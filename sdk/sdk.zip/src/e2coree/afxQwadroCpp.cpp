
#ifdef __cplusplus
extern "C"
{
#include "afx/afxQwadro.h"
}
#endif

//struct afxInstance
//{
    //int a;
//};

//typedef struct afxInstance *afxInstance;
