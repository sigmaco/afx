/*
 *          ::::::::  :::       :::     :::     :::::::::  :::::::::   ::::::::
 *         :+:    :+: :+:       :+:   :+: :+:   :+:    :+: :+:    :+: :+:    :+:
 *         +:+    +:+ +:+       +:+  +:+   +:+  +:+    +:+ +:+    +:+ +:+    +:+
 *         +#+    +:+ +#+  +:+  +#+ +#++:++#++: +#+    +:+ +#++:++#:  +#+    +:+
 *         +#+  # +#+ +#+ +#+#+ +#+ +#+     +#+ +#+    +#+ +#+    +#+ +#+    +#+
 *         #+#   +#+   #+#+# #+#+#  #+#     #+# #+#    #+# #+#    #+# #+#    #+#
 *          ###### ###  ###   ###   ###     ### #########  ###    ###  ########
 *
 *              T H E   Q W A D R O   E X E C U T I O N   E C O S Y S T E M
 *
 *                                   Public Test Build
 *                   (c) 2017 SIGMA Technology Group � Federa��o SIGMA
 *                                    www.sigmaco.org
 */

#define _CRT_SECURE_NO_WARNINGS 1
#define WIN32_LEAN_AND_MEAN 1

#include <sys/stat.h>
#include <stdio.h>

#if (defined(_WIN32) || defined(_WIN64))
#   include <Windows.h>
#   include <Shlwapi.h>
#   include <combaseapi.h>
#   include <process.h>
#   include <sys/timeb.h>
#else
#   include <unistd.h>
#endif

#define _AFX_SYSTEM_C
#define _AFX_THREAD_C
#define _AFX_MOUSE_C
#define _AFX_KEYBOARD_C
#define _AFX_MODULE_C
#define _AFX_FILE_C
#define _AFX_ARCHIVE_C
#define _AFX_APPLICATION_C
#define _AFX_CONTEXT_C
#define _AFX_DRAW_SYSTEM_C
#include "../src/e2coree/core/afxCoreHideout.h"
#include "afx/core/afxSystem.h"
#include "afx/draw/afxDrawSystem.h"
#include "afx/core/afxArchive.h"
#include "afx/core/afxStream.h"
#include "afx/core/afxKeyboard.h"
#include "afx/core/afxMouse.h"
#include "afx/core/afxContext.h"
#include "afx/core/afxString.h"
#include "afx/core/afxThread.h"
#include "afx/core/afxPool.h"

_AFX afxClass _sysClass;
afxClass _sysClass;
_AFX afxBool _sysClassInited = FALSE;
_AFX afxChar const _rwBuildDateTime[];
static afxChar const  _rwBuildDateTime[] = "\nCore built at " __DATE__ " " __TIME__ "\n";
static afxChar const _yhwhNisi[] = "Yhwh-nisi";

_AFX afxSystem theSys;
afxSystem theSys = NIL;
//_AFX struct _afxSysD theSys;
_AFX afxClassConfig _AfxSysClsConfig;

_AFX afxNat mainThreadId;

AFX afxError AfxExecuteThread(afxThread thr);

extern afxClassConfig _AfxCtxClsConfig;
extern afxClassConfig _AfxMdleClsConfig;
extern afxClassConfig _AfxThrClsConfig;
extern afxClassConfig _AfxFileClsConfig;
extern afxClassConfig _AfxArcClsConfig;
extern afxClassConfig _AfxAppClsConfig;
extern afxClassConfig _AfxKbdClsConfig;
extern afxClassConfig _AfxMseClsConfig;
extern afxClassConfig _AfxDsysClsConfig;

AFX_DEFINE_STRUCT(afxStoragePoint)
{
    afxFcc          fcc;
    afxLinkage      io;

    afxUri         name; // name of exchange point // AFX_FS_SYM_LEN // can't have control chars. Actually works like a variable without $().
    afxUri         path; // path of exchange point
    afxIoFlags      flags;
    afxArchive      arc;
};

#if 0
AFX afxBool _AfxGetSysD(afxSystem sys, struct _afxSysD**sysD)
{
    afxError err = AFX_ERR_NONE;
    //AfxAssertObjects(1, &sys, afxFcc_SYS);
    afxBool rslt = FALSE;

    if (theSys->sysObj == sys)
    {
        AfxAssert(sysD);
        *sysD = &theSys;
        rslt = TRUE;
    }
    return rslt;
}
#endif

_AFX void Start_us_count(afxNat64* out_count)
{
    QueryPerformanceCounter((LARGE_INTEGER*)out_count);
}

_AFX afxNat32 Delta_us_count(afxNat64* last_count)
{
    static afxNat64 frequency = 1000;
    static afxInt32 got_frequency = 0;

    if (!got_frequency)
    {
        got_frequency = 1;
        QueryPerformanceFrequency((LARGE_INTEGER*)&frequency);
    }
    afxNat64 start = *last_count;
    QueryPerformanceCounter((LARGE_INTEGER*)last_count);
    return((afxNat32)(((*last_count - start) * (afxNat64)1000000) / frequency));
}

#define Start_timer() { afxNat64 __timer; Start_us_count( &__timer );
#define End_and_start_next_timer( count ) count += Delta_us_count( &__timer );
#define End_timer( count ) End_and_start_next_timer( count ) }


// READ ONLY METHODS //////////////////////////////////////////////////////////

_AFX afxNat AfxGetIoBufferSize(void)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertObjects(1, &theSys, afxFcc_SYS);
    return theSys->ioBufSiz;
}

_AFX afxArena* AfxGetIoArena(void)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertObjects(1, &theSys, afxFcc_SYS);
    afxArena *aren = &theSys->ioArena;
    AfxAssertType(aren, afxFcc_AREN);
    return aren;
}

#define AfxSystem(_t_) theSys->_t_

_AFX afxContext AfxGetIoContext(void)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertObjects(1, &theSys, afxFcc_SYS);
    afxContext ctx = theSys->ctx;
    AfxAssertObjects(1, &ctx, afxFcc_CTX);
    return ctx;
}

_AFX afxContext AfxGetSystemContext(void)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertObjects(1, &theSys, afxFcc_SYS);
    afxContext ctx = theSys->ctx;
    //AfxAssertObjects(1, &ctx, afxFcc_CTX);
    return ctx;
}

_AFX afxNat AfxGetMemoryPageSize(void)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertObjects(1, &theSys, afxFcc_SYS);
    return theSys->memPageSize;
}

_AFX afxNat AfxGetThreadingCapacity(void)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertObjects(1, &theSys, afxFcc_SYS);
    return theSys->hwConcurrencyCap;
}

_AFX afxBool AfxGetSystem(afxSystem *sys)
{
    if (sys)
        *sys = theSys;

    return !!theSys;
}

_AFX afxUri const* AfxGetSystemRootPath(afxUri *copy)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertObjects(1, &theSys, afxFcc_SYS);
    afxUri const* rootDir = &theSys->rootDir;
    return copy ? AfxCopyUri(copy, rootDir), copy : rootDir;
}

_AFX afxString const* AfxGetSystemRootPathString(afxString *copy)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertObjects(1, &theSys, afxFcc_SYS);
    afxString const* rootDir = AfxUriGetStringConst(&theSys->rootDir);
    return copy ? AfxCopyString(copy, rootDir), copy : rootDir;
}

AFX afxResult _AfxProcessSystemInputMessageWin32(MSG* msg); // from afxHid.c

_AFX afxResult _AfxProcessHostPlatformEvents(void)
{
    afxError err = AFX_ERR_NONE;

    MSG msg;
    //afxEvent ev;
    afxResult msgCnt = 0;
    
    while (PeekMessageA(&(msg), NIL, 0, 0, PM_REMOVE/* | PM_NOYIELD*/))
    {
        ++msgCnt;

        if (msg.message == WM_QUIT) // PostQuitMessage()
        {
            AfxRequestSystemShutdown(0);
        }
        else
        {
            if (msg.message == WM_INPUT || msg.message == WM_INPUT_DEVICE_CHANGE)
            {
                _AfxProcessSystemInputMessageWin32(&msg);

                if (AfxKeyWasPressed(0, AFX_KEY_F1))
                {
                    AfxAssist("User input requested support.");
                    AfxAssist("Get help at https://sigmaco.org/");
                    system("start https://sigmaco.org");
                }
                else if (AfxKeyWasPressed(0, AFX_KEY_F4))
                {
                    //AfxRequestThreadInterruption(thr);
                    AfxAdvertise("User input requested application break.");
                    AfxRequestSystemShutdown(0);
                }
                else if (AfxKeyWasPressed(0, AFX_KEY_F5))
                {
                    AfxAdvertise("User input requested application reboot.");
                    //_AfxInterruptionAllApplications();
                    //opcode = AFX_OPCODE_REBOOT;
                }
            }

            TranslateMessage(&(msg));
            DispatchMessageA(&(msg));
        }
    }
    return msgCnt;
}

_AFX afxBool _AfxThrQuitAndExecuteCb(afxThread thr, void *udd)
{
    afxError err = AFX_ERR_NONE;
    (void)udd;
    //afxInt exitCode = *(afxInt*)udd;

    AfxRequestThreadInterruption(thr);

    if (AfxExecuteThread(thr))
        AfxThrowError();

    return FALSE; // dont interrupt curation
}

_AFX void _AfxInterruptionAllThreads(afxInt exitCode)
{
    AfxCurateThreads(0, AFX_N32_MAX, _AfxThrQuitAndExecuteCb, &exitCode);
}

_AFX void AfxRequestSystemShutdown(afxInt exitCode)
{
    afxError err = AFX_ERR_NONE;

    afxSystem sys;

    if (!AfxGetSystem(&sys)) AfxThrowError();
    else
    {
        AfxAssertObjects(1, &sys, afxFcc_SYS);
        _AfxInterruptionAllThreads(exitCode);
        sys->exitCode = exitCode;
        sys->isInShutdown = TRUE;
    }
}

_AFX afxBool AfxSystemIsOperating(void)
{
    afxError err = AFX_ERR_NONE;

    afxSystem sys;

    if (AfxGetSystem(&sys))
    {
        AfxAssertObjects(1, &sys, afxFcc_SYS);
        return sys->operating && !sys->isInShutdown;
    }
    return FALSE;
}

_AFX afxBool _AfxThrExecuteCb(afxThread thr, void *udd)
{
    afxError err = AFX_ERR_NONE;
    afxSystem sys;

    if (AfxGetSystem(&sys))
    {
        AfxAssertObjects(1, &sys, afxFcc_SYS);
        AfxAssertObjects(1, &thr, afxFcc_THR);
        afxProcessor *procUnit = udd;

        afxNat affineProcUnitIdx = thr->affineProcUnitIdx;

        if ((AFX_INVALID_INDEX == affineProcUnitIdx) || (affineProcUnitIdx == procUnit->unitIdx))
        {
            if (AfxExecuteThread(thr))
                AfxThrowError();
        }
    }
    return FALSE; // dont interrupt curation
}

_AFX afxResult AfxDoSystemThreading(afxTime timeout)
{
    afxError err = AFX_ERR_NONE;
    (void)timeout;

    afxResult code = 0;
    afxSystem sys;

    if (!AfxGetSystem(&sys)) AfxThrowError();
    else
    {
        AfxAssertObjects(1, &sys, afxFcc_SYS);
        
        if (AfxSystemIsOperating())
        {
            afxNat procUnitIdx;
            AfxGetThreadingUnit(&procUnitIdx);
            afxProcessor *procUnit;
            
            if (!AfxGetPoolUnit(&sys->processors, procUnitIdx, (void**)&procUnit)) AfxThrowError();
            else
            {
                afxNat32 tid;
                AfxGetThreadingId(&tid);

                if (procUnit->tid == tid)
                {
                    // Ignore clock recentering issues for this example
                    AfxGetClock(&procUnit->currClock);
                    procUnit->currTime = AfxGetSecondsElapsed(&procUnit->startClock, &procUnit->currClock);
                    procUnit->deltaTime = AfxGetSecondsElapsed(&procUnit->lastClock, &procUnit->currClock);
                    procUnit->lastClock = procUnit->currClock;

                    if (1 < AfxGetSecondsElapsed(&procUnit->iterCntSwapClock, &procUnit->currClock))
                    {
                        procUnit->iterCntSwapClock = procUnit->currClock;
                        procUnit->lastIterCnt = procUnit->iterCnt;
                        procUnit->iterCnt = 0;
                    }
                    else
                    {
                        ++procUnit->iterCnt;
                    }

                    afxResult msgCnt = _AfxProcessHostPlatformEvents();

                    afxNat rslt = AfxCurateThreads(0, AFX_N32_MAX, _AfxThrExecuteCb, procUnit);
                }
            }
        }

        if (sys->isInShutdown)
            code = sys->exitCode;
    }
    return code;
}

_AFXINL afxBool _AfxNotifyObject(afxInstance *receiver, afxEvent *ev)
{
    // Sends event to receiver: receiver->event(event). 
    // Returns the value that is returned from the receiver's event handler. 
    // Note that this function is called for all events sent to any object in any thread.

    afxError err = AFX_ERR_NONE;
    
    AfxAssertType(receiver, afxFcc_OBJ);
    AfxAssertType(ev, afxFcc_EVNT);
    afxBool rslt = AfxObjectEmitEvent(receiver, ev);

    return rslt;
}

_AFX afxBool AfxEmitEvents(afxNat cnt, afxInstance *receiver[], afxEvent ev[])
{
    afxError err = AFX_ERR_NONE;
    

    AfxAssert(receiver);
    AfxAssert(ev);
    afxBool res = 0;
    
    for (afxNat i = 0; i < cnt; i++)
    {
        afxInstance *obj = receiver[i];
        AfxAssertType(obj, afxFcc_OBJ);
        afxEvent *e = &ev[i];
        AfxAssertType(e, afxFcc_EVNT);
        _AfxNotifyObject(obj, e);
    }
    return res;
}

_AFX afxBool AfxReemitEvent(afxNat cnt, afxInstance *receiver[], afxEvent *ev)
{
    afxError err = AFX_ERR_NONE;

    AfxAssert(receiver);
    AfxAssertType(ev, afxFcc_EVNT);

    for (afxNat i = 0; i < cnt; i++)
    {
        afxInstance *obj = receiver[i];
        AfxAssertType(obj, afxFcc_OBJ);
        _AfxNotifyObject(obj, ev);
    }
    return err;
}

_AFX afxBool AfxEmitEvent(afxInstance *receiver, afxEvent *ev)
{
    afxError err = AFX_ERR_NONE;

    AfxAssertType(receiver, afxFcc_OBJ);
    AfxAssertType(ev, afxFcc_EVNT);
    return _AfxNotifyObject(receiver, ev);
}

_AFX afxError AfxPostEvents(afxNat cnt, afxInstance *receiver[], afxEvent ev[])
{
    afxError err = AFX_ERR_NONE;

    AfxAssert(receiver);
    AfxAssertType(ev, afxFcc_EVNT);

    for (afxNat i = 0; i < cnt; i++)
    {
        afxInstance *obj = receiver[i];
        AfxAssertType(obj, afxFcc_OBJ);
        _AfxNotifyObject(obj, ev);
        AfxThrowError();
        // Not implemented yet.
    }
    return err;
}

_AFX afxError AfxPostEvent(afxInstance *receiver, afxEvent *ev)
{
    afxError err = AFX_ERR_NONE;

    AfxAssertType(receiver, afxFcc_OBJ);
    AfxAssertType(ev, afxFcc_EVNT);
    
    if (AfxPostEvents(1, &receiver, ev))
        AfxThrowError();

    return err;
}

_AFX afxResult AfxDescribeStoragePoints(afxNat first, afxNat cnt, afxStoragePointSpecification spec[])
{
    afxError err = AFX_ERR_NONE;
    AfxAssert(cnt);
    AfxAssert(spec);
    afxResult rslt = 0;

    afxNat posn = 0;
    afxStoragePoint *mnpt;
    AfxAssertObjects(1, &theSys, afxFcc_SYS);
    AfxChainForEveryLinkage(&theSys->mountPoints, afxStoragePoint, io, mnpt)
    {
        AfxAssertType(mnpt, afxFcc_FSSP);

        if (posn >= first)
        {
            spec[rslt].namespace = &mnpt->name;
            spec[rslt].hostPath = &mnpt->path;
            spec[rslt].isZip = !!mnpt->arc;
            spec[rslt].perm = mnpt->flags;
            ++rslt;
        }

        ++posn;

        if (posn >= first + cnt)
            break;
    }
    return rslt;
}

/******************************************************************************

 Unix-like systems implement three specific permissions that apply to each class:

 The read permission grants the ability to read a file. When set for a directory,
 this permission grants the ability to read the names of files in the directory,
 but not to find out any further information about them such as contents, file class,
 size, ownership, permissions.

 The write permission grants the ability to modify a file. When set for a directory,
 this permission grants the ability to modify entries in the directory, which includes
 creating files, deleting files, and renaming files. Note that this requires that
 execute is also set; without it, the write permission is meaningless for directories.

 The execute permission grants the ability to execute a file. This permission must be
 set for executable programs, in order to allow the operating system to run them. When
 set for a directory, the execute permission is interpreted as the search permission:
 it grants the ability to access file contents and meta-information if its name is
 known, but not list files inside the directory, unless read is set also.

 The effect of setting the permissions on a directory, rather than a file, is "one of
 the most frequently misunderstood file permission issues".

 When a permission is not set, the corresponding rights are denied. Unlike ACL-based
 systems, permissions on Unix-like systems are not inherited. Files created within a
 directory do not necessarily have the same permissions as that directory.

 ******************************************************************************/

_AFX afxError AfxResolveUris(afxNat cnt, afxUri const in[], afxFileFlags const permissions[], afxUri out[])
{
    afxError err = AFX_ERR_NONE;

    AfxAssertObjects(1, &theSys, afxFcc_SYS);

    AfxAssert(in);
    AfxAssert(out);
    AfxAssert(permissions);

    for (afxNat i = 0; i < cnt; i++)
    {
        AfxAssertType(&in[i], afxFcc_URI);
        AfxAssertType(&out[i], afxFcc_URI);
        AfxAssert(!AfxUriIsBlank(&in[i]));

        afxFileFlags ioPerms = permissions ? permissions[i] & AFX_FILE_PERM_MASK : AFX_FILE_FLAG_RX;
        afxBool resolved = FALSE;
        struct stat st;

        unsigned short flagsToTest = NIL;

        if (AfxFlagsTest(ioPerms, AFX_FILE_FLAG_R))
            flagsToTest |= _S_IREAD;

        if (AfxFlagsTest(ioPerms, AFX_FILE_FLAG_W))
            flagsToTest |= _S_IWRITE;

        //if (AfxFlagsTest(ioPerms, AFX_IO_FLAG_X))
            //flagsToTest |= _S_IEXEC;

#if 0
        if (fileStr)
            flagsToTest |= _S_IFREG;
        else if (dirStr)
            flagsToTest |= _S_IFDIR;
#endif

        afxString const *srcStr = AfxUriGetStringConst(&in[i]);
        afxString const *dstStr = AfxUriGetStringConst(&out[i]);
        afxChar const* srcData = AfxGetStringDataConst(srcStr, 0);
        afxChar const* dstData = AfxGetStringDataConst(dstStr, 0);

        if (('a' > srcData[0] && 'z' < srcData[0]) || ('A' > srcData[0] && 'Z' < srcData[0]))
        {
            AfxCopyUri(&out[i], &in[i]);

            if (stat(dstData, &(st))) AfxThrowError();
            else
            {
                if (!((st.st_mode & flagsToTest) == flagsToTest))
                    AfxThrowError();
            }
            resolved = TRUE;
        }
        else
        {
            afxUri path, dir, file;
            AfxExcerptUriPath(&path, &in[i]);
            AfxExcerptUriDirectory(&dir, &in[i]);
            AfxExcerptUriObject(&file, &in[i]);
            afxString const *pathStr = AfxUriGetStringConst(&path);
            afxString const *dirStr = AfxUriGetStringConst(&dir);
            afxString const *fileStr = AfxUriGetStringConst(&file);

            srcData = AfxGetStringDataConst(pathStr, 0);

            afxChar const *pointStart = srcData;

            afxChar const *pointEnd = AfxFindCharRaw(pointStart, '/');

            afxString point;
            AfxWrapStringLiteral(&point, pointStart, pointEnd ? pointEnd - pointStart : AfxGetStringSize(pathStr));
            afxString const *pointStr = &point;

            if (pointEnd && *pointEnd == '/')
                pointEnd++; // skip bar

            afxNat pointEndRange = pointEnd ? AfxGetStringSize(pathStr) - (pointEnd - pointStart) : AfxGetStringSize(pathStr);


#if 0
#define _S_IFMT   0xF000 // File class mask
#define _S_IFDIR  0x4000 // Directory
#define _S_IFCHR  0x2000 // Character special
#define _S_IFIFO  0x1000 // Pipe
#define _S_IFREG  0x8000 // Regular
#define _S_IREAD  0x0100 // Read permission, owner
#define _S_IWRITE 0x0080 // Write permission, owner
#define _S_IEXEC  0x0040 // Execute/search permission, owner
#endif
            AfxCopyUri(&out[i], &in[i]);

            if (!pointEnd)
            {
                AfxFormatUri(&out[i], "%.*s", AfxGetStringSize(pathStr), AfxGetStringDataConst(pathStr, 0));

                if (stat(dstData, &(st))) AfxThrowError();
                else
                {
                    if (!((st.st_mode & flagsToTest) == flagsToTest))
                        AfxThrowError();

                }

                resolved = TRUE;
            }
            else
            {
                afxStoragePoint *fssp;
                AfxChainForEveryLinkage(&theSys->mountPoints, afxStoragePoint, io, fssp)
                {
                    if ((fssp->flags & ioPerms) == ioPerms)
                    {
                        if (0 == AfxCompareString(&point, AfxUriGetStringConst(&fssp->name)))
                        {
                            AfxFormatUri(&out[i], "%.*s/%.*s\0", AfxPushString(AfxUriGetStringConst(&fssp->path)), pointEndRange, pointEnd);
                            AfxEcho(dstData);

                            if (!stat(dstData, &(st)) || (ioPerms & AFX_FILE_FLAG_W))
                            {
                                if (((st.st_mode & flagsToTest) == flagsToTest) || ioPerms & AFX_FILE_FLAG_W)
                                {
                                    resolved = TRUE;
                                    break;
                                }
                            }
                        }
                    }
                }

                if (!resolved)
                    AfxThrowError(); // unresolved.
            }

            //AfxAdvertise("%x %x %x %x %x", st.st_mode & _S_IFREG, st.st_mode & _S_IFDIR, st.st_mode & _S_IREAD, st.st_mode & _S_IWRITE, st.st_mode & _S_IEXEC);
        }

  //      if (!resolved)
//            AfxCopyUri(&out[i], &in[i]);
    }
    return err;
}

_AFX afxError AfxResolveUri(afxUri const *in, afxFileFlags permissions, afxUri *out)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(in, afxFcc_URI);
    AfxAssertType(out, afxFcc_URI);
    AfxAssert(!AfxUriIsBlank(in));

    if (AfxResolveUris(1, in, &permissions, out))
        AfxThrowError();

    return err;
}

_AFX afxResult AfxDismountStoragePoints(afxNat cnt, afxStoragePointSpecification const spec[])
{
    afxError err = AFX_ERR_NONE;
    AfxAssert(cnt);
    AfxAssert(spec);
    AfxEntry("%u,%p", cnt, spec);
    afxResult hitCnt = 0;
    afxStoragePoint* mnpt;

    AfxAssertObjects(1, &theSys, afxFcc_SYS);

    for (afxNat i = 0; i < cnt; i++)
    {
        afxLinkage *lnk = AfxGetLastLinkage(&theSys->mountPoints);

        while (1)
        {
            if (!lnk) break;
            else
            {
                afxLinkage *next = AfxGetNextLinkage(lnk);
                mnpt = AFX_REBASE(lnk, afxStoragePoint, io);
                AfxAssert(mnpt->fcc == afxFcc_FSSP);
                afxUri const *name = spec[i].namespace;

                if (!name || 0 == AfxCompareString(AfxUriGetStringConst(name), AfxUriGetStringConst(&mnpt->name)))
                {
                    hitCnt++;
                    AfxEcho("Point \"%.*s\" %x unmounted -> \"%.*s\".", AfxPushString(AfxUriGetStringConst(&mnpt->name)), mnpt->flags, AfxPushString(AfxUriGetStringConst(&mnpt->path)));
                    AfxPopLinkage(&mnpt->io);

                    if (mnpt->arc)
                        AfxReleaseObjects(1, (void*[]) { mnpt->arc });

                    AfxUriDeallocate(&mnpt->path);
                    AfxUriDeallocate(&mnpt->name);

                    AfxDeallocate(theSys->ctx, mnpt);
                    break;
                }
                lnk = next;
            }
        }
    }
    return hitCnt;
}

_AFX afxResult AfxMountStoragePoints(afxNat cnt, afxStoragePointSpecification const spec[])
{
    afxError err = AFX_ERR_NONE;
    AfxAssertObjects(1, &theSys, afxFcc_SYS);

    AfxAssert(cnt);
    AfxAssert(spec);
    AfxAssert(spec->perm & AFX_IO_PERM_MASK);
    AfxEntry("%u,%p", cnt, spec);
    afxResult hitCnt = 0;
    afxStoragePoint* fssp;

    afxUri const *rootUri = AfxGetSystemRootPath(NIL);
    afxString const *rootUriString = AfxGetSystemRootPathString(NIL);

    afxUri2048 bufUri;
    AfxUri2048(&bufUri);

    for (afxNat i = 0; i < cnt; i++)
    {
        afxUri path;
        AfxExcerptUriPath(&path, spec[i].hostPath);

        if (AfxUriIsPathRelative(&path))
        {
            AfxFormatUri(&bufUri.uri, "%.*s/%.*s", AfxPushString(rootUriString), AfxPushString(AfxUriGetStringConst(&path)));
        }
        else
        {
            AfxCopyUri(&bufUri.uri, &path);
        }

        afxChar const *pathRaw = AfxGetUriDataConst(&bufUri.uri, 0);
        struct stat st;

        if (stat(pathRaw, &(st))) AfxThrowError();
        else
        {
            unsigned short flagsToTest = NIL;
            afxIoFlags ioPerms = spec[i].perm & AFX_IO_PERM_MASK;

            if (AfxFlagsTest(ioPerms, AFX_IO_FLAG_R))
                flagsToTest |= _S_IREAD;

            if (AfxFlagsTest(ioPerms, AFX_IO_FLAG_W))
                flagsToTest |= _S_IWRITE;

            if (AfxFlagsTest(ioPerms, AFX_IO_FLAG_X))
                flagsToTest |= _S_IEXEC;

            if (!((st.st_mode & flagsToTest) == flagsToTest)) AfxThrowError();
            else
            {
                afxBool isDir = !!(st.st_mode & _S_IFDIR);
                afxBool isFile = !!(st.st_mode & _S_IFREG);
                afxArchive arc = NIL;

                if (!isDir && (isFile && AfxAcquireArchives(1, &arc, &bufUri.uri, (afxFileFlags[]) { ioPerms | AFX_FILE_FLAG_D }))) AfxThrowError();
                else
                {
                    if (!(fssp = AfxAllocate(theSys->ctx, sizeof(*fssp), 0, AfxSpawnHint()))) AfxThrowError();
                    else
                    {
                        fssp->fcc = afxFcc_FSSP;
                        AfxPushLinkage(&fssp->io, &theSys->mountPoints);
                        AfxCloneUriPath(&fssp->name,spec[i].namespace);

                        //if (!(fssp->name)) AfxThrowError();
                        //else
                        {
                            AfxCloneUriPath(&fssp->path,&bufUri.uri);

                            //if (!(fssp->path)) AfxThrowError();
                            //else
                            {
                                fssp->flags = ioPerms;
                                fssp->arc = arc;

                                hitCnt++;
                                AfxEcho("Point \"%.*s\" %x mounted -> \"%.*s\".", AfxPushString(AfxUriGetStringConst(&fssp->name)), fssp->flags, AfxPushString(AfxUriGetStringConst(&fssp->path)));

                                if (err)
                                    AfxUriDeallocate(&fssp->path);
                            }

                            if (err)
                                AfxUriDeallocate(&fssp->name);
                        }

                        if (err)
                        {
                            AfxPopLinkage(&fssp->io);
                            AfxDeallocate(theSys->ctx, fssp);
                        }
                    }

                    if (err && arc)
                        AfxReleaseObjects(1, (void*[]) { arc });
                }
            }
        }
    }

    return hitCnt;
}

_AFX afxNat AfxGetStoragePointCount(void)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertObjects(1, &theSys, afxFcc_SYS);
    return theSys->mountPoints.cnt;
}

#if 0
_AFX afxError AfxEnableResourceMonitoring(afxResource res, afxBool enable)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertObjects(1, &theSys, afxFcc_SYS);
    //AfxAssertObject(res, afxFcc_RES);

    if (enable)
    {
        if (NIL == res->monitor.chain)
        {
            //afxSystem sys = AfxResourceGetSystem(res);
            AfxPushLinkage(&res->monitor, &theSys->aliveRsrcs);
        }
    }
    else
    {
        if (res->monitor.chain)
            AfxPopLinkage(&res->monitor);
    }
    return err;
}

_AFX void _AfxMonitorResources(void)
{
    afxError err = AFX_ERR_NONE;
    afxUri2048 tmp;
    AfxUri2048(&tmp);
    afxTime lastUpdTime = 0;

    afxResource res;
    AfxAssertObjects(1, &theSys, afxFcc_SYS);
    AfxChainForEveryLinkage(&theSys->aliveRsrcs, AFX_OBJECT(afxResource), monitor, res)
    {
        //AfxAssertObject(res, afxFcc_RES);

        if (!res->uri || AfxUriIsBlank(res->uri)) AfxThrowError();
        else
        {
            if (AfxResolveUri(res->uri, AFX_FILE_FLAG_R, &tmp.uri)) AfxThrowError();
            else
            {
                //if (res->lastUpdTime < *resolver.lastUpdTime)
                {
                    //if (AfxLoadResource(res)) AfxThrowError();
                    //else
                    {
                        //AfxGetTime(&res->lastUpdTime);
                    }
                }
            }
        }
    }

}
#endif

_AFX void AfxStdAssertHookCallback(char const* exp, char const* file, int line)
{
    assert(exp);
    assert(file);
    assert(line);
    AfxLogMessageFormatted(0xFF000000, "\n %s:%i\n\t     %s", file, line, exp);
}

_AFX afxError _AfxSysDtor(afxSystem sys)
{
    AfxEntry("sys=%p", sys);
    afxError err = AFX_ERR_NONE;
    AfxAssertObjects(1, &sys, afxFcc_SYS);

    for (afxNat i = 0; i < sys->hwConcurrencyCap * 2; i++)
        AfxYieldThreading();

    _AfxShutdownOrphanClasses();

    // will be released at class drop.
    //AfxReleaseObject(&(sys->stdKbd->hid.obj));
    //AfxReleaseObject(&(sys->e2coree->obj));
    //AfxReleaseObject(&(sys->ctx->obj));

    AfxAssert(sys->aliveRsrcs.cnt == 0);

    for (;;)
    {
        if (!AfxGetStoragePointCount()) break;
        else
        {
            afxStoragePointSpecification spec = { 0 };

            if (1 != AfxDescribeStoragePoints(0, 1, &spec)) AfxThrowError();
            else
            {
                if (1 != AfxDismountStoragePoints(1, &spec))
                    AfxThrowError();
            }
        }
    }

    AfxUriDeallocate(&sys->rootDir);

    _AfxUninstallChainedClasses(&sys->classes);
    //AfxReleaseArena(&sys->ioArena);
    //AfxReleaseObject(&(sys->memD->obj));

    //_AfxFreeExternalAllocations();
    theSys = NIL;
    return err;
}

_AFX void AfxShutdownBasicIoSystem(afxInt exitCode)
{
    afxError err = AFX_ERR_NONE;
    afxSystem sys;

    if (AfxGetSystem(&sys))
    {
        do { AfxRequestSystemShutdown(exitCode); } while (AfxSystemIsOperating());
        while (!AfxReleaseObjects(1, (void*[]) { sys }));
        AfxDismountClass(&_sysClass);
    };
#ifndef _AFX_DISABLE_DEBUGGER
    AfxDetachDebugger();
#endif
}

_AFX int __stdcall startCbOnSysProcUnit(afxProcessor *procUnit)
{
    afxError err = AFX_ERR_NONE;
    
    procUnit->tid = GetCurrentThreadId();

    //_AfxThrRun(thr);
    AfxEntry("Threading Execution Environment %u started", procUnit->unitIdx);
    AfxGetClock(&procUnit->startClock);

    while (AfxSystemIsOperating())
    {
        AfxDoSystemThreading(0);
    }

    procUnit->activeThr = NIL;
    CloseHandle(procUnit->osHandle);
    procUnit->osHandle = NIL;
    procUnit->tid = 0;

    AfxEntry("Threading Execution Environment %u stopped.", procUnit->unitIdx);
    return 0;
}

_AFX afxError _AfxSysCtor(afxSystem sys, afxCookie const* cookie)
{
    AfxEntry("sys=%p", sys);
    afxError err = AFX_ERR_NONE;
    AfxAssertObjects(1, &sys, afxFcc_SYS);

    afxSystemConfig const *config = ((afxSystemConfig const *)cookie->udd[0]) + cookie->no;

    theSys = sys; // evil trick to get this working at bootstrap

    afxSystemConfigWin32 *configExt = AFX_REBASE(config, afxSystemConfigWin32, base);

    mainThreadId;
    AfxGetThreadingId(&mainThreadId);
    
    sys->isInShutdown = FALSE;
    sys->isInBootUp = FALSE;
    sys->operating = FALSE;
    sys->interruptionRequested = FALSE;

    afxSystemConfigWin32 def;
    AfxChooseBasicIoSystemConfiguration(&def.base, sizeof(def));

    sys->assertHook = def.base.assertHook;
    sys->unitsToMeter = def.base.unitsToMeter;
    sys->ioBufSiz = def.base.ioBufSiz;
    sys->hwConcurrencyCap = def.base.maxHwThreads;
    sys->memPageSize = def.base.memPageSiz;
    sys->allocGranularity = def.base.allocGranularity;
    sys->profilerPopTimer = def.base.profilerPopTimer;
    sys->profilerPushTimer = def.base.profilerPushTimer;
    sys->profilerPostMarker = def.base.profilerPostMarker;

    afxNat handlePageSiz = def.base.handlePageSiz;

    if (config)
    {
        if (config->memPageSiz)
            sys->memPageSize = config->memPageSiz;

        if (config->allocGranularity)
            sys->allocGranularity = config->allocGranularity;

        if (config->maxHwThreads)
            sys->hwConcurrencyCap = config->maxHwThreads;

        if (config->assertHook)
            sys->assertHook = config->assertHook;

        if (config->unitsToMeter)
            sys->unitsToMeter = config->unitsToMeter;

        if (config->ioBufSiz)
            sys->ioBufSiz = config->ioBufSiz;

        if (config->handlePageSiz)
            handlePageSiz = config->handlePageSiz;

        if (config->profilerPopTimer)
            sys->profilerPopTimer = config->profilerPopTimer;

        if (config->profilerPushTimer)
            sys->profilerPushTimer = config->profilerPushTimer;

        if (config->profilerPostMarker)
            sys->profilerPostMarker = config->profilerPostMarker;
    }

    afxChain* classes = &sys->classes;
    AfxAcquireChain(classes, &sys);

    AfxMountClass(&sys->memories, classes, &_AfxCtxClsConfig);
    AfxMountClass(&sys->modules, classes, &_AfxMdleClsConfig);
    AfxMountClass(&sys->threads, classes, &_AfxThrClsConfig);
    AfxMountClass(&sys->files, classes, &_AfxFileClsConfig);
    AfxMountClass(&sys->archives, classes, &_AfxArcClsConfig);
    AfxMountClass(&sys->applications, classes, &_AfxAppClsConfig);
    AfxMountClass(&sys->keyboards, classes, &_AfxKbdClsConfig);
    AfxMountClass(&sys->mouses, classes, &_AfxMseClsConfig);
    AfxMountClass(&sys->dsystems, classes, &_AfxDsysClsConfig);

    afxChar buf[2048];
    GetModuleFileNameA(NULL, buf, sizeof(buf));
    PathRemoveFileSpecA(buf);
    AfxConcatRawString(buf, "/");

    AfxAdvertise("Memory page size: %d", sys->memPageSize);
    AfxAdvertise("Logical processor count: %d", sys->hwConcurrencyCap);

    afxAllocationStrategy as = { 0 };
    as.size = sizeof(afxByte);
    as.align = AFX_SIMD_ALIGN;
    as.cap = 0;
    as.duration = AFX_ALL_DUR_TRANSIENT;
    as.resizable = TRUE;
    as.stock = sys->memPageSize * 8192; // 32MB

    if (AfxAcquireContexts(1, &sys->ctx, &as, AfxSpawnHint())) AfxThrowError();
    else
    {
        afxUri rootDir;
        AfxUriWrapLiteral(&rootDir, buf, 0);
        AfxCloneUri(&sys->rootDir, &rootDir);
        SetCurrentDirectoryA(AfxGetUriDataConst(&rootDir, 0));

        afxUri tmpUriMaps[6];
        AfxUriWrapLiteral(&tmpUriMaps[0], ".", 0);
        AfxUriWrapLiteral(&tmpUriMaps[1], "system", 0);
        AfxUriWrapLiteral(&tmpUriMaps[2], "sound", 0);
        AfxUriWrapLiteral(&tmpUriMaps[3], "data", 0);
        AfxUriWrapLiteral(&tmpUriMaps[4], "art", 0);
        AfxUriWrapLiteral(&tmpUriMaps[5], "tmp", 0);

        afxUri tmpHostPaths[6];
        AfxUriWrapLiteral(&tmpHostPaths[0], "..", 0);
#ifdef AFX_PLATFORM_X64
        AfxUriWrapLiteral(&tmpHostPaths[1], "../system64", 0);
#elif defined(AFX_PLATFORM_X86)
        AfxUriWrapLiteral(&tmpHostPaths[1], "../system32", 0);
#else
        AfxUriWrapLiteral(&tmpHostPaths[1], "../system", 0);
#endif
        AfxUriWrapLiteral(&tmpHostPaths[2], "../sound", 0);
        AfxUriWrapLiteral(&tmpHostPaths[3], "../data", 0);
        AfxUriWrapLiteral(&tmpHostPaths[4], "../art", 0);
        AfxUriWrapLiteral(&tmpHostPaths[5], "../tmp", 0);

        afxStoragePointSpecification mnptSpec[] =
        {
            { &tmpUriMaps[0], &tmpHostPaths[0], AFX_IO_FLAG_RX, FALSE },
            { &tmpUriMaps[1], &tmpHostPaths[1], AFX_IO_FLAG_RX, FALSE },
            { &tmpUriMaps[2], &tmpHostPaths[2], AFX_IO_FLAG_RX, FALSE },
            { &tmpUriMaps[3], &tmpHostPaths[3], AFX_IO_FLAG_RX, FALSE },
            { &tmpUriMaps[4], &tmpHostPaths[4], AFX_IO_FLAG_RX, FALSE },
            { &tmpUriMaps[5], &tmpHostPaths[5], AFX_IO_FLAG_RWX, FALSE },
        };

        afxNat mpCnt = sizeof(mnptSpec) / sizeof(mnptSpec[0]);
        
        if (AfxAcquireArena(sys->ctx, &sys->ioArena, NIL, AfxSpawnHint())) AfxThrowError();
        else
        {
            AfxAcquireChain(&sys->mountPoints, (void*)sys);
            AfxAcquireChain(&sys->aliveRsrcs, (void*)sys);

            if (!(mpCnt == (afxNat)AfxMountStoragePoints(mpCnt, mnptSpec))) AfxThrowError();
            else
            {
                afxUri128 uri2;
                AfxUri128(&uri2);
                AfxFormatUri(&uri2.uri, "system/e2coree.dll");

                if (AfxAcquireModules(1, &sys->e2coree, &uri2.uri)) AfxThrowError();
                else
                {
                    AfxAssertObjects(1, &sys->e2coree, afxFcc_MDLE);

                    afxNat mainKbdPort = { 0 };

                    if (AfxAcquireKeyboards(1, &mainKbdPort, &sys->stdKbd)) AfxThrowError();
                    else
                    {
                        AfxAssertObjects(1, &sys->stdKbd, afxFcc_KBD);
                        AfxAcquirePool(&sys->processors, sizeof(afxProcessor), sys->hwConcurrencyCap);

                        for (afxNat i = 0; i < sys->hwConcurrencyCap; i++)
                        {
                            if (AfxOccupyPoolUnit(&sys->processors, i, NIL)) AfxThrowError();
                            else
                            {
                                afxProcessor *procUnit;

                                if (!(AfxGetPoolUnit(&sys->processors, i, (void**)&procUnit))) AfxThrowError();
                                else
                                {
                                    procUnit->unitIdx = i;
                                    procUnit->activeThr = NIL;

                                    AfxGetClock(&procUnit->startClock);
                                    procUnit->lastClock = procUnit->startClock;
                                    procUnit->iterCntSwapClock = procUnit->lastClock;
                                    procUnit->iterCnt = 0;

                                    //AfxAcquireChain(&procUnit->threads, sys);

                                    afxNat tid = 0;
                                    void* osHandle = 0;

                                    if (i == 0)
                                    {
                                        tid;
                                        AfxGetThreadingId(&tid);
                                        osHandle = (void*)OpenThread(THREAD_QUERY_INFORMATION, NIL, tid);
                                        AfxGetClock(&procUnit->startClock);
                                    }
                                    else
                                    {
                                        if (!(osHandle = (void*)_beginthreadex(NIL, 0, (void*)startCbOnSysProcUnit, procUnit, /*CREATE_SUSPENDED*/0, &tid))) AfxThrowError();
                                        else
                                        {
                                            //AfxYieldThreading();
                                            //AfxAssert(osHandle == procUnit->osHandle); // GetCurrentThread returns pseudo-handle
                                            //AfxAssert(tid == procUnit->tid);
                                        }
                                    }

                                    procUnit->tid = tid;
                                    procUnit->osHandle = osHandle;
                                }
                            }
                        }

                        if (!err)
                        {
                            sys->operating = TRUE;
                            sys->interruptionRequested = FALSE;
                        }

                        if (err)
                            AfxReleaseObjects(1, (void*[]) { sys->stdKbd });

                    }
                }
            }

            if (err)
                AfxReleaseObjects(1, (void*[]) { sys->e2coree });
        }

        if (err)
        {
            AfxUriDeallocate(&sys->rootDir);

            AfxReleaseObjects(1, (void*[]) { sys->ctx });
        }
    }

    if (err)
        theSys = NIL; // undo our hack in failure cause

    return err;
}

_AFX afxError AfxBootUpBasicIoSystem(afxSystemConfig const *config, afxSystem *sys)
{
    afxError err = AFX_ERR_NONE;
    (void)_yhwhNisi;
#ifndef _AFX_DISABLE_DEBUGGER
    AfxAttachDebugger(NIL);
#endif

    if (AfxGetSystem(sys)) AfxThrowError();
    else
    {
        afxSystem sys1;
        AfxMountClass(&_sysClass, NIL, &_AfxSysClsConfig);

        if (AfxAcquireObjects(&_sysClass, 1, (afxHandle*)&sys1, (void*[]) { (void*)config })) AfxThrowError();
        else
        {
            *sys = (theSys = sys1);
        }
    }

    return err;
}

_AFX void AfxChooseBasicIoSystemConfiguration(afxSystemConfig *config, afxNat extendedSiz)
{
    afxError err = AFX_ERR_NONE;
    AfxAssert(config);
    AfxZero(config, AfxMaxi(extendedSiz, sizeof(*config)));

    SYSTEM_INFO si;
    GetSystemInfo(&si);
    config->maxHwThreads = si.dwNumberOfProcessors;
    config->memPageSiz = si.dwPageSize;
    config->allocGranularity = si.dwAllocationGranularity;
    config->genrlArenaSpace = config->memPageSiz;

    config->assertHook = AfxStdAssertHookCallback;
    config->unitsToMeter = 1;
    config->ioBufSiz = BUFSIZ;
    config->ioArenaSpace = config->memPageSiz;

    config->handlePageSiz = (config->memPageSiz * AFX_BYTE_SIZE) / 32; // ((config->memPageSiz / 4) * 32) / 32;

    config->root = NIL;
    config->profilerPopTimer = NIL;
    config->profilerPushTimer = NIL;
    config->profilerPostMarker = NIL;

    if (extendedSiz > sizeof(*config))
    {
#ifdef AFX_PLATFORM_WIN32
        afxSystemConfigWin32 *ext = AFX_REBASE(config, afxSystemConfigWin32, base);
        AfxAssert(extendedSiz == sizeof(*ext));
        ext->instance = GetModuleHandle(NULL);
        ext->hWnd = GetActiveWindow();
#endif
    }
}

_AFX afxClassConfig _AfxSysClsConfig =
{
    .fcc = afxFcc_SYS,
    .name = "Basic I/O System",
    .maxCnt = 1,
    .unitsPerPage = 1,
    .size = sizeof(AFX_OBJECT(afxSystem)),
    .ctx = NIL,
    .ctor = (void*)_AfxSysCtor,
    .dtor = (void*)_AfxSysDtor
};
