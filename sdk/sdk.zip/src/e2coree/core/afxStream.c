/*
 *          ::::::::  :::       :::     :::     :::::::::  :::::::::   ::::::::
 *         :+:    :+: :+:       :+:   :+: :+:   :+:    :+: :+:    :+: :+:    :+:
 *         +:+    +:+ +:+       +:+  +:+   +:+  +:+    +:+ +:+    +:+ +:+    +:+
 *         +#+    +:+ +#+  +:+  +#+ +#++:++#++: +#+    +:+ +#++:++#:  +#+    +:+
 *         +#+  # +#+ +#+ +#+#+ +#+ +#+     +#+ +#+    +#+ +#+    +#+ +#+    +#+
 *         #+#   +#+   #+#+# #+#+#  #+#     #+# #+#    #+# #+#    #+# #+#    #+#
 *          ###### ###  ###   ###   ###     ### #########  ###    ###  ########
 *
 *              T H E   Q W A D R O   E X E C U T I O N   E C O S Y S T E M
 *
 *                                   Public Test Build
 *                   (c) 2017 SIGMA Technology Group � Federa��o SIGMA
 *                                    www.sigmaco.org
 */

#include "afx/core/afxStream.h"
#include "afx/core/afxSystem.h"
#include "afx/core/afxContext.h"
#include "afx/core/afxString.h"
#include "afx/core/afxThread.h"

// AUXILIAR FUNCTIONS /////////////////////////////////////////////////////////

_AFX afxBool _AfxStandardTestStreamEndConditionCallback(afxStream* ios)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(ios, afxFcc_IOS);
    afxBool b = (ios->posn >= ios->len - 1);
    return b;
}

_AFX afxError _AfxStandardStreamMoveCursorCallback(afxStream* ios, afxInt offset, afxStreamOrigin origin)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(ios, afxFcc_IOS);

    if (origin == AFX_STRM_ORIGIN_BEGIN)
    {
        if (offset > (afxInt)ios->len) AfxThrowError();
        else ios->posn = offset;
    }
    else if (origin == AFX_STRM_ORIGIN_CURRENT)
    {
        if (offset > (afxInt)(ios->len - ios->posn)) AfxThrowError();
        else ios->posn += offset;
    }
    else if (origin == AFX_STRM_ORIGIN_END)
    {
        if (0 > ios->len - offset) AfxThrowError();
        else ios->posn = ios->len - offset;
    }
    else AfxThrowError();
    
    return err;
}

_AFX afxNat _AfxStandardStreamAskCursorCallback(afxStream* ios)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(ios, afxFcc_IOS);
    return ios->posn;
}

_AFX afxError _AfxStandardStreamWriteCallback(afxStream* ios, void const* const src, afxNat siz)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(ios, afxFcc_IOS);
    AfxAssert(siz);
    AfxAssert(src);
    afxNat clampedOffRange = siz;

    if ((siz > (ios->len - ios->posn)) && !ios->forked && !ios->isUserBuf) // if it is not a forked or user-buffered stream, we will try to enlarge it.
    {
        afxNat bufCap = AfxGetStreamBufferCap(ios);

        if (siz > (bufCap - ios->posn))
        {
            afxSize scaledSiz = bufCap + (siz - (bufCap - ios->posn));

            if (AfxResizeStreamBuffer(ios, scaledSiz))
                AfxThrowError();
        }
    }

    afxNat writeLen = siz;

    if (siz > (ios->len - ios->posn))
    {
        writeLen = ios->len - ios->posn;
        AfxThrowError();
    }

    AfxCopy((void*)AfxGetStreamData(ios, ios->posn), src, writeLen);
    clampedOffRange -= writeLen;
    ios->posn += writeLen;

    return clampedOffRange;
}

_AFX afxError _AfxStandardStreamReadCallback(afxStream* ios, void *dst, afxNat siz)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(ios, afxFcc_IOS);
    AfxAssert(siz);
    AfxAssert(dst);
    afxNat clampedOffRange = siz;

    afxNat readLen = siz;

    if (siz > ios->len - ios->posn)
    {
        readLen = ios->len - ios->posn;
        AfxThrowError();
    }

    AfxCopy(dst, AfxGetStreamData(ios, ios->posn), readLen);
    clampedOffRange -= readLen;
    ios->posn += readLen;

    return clampedOffRange;
}

// READ ONLY METHODS //////////////////////////////////////////////////////////

_AFXINL void const* AfxGetStreamData(afxStream const*ios, afxNat offset)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(ios, afxFcc_IOS);
    AfxAssert(offset < ios->len);

    if (ios->forked)
        return AfxGetStreamData(ios->src.parent, ios->src.base + offset);
    else
    {
        if (!ios->src.start)
            if (AfxResizeStreamBuffer((afxStream*)ios, ios->src.cap))
                AfxThrowError();

        return &(ios->src.start[offset]);
    }
};

_AFXINL afxNat AfxGetStreamLength(afxStream const *ios)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(ios, afxFcc_IOS);
    return ios->len;
};

_AFXINL afxNat AfxGetStreamBufferCap(afxStream const *ios)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(ios, afxFcc_IOS);
    return ios->forked ? AfxGetStreamBufferCap(ios->src.parent) : ios->src.cap;
};

_AFXINL afxBool AfxStreamIsReadOnly(afxStream const* ios)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(ios, afxFcc_IOS);
    return AfxFlagsTest(ios->flags, (AFX_IO_FLAG_R | ~AFX_IO_FLAG_W));
}

_AFXINL afxBool AfxStreamIsReadable(afxStream const* ios)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(ios, afxFcc_IOS);
    return AfxFlagsTest(ios->flags, AFX_IO_FLAG_R);
}

_AFXINL afxBool AfxStreamIsWriteable(afxStream const* ios)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(ios, afxFcc_IOS);
    return AfxFlagsTest(ios->flags, AFX_IO_FLAG_W);
}

_AFXINL afxBool AfxStreamIsExecutable(afxStream const* ios)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(ios, afxFcc_IOS);
    return AfxFlagsTest(ios->flags, AFX_IO_FLAG_X);
}

_AFX afxBool AfxTestStreamEndCondition(afxStream* ios)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(ios, afxFcc_IOS);
    return ios->ioctl.eos(ios);
}

_AFX afxError AfxResizeStreamBuffer(afxStream* ios, afxNat siz)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(ios, afxFcc_IOS);
    AfxAssert(siz);

    AfxAssert(!ios->isUserBuf);
    AfxAssert(!ios->forked);

    if (ios->isUserBuf || ios->forked) AfxThrowError();
    else
    {
        if ((siz > ios->src.cap) || (!ios->src.start))
        {
            afxArena* aren = AfxGetIoArena();
            AfxAssertType(aren, afxFcc_AREN);
            void const *oldData = ios->src.start;
            afxByte *start;
            afxNat alignedSiz;

            if (!siz)
            {
                alignedSiz = 0;
                start = NIL;
            }
            else
            {
                alignedSiz = AFX_ALIGN(siz, AfxGetIoBufferSize());                
                //void *start;

                if (!(start = AfxRequestArenaUnit(aren, alignedSiz))) AfxThrowError();
                else
                {
                    if (oldData)
                        AfxCopy(start, oldData, AfxGetStreamLength(ios));
                }
            }

            if (!err)
            {
                if (oldData)
                    AfxRecycleArenaUnit(aren, (void*)oldData, ios->src.cap);

                ios->src.cap = alignedSiz;
                ios->len = ios->src.cap;
                ios->src.start = start;

                if (ios->posn >= alignedSiz)
                    ios->posn = alignedSiz - 1;
            }
        }
    }
    return err;
}

_AFX afxError AfxSeekStream(afxStream* ios, afxInt offset, afxStreamOrigin origin)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(ios, afxFcc_IOS);
    AfxAssert(AfxFlagsTest(ios->flags, AFX_IO_FLAG_X));
    AfxAssertRange(origin, AFX_STRM_ORIGIN_BEGIN, AFX_STRM_ORIGIN_END);
    return ios->ioctl.seek(ios, offset, origin);
}

_AFX afxError AfxRecedeStream(afxStream* ios, afxInt range)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(ios, afxFcc_IOS);
    AfxAssert(AfxFlagsTest(ios->flags, AFX_IO_FLAG_X));
    AfxAssert(range);
    return ios->ioctl.seek(ios, -(range), AFX_STRM_ORIGIN_CURRENT);
}

_AFX afxError AfxSkipStream(afxStream* ios, afxInt range)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(ios, afxFcc_IOS);
    AfxAssert(AfxFlagsTest(ios->flags, AFX_IO_FLAG_X));
    AfxAssert(range);
    return ios->ioctl.seek(ios, range, AFX_STRM_ORIGIN_CURRENT);
}

_AFX afxError AfxGoToStreamEnd(afxStream* ios, afxInt offset)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(ios, afxFcc_IOS);
    AfxAssert(AfxFlagsTest(ios->flags, AFX_IO_FLAG_X));
    return ios->ioctl.seek(ios, offset, AFX_STRM_ORIGIN_END);
}

_AFX afxError AfxGoToStreamBegin(afxStream* ios, afxInt offset)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(ios, afxFcc_IOS);
    AfxAssert(AfxFlagsTest(ios->flags, AFX_IO_FLAG_X));
    return ios->ioctl.seek(ios, offset, AFX_STRM_ORIGIN_BEGIN);
}

_AFX afxNat AfxMeasureStream(afxStream* ios)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(ios, afxFcc_IOS);
    AfxAssert(AfxFlagsTest(ios->flags, AFX_IO_FLAG_X));
    afxNat curr = ios->ioctl.tell(ios);
    ios->ioctl.seek(ios, 0, AFX_STRM_ORIGIN_END);
    afxNat len = ios->ioctl.tell(ios);
    ios->ioctl.seek(ios, curr, AFX_STRM_ORIGIN_BEGIN);
    return len;
}

_AFX afxNat AfxAskStreamPosn(afxStream* ios)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(ios, afxFcc_IOS);
    afxNat cur = ios->ioctl.tell(ios);
    AfxAssert(cur == ios->posn);
    return cur;
}

_AFX afxError AfxCopyStreamRange(afxStream *out, afxStream *in, afxNat base, afxNat range, afxNat feedback)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(out, afxFcc_IOS);
    AfxAssert(AfxStreamIsWriteable(out));
    AfxAssertType(in, afxFcc_IOS);
    AfxAssert(AfxStreamIsReadable(in));
    afxArena *aren = AfxGetIoArena();
    AfxAssertType(aren, afxFcc_AREN);
    void *space = AfxRequestArenaUnit(aren, range);
    afxNat clampedOffRange = range;

    if (!space) AfxThrowError();
    else
    {
        if (AfxGoToStreamBegin(in, base)) AfxThrowError();
        else
        {
            afxNat batchSiz = feedback ? feedback : AfxGetIoBufferSize();
            afxNat batches = range / batchSiz;
            afxNat remain = range % batchSiz;
            afxNat nextSizR = 0, nextSizW = 0;
            afxNat errSiz = 0;

            for (afxNat i = 0; i < batches; i++)
            {
                nextSizR = batchSiz;

                if ((errSiz = AfxReadStream(in, space, nextSizR, feedback)))
                {
                    AfxThrowError();
                    nextSizW = nextSizR - errSiz;
                }
                else
                {
                    nextSizW = nextSizR;
                }
                
                if ((errSiz = AfxWriteStream(out, space, nextSizW, feedback)))
                {
                    AfxThrowError();
                    nextSizW -= errSiz;
                }

                clampedOffRange -= nextSizW;

                if (err)
                    break;
            }

            if (!err)
            {
                nextSizR = remain;

                if ((errSiz = AfxReadStream(in, space, nextSizR, feedback)))
                {
                    AfxThrowError();
                    nextSizW -= errSiz;
                }
                else
                {
                    nextSizW = nextSizR;
                }

                if ((errSiz = AfxWriteStream(out, space, nextSizW, feedback)))
                {
                    AfxThrowError();
                    nextSizW -= errSiz;
                }
                clampedOffRange -= nextSizW;
            }
        }
        AfxRecycleArenaUnit(aren, space, range);
    }
    return clampedOffRange;
}

_AFX afxError AfxCopyStream(afxStream *out, afxStream *in, afxNat feedback)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(out, afxFcc_IOS);
    AfxAssert(AfxStreamIsWriteable(out));
    AfxAssertType(in, afxFcc_IOS);
    AfxAssert(AfxStreamIsReadable(in));
    afxNat clampedOffRange = AfxMeasureStream(in);

    if ((clampedOffRange = AfxCopyStreamRange(out, in, 0, clampedOffRange, feedback)))
        AfxThrowError();

    return clampedOffRange;
}

_AFX afxError AfxWriteStream(afxStream* ios, void const* src, afxNat len, afxNat feedback)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(ios, afxFcc_IOS);
    AfxAssert(AfxStreamIsWriteable(ios));
    AfxAssert(len);
    AfxAssert(src);
    afxNat clampedOffRange = len;

    if (feedback)
    {
        afxByte const *bytemap = src;
        afxNat batchSiz = feedback ? feedback : AfxGetIoBufferSize();
        afxNat batches = len / batchSiz;
        afxNat remain = len % batchSiz;
        afxNat nextSiz = 0;
        afxNat nextOff = 0;
        afxNat errSiz = 0;

        for (afxNat i = 0; i < batches; i++)
        {
            nextSiz = batchSiz;

            if ((errSiz = ios->ioctl.write(ios, &bytemap[nextOff], nextSiz)))
            {
                AfxThrowError();
                nextSiz -= errSiz;
            }

            nextOff += nextSiz;
            clampedOffRange -= nextSiz;

            if (ios->ioctl.writeFeedback)
                ios->ioctl.writeFeedback(ios, nextSiz, ios->idd);

            if (err)
                break;
        }

        if (!err && remain)
        {
            nextSiz = remain;

            if (!(errSiz = ios->ioctl.write(ios, &bytemap[nextOff], nextSiz)))
            {
                AfxThrowError();
                nextSiz -= errSiz;
            }

            clampedOffRange -= nextSiz;

            if (ios->ioctl.writeFeedback)
                ios->ioctl.writeFeedback(ios, nextSiz, ios->idd);
        }
    }
    else
    {
        if ((clampedOffRange = ios->ioctl.write(ios, src, len)))
            AfxThrowError();
    }
    return clampedOffRange;
}

_AFX afxError AfxWriteStreamAt(afxStream* ios, afxNat offset, void const *src, afxNat len, afxNat feedback)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(ios, afxFcc_IOS);
    AfxAssert(AfxStreamIsWriteable(ios));
    AfxAssert(len);
    AfxAssert(src);
    afxNat clampedOffRange = len;

    if (AfxSeekStream(ios, offset, AFX_STRM_ORIGIN_BEGIN)) AfxThrowError();
    else if ((clampedOffRange = AfxWriteStream(ios, src, len, feedback)))
        AfxThrowError();

    return clampedOffRange;
}

_AFX afxError AfxReadStream(afxStream* ios, void *dst, afxNat len, afxNat feedback)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(ios, afxFcc_IOS);
    AfxAssert(AfxStreamIsReadable(ios));
    AfxAssert(len);
    AfxAssert(dst);
    afxNat clampedOffRange = len;

    if (feedback)
    {
        afxByte *bytemap = dst;
        afxNat batchSiz = feedback ? feedback : AfxGetIoBufferSize();
        afxNat batches = len / batchSiz;
        afxNat remain = len % batchSiz;
        afxNat nextSiz = 0;
        afxNat nextOff = 0;
        afxNat errSiz = 0;

        for (afxNat i = 0; i < batches; i++)
        {
            nextSiz = batchSiz;

            if ((errSiz = ios->ioctl.read(ios, &bytemap[nextOff], nextSiz)))
            {
                AfxThrowError();
                nextSiz -= errSiz;
            }

            nextOff += nextSiz;
            clampedOffRange -= nextSiz;

            if (ios->ioctl.readFeedback)
                ios->ioctl.readFeedback(ios, nextSiz, ios->idd);

            if (err)
                break;
        }

        if (!err && remain)
        {
            nextSiz = remain;

            if (!(errSiz = ios->ioctl.read(ios, &bytemap[nextOff], nextSiz)))
            {
                AfxThrowError();
                nextSiz -= errSiz;
            }

            clampedOffRange -= nextSiz;

            if (ios->ioctl.readFeedback)
                ios->ioctl.readFeedback(ios, nextSiz, ios->idd);
        }
    }
    else
    {
        if ((clampedOffRange = ios->ioctl.read(ios, dst, len)))
            AfxThrowError();
    }
    return clampedOffRange;
}

_AFX afxError AfxReadStreamAt(afxStream* ios, afxNat offset, void *dst, afxNat len, afxNat feedback)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(ios, afxFcc_IOS);
    AfxAssert(AfxStreamIsReadable(ios));
    AfxAssert(len);
    AfxAssert(dst);
    afxNat clampedOffRange = len;

    if (AfxSeekStream(ios, offset, AFX_STRM_ORIGIN_BEGIN)) AfxThrowError();
    else if ((clampedOffRange = AfxReadStream(ios, dst, len, feedback)))
        AfxThrowError();

    return clampedOffRange;
}

_AFX afxError AfxForkStreamRange(afxStream* ios, afxStream* parent, afxNat offset, afxNat range)
{
    afxError err = AFX_ERR_NONE;
    AfxEntry("fork=%p,parent=%p,offset=%x,range=%u", ios, parent, offset, range);
    AfxAssertType(parent, afxFcc_IOS);
    AfxAssertRange(parent->len, offset, range);

    afxNat maxRange = parent->len;
    afxNat effectiveRange = range > maxRange ? maxRange : range;
    AfxAssert(effectiveRange == range);

    AfxAssert(ios);
    AfxAssignTypeFcc(ios, afxFcc_IOS);
    ios->len = effectiveRange;
    ios->forked = TRUE;
    ios->src.base = offset;
    ios->src.parent = parent;
    ios->isUserBuf = FALSE;
    ios->posn = 0;

    ios->flags = parent->flags;

    ios->ioctl = parent->ioctl;

    ios->dtor = parent->dtor;
    ios->idd = parent->idd;

    return range - effectiveRange;
}

_AFX afxError AfxForkStream(afxStream* ios, afxStream* parent)
{
    afxError err = AFX_ERR_NONE;
    AfxEntry("ios=%p,parent=%p", ios, parent);
    AfxAssertType(parent, afxFcc_IOS);
    afxError clampedOffLen = 0;

    if ((clampedOffLen = AfxForkStreamRange(ios, parent, 0, parent->len)))
        AfxThrowError();

    return clampedOffLen;
}

_AFX afxError AfxAcquireStream(afxStream *ios, afxIoFlags flags, void *start, afxNat len)
{
    afxError err = AFX_ERR_NONE;
    AfxEntry("ios=%p,flags=%x,start=%p,len=%u", ios, flags, start, len);
    AfxAssert(ios);

    afxArena* aren = AfxGetIoArena();
    AfxAssertType(aren, afxFcc_AREN);

    AfxAssignTypeFcc(ios, afxFcc_IOS);
    ios->flags = flags ? flags : AFX_IO_FLAG_RWX;

    ios->len = len ? len : AfxGetIoBufferSize();
    ios->posn = 0;
    ios->src.start = start;
    ios->isUserBuf = !!start;
    ios->forked = FALSE;
    ios->src.cap = ios->len;

    ios->ioctl.read = _AfxStandardStreamReadCallback;
    ios->ioctl.readFeedback = NIL;
    ios->ioctl.write = _AfxStandardStreamWriteCallback;
    ios->ioctl.writeFeedback = NIL;
    ios->ioctl.seek = _AfxStandardStreamMoveCursorCallback;
    ios->ioctl.eos = _AfxStandardTestStreamEndConditionCallback;
    ios->ioctl.tell = _AfxStandardStreamAskCursorCallback;
    ios->dtor = NIL;
    ios->idd = NIL;

    return err;
}

_AFX afxError AfxAcquireInputStream(afxStream *in, void const *start, afxNat len)
{
    afxError err = AFX_ERR_NONE;
    AfxEntry("ios=%p,start=%p,len=%u", in, start, len);
    AfxAssertType(in, afxFcc_IOS);

    if (AfxAcquireStream(in, AFX_IO_FLAG_RX, (void*)start, len))
        AfxThrowError();

    return err;
}

_AFX afxError AfxAcquireOutputStream(afxStream *out, void *start, afxNat len)
{
    afxError err = AFX_ERR_NONE;
    AfxEntry("ios=%p,start=%p,len=%u", out, start, len);
    AfxAssertType(out, afxFcc_IOS);

    if (AfxAcquireStream(out, AFX_IO_FLAG_WX, start, len))
        AfxThrowError();

    return err;
}

_AFX void AfxReleaseStream(afxStream* ios)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(ios, afxFcc_IOS);

    if (ios->dtor)
        ios->dtor(ios);

    if (!ios->forked && ios->isUserBuf && ios->src.start)
    {
        AfxResizeStreamBuffer(ios, 0);
    }
}
