/*
 *          ::::::::  :::       :::     :::     :::::::::  :::::::::   ::::::::
 *         :+:    :+: :+:       :+:   :+: :+:   :+:    :+: :+:    :+: :+:    :+:
 *         +:+    +:+ +:+       +:+  +:+   +:+  +:+    +:+ +:+    +:+ +:+    +:+
 *         +#+    +:+ +#+  +:+  +#+ +#++:++#++: +#+    +:+ +#++:++#:  +#+    +:+
 *         +#+  # +#+ +#+ +#+#+ +#+ +#+     +#+ +#+    +#+ +#+    +#+ +#+    +#+
 *         #+#   +#+   #+#+# #+#+#  #+#     #+# #+#    #+# #+#    #+# #+#    #+#
 *          ###### ###  ###   ###   ###     ### #########  ###    ###  ########
 *
 *              T H E   Q W A D R O   E X E C U T I O N   E C O S Y S T E M
 *
 *                                   Public Test Build
 *                   (c) 2017 SIGMA Technology Group � Federa��o SIGMA
 *                                    www.sigmaco.org
 */

#include "afx/core/afxArray.h"
#include "afx/core/afxSystem.h"

#if !0

_AFXINL afxNat AfxGetArrayCap(afxArray const *arr)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(arr, afxFcc_ARR);
    return arr->cap;
}

_AFXINL afxNat AfxCountArrayElements(afxArray const *arr)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(arr, afxFcc_ARR);
    return arr->cnt;
}

_AFXINL void AfxArraySetPop_(afxArray *arr, afxNat pop)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(arr, afxFcc_ARR);
    AfxAssert(arr->cap >= pop);
    arr->cnt = pop;
}

_AFXINL afxBool AfxArrayIsFull(afxArray const *arr)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(arr, afxFcc_ARR);
    return arr->cnt == arr->cap;
}

// AfxArrayIsEmpty() - Checks if the container has no elements, i.e. whether begin() == end().

_AFXINL afxBool AfxArrayIsEmpty(afxArray const *arr)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(arr, afxFcc_ARR);
    return !arr->cnt;
}

// AfxEmptyArray() - Erases mem elements from the container. After this call, size() returns zero.

// Invalidates any references, pointers, or iterators referring to contained elements.Any past - the - end iterators are also invalidated.

// Leaves the capacity() of the vector unchanged(note: the standard's restriction on the changes to capacity is in the specification of vector::reserve, see [1])

_AFXINL void AfxEmptyArray(afxArray *arr)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(arr, afxFcc_ARR);
    arr->cnt = 0;
}

_AFXINL void AfxFillArrayRange(afxArray *arr, afxNat first, afxNat cnt, void* val)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(arr, afxFcc_ARR);
    AfxAssertRange(arr->cnt, first, cnt);
    AfxReserveArraySpace(arr, first + cnt);
    AfxFill(&arr->bytemap[first * arr->unitSiz], cnt, arr->unitSiz, val);
}

_AFXINL void AfxFillArray(afxArray *arr, void* val)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(arr, afxFcc_ARR);
    arr->cnt = arr->cap;
    AfxFillArrayRange(arr, 0, arr->cap, val);
}

_AFXINL void AfxZeroArrayRange(afxArray *arr, afxNat firstUnit, afxNat unitCnt)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(arr, afxFcc_ARR);
    AfxAssertRange(arr->cnt, firstUnit, unitCnt);
    AfxReserveArraySpace(arr, firstUnit + unitCnt);
    AfxZero(&arr->bytemap[firstUnit * arr->unitSiz], arr->unitSiz * unitCnt);
}

_AFXINL void AfxZeroArray(afxArray *arr)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(arr, afxFcc_ARR);    
    arr->cnt = arr->cap;
    AfxZeroArrayRange(arr, 0, arr->cnt);
}

_AFXINL void AfxReleaseArray(afxArray *arr)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(arr, afxFcc_ARR);
    AfxAssignTypeFcc(arr, 0);

    afxContext mem = AfxGetSystemContext();

    if (arr->bytemap)
        AfxDeallocate(mem, arr->bytemap);

    arr->bytemap = NIL;
    arr->mem = NIL;
}

_AFXINL void AfxAcquireArray(afxArray *arr, afxNat unitSiz, afxNat cap, afxHint const hint)
{
    afxError err = AFX_ERR_NONE;
    AfxAssert(arr);
    AfxAssert(unitSiz);
    AfxAssignTypeFcc(arr, afxFcc_ARR);
    arr->cap = cap;
    arr->cnt = 0;
    arr->unitSiz = unitSiz;
    arr->mem = NIL;
    arr->bytemap = NIL;
}

// AfxOptimizeArray() - Requests the removal of unused capacity.

// It is a non - binding request to reduce capacity() to size().It depends on the implementation whether the request is fulfilled.

// If reallocation occurs, mem iterators, including the past the end iterator, and mem references to the elements are invalidated.
// If no reallocation takes place, no iterators or references are invalidated.

_AFXINL afxError AfxOptimizeArray(afxArray *arr)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(arr, afxFcc_ARR);
    AfxError("To be implemented. Should release unused reserved memory.");
    AfxThrowError();
    return err;
}

// AfxReserveArraySpace() - Increase the capacity of the vector (the total number of elements that the vector canv hold without requiring reallocation) to a value that's greater or equal to newcap.
// If newcap is greater than the current capacity(), new storage is allocated, otherwise the function does nothing.

// reserve() does not change the size of the vector.

// If newcap is greater than capacity(), mem iterators, including the past -the- end iterator, and mem references to the elements are invalidated. Otherwise, no iterators or references are invalidated.

_AFXINL afxError AfxReserveArraySpace(afxArray *arr, afxNat cap)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(arr, afxFcc_ARR);
    AfxAssert(cap);

    if ((cap > arr->cap) || !arr->bytemap)
    {
        afxContext mem = AfxGetSystemContext();

        afxByte *p;

        if (!(p = AfxReallocate(mem, arr->bytemap, cap * arr->unitSiz, 0, AfxSpawnHint()) /*AfxReallocate(&((afxSize *)(*arr))[-2], (siz), AfxSpawnHint())*/)) AfxThrowError();
        else
        {
            arr->cap = cap;
            arr->bytemap = (afxByte*)p;
        }
    }
    return err;
}

_AFXINL void* AfxGetArrayUnit(afxArray const *arr, afxNat unitIdx)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(arr, afxFcc_ARR);
    AfxAssertRange(arr->cnt, unitIdx, 1);
    //AfxReserveArraySpace((void*)arr, unitIdx + 1);
    return &(arr->bytemap[unitIdx * arr->unitSiz]);
}

_AFXINL void* AfxGetLastArrayUnit(afxArray const *arr)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(arr, afxFcc_ARR);
    return arr->cnt ? &(arr->bytemap[(arr->cnt - 1) * arr->unitSiz]) : NIL;
}

_AFXINL void AfxUpdateArrayRange(afxArray *arr, afxNat firstUnit, afxNat unitCnt, void const* src)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(arr, afxFcc_ARR);
    AfxAssertRange(arr->cnt, firstUnit, unitCnt);
    AfxAssert(src);
    AfxCopy(&(arr->bytemap[firstUnit * arr->unitSiz]), src, unitCnt * arr->unitSiz);
}

_AFXINL void AfxUpdateArray(afxArray *arr, void const* src)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(arr, afxFcc_ARR);
    AfxAssert(src);
    AfxUpdateArrayRange(arr, 0, arr->cnt, src);
}

_AFXINL void AfxDumpArrayRange(afxArray const* arr, afxNat firstUnit, afxNat unitCnt, void *dst)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(arr, afxFcc_ARR);
    AfxAssertRange(arr->cnt, firstUnit, unitCnt);
    AfxAssert(dst);
    AfxCopy(dst, &arr->bytemap[firstUnit * arr->unitSiz], unitCnt * arr->unitSiz);
}

_AFXINL void AfxDumpArray(afxArray const* arr, void *dst)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(arr, afxFcc_ARR);
    AfxAssert(dst);
    AfxDumpArrayRange(arr, 0, arr->cnt, dst);
}

_AFXINL void* AfxInsertArrayUnits(afxArray *arr, afxNat cnt, afxNat *firstIdx, void const *initialVal)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(arr, afxFcc_ARR);
    AfxAssert(cnt);

    if (AfxArrayIsFull(arr) || !arr->bytemap)
        if (AfxReserveArraySpace(arr, arr->cnt + cnt))
            AfxThrowError();

    afxNat baseIdx = arr->cnt;

    if (firstIdx)
        *firstIdx = err ? AFX_INVALID_INDEX : baseIdx;
    
    afxByte *base = err ? NIL : &arr->bytemap[baseIdx * arr->unitSiz];

    if (!err)
    {
        if (!initialVal)
            AfxZero(base, cnt * arr->unitSiz);
        else
            AfxFill(base, cnt, arr->unitSiz, initialVal);

        arr->cnt += cnt;
    }
    return base;
}

_AFXINL void* AfxInsertArrayUnit(afxArray *arr, afxNat *idx)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(arr, afxFcc_ARR);
    void *ptr;

    if (!(ptr = AfxInsertArrayUnits(arr, 1, idx, NIL)))
        AfxThrowError();

    return ptr;
}

_AFXINL afxError AfxAddArrayUnits(afxArray *arr, afxNat cnt, void const* src, afxNat srcStride, afxNat *firstIdx)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(arr, afxFcc_ARR);
    AfxAssert(cnt);
    *firstIdx = AFX_INVALID_INDEX;

    if (AfxArrayIsFull(arr) || !arr->bytemap)
        if (AfxReserveArraySpace(arr, arr->cnt + cnt))
            AfxThrowError();

    if (!err)
    {
        *firstIdx = arr->cnt;

        afxByte* map = &arr->bytemap[arr->cnt * arr->unitSiz];

        if (!src)
        {
            AfxZero(map, cnt * arr->unitSiz);
        }
        else
        {
            AfxAssert(srcStride);

            if (srcStride == arr->unitSiz)
            {
                AfxCopy(map, src, (cnt * arr->unitSiz));
            }
            else
            {
                afxByte const *src2 = src;

                for (afxNat i = 0; i < cnt; i++)
                {
                    AfxCopy(&(map[i * arr->unitSiz]), &(src2[i * srcStride]), arr->unitSiz);
                }
            }
        }
        arr->cnt += cnt;
    }
    return err;
}

_AFXINL afxError AfxUpdateArrayUnits(afxArray *arr, afxNat base, afxNat cnt, void const* src, afxNat srcStride)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(arr, afxFcc_ARR);
    AfxAssert(srcStride);

    afxByte* map = &arr->bytemap[base * arr->unitSiz];

    if (srcStride == arr->unitSiz)
    {
        AfxCopy(map, src, (cnt * arr->unitSiz));
    }
    else
    {
        afxByte const *src2 = src;

        for (afxNat i = 0; i < cnt; i++)
        {
            AfxCopy(&(map[i * arr->unitSiz]), &(src2[i * srcStride]), arr->unitSiz);
        }
    }

    return err;
}

_AFXINL afxNat AfxArrayFetchElement(afxArray *arr, void const **elem)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(arr, afxFcc_ARR);
    afxNat idx = AFX_INVALID_INDEX;

    if (AfxArrayIsFull(arr) || !arr->bytemap)
        if (AfxReserveArraySpace(arr, arr->cap + 1))
            AfxThrowError();

    if (!err)
    {
        if (elem)
        {
            *elem = &(arr->bytemap[arr->cnt * arr->unitSiz]);
        }

        if (!err)
        {
            idx = arr->cnt;
            arr->cnt++;
        }
    }
    return idx;
}

_AFXINL afxNat AfxArrayFetchElements(afxArray *arr, afxNat cnt, void const *elem[])
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(arr, afxFcc_ARR);
    AfxAssert(cnt);
    afxNat idx = AFX_INVALID_INDEX;

    if (AfxArrayIsFull(arr) || !arr->bytemap)
        if (AfxReserveArraySpace(arr, arr->cap + cnt))
            AfxThrowError();

    if (!err)
    {
        if (elem)
        {
            *elem = &(arr->bytemap[arr->cnt * arr->unitSiz]);
        }

        if (!err)
        {
            idx = arr->cnt;
            arr->cnt++;
        }
    }
    return idx;
}

// AfxArrayEraseElement() - Erases the specified elements from the container.
//  - 1) Removes the element at pos.
// Invalidates iterators and references at or after the point of the erase, including the end() iterator.

// The iterator pos must be valid and dereferenceable.Thus the end() iterator(which is valid, but is not dereferenceable) cannot be used as a value for pos.

// The iterator first does not need to be dereferenceable if first == last: erasing an empty range is a no - op.

_AFXINL afxResult AfxArrayForEachElement(afxArray *arr, afxResult(*f)(void *arrel, void *data), void *data)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(arr, afxFcc_ARR);
    AfxAssert(f);
    afxResult cnt = 0;

    for (afxNat i = 0; i < arr->cnt; i++)
    {
        void *arrel = AfxGetArrayUnit(arr, i);

        cnt++;

        if (!(f(arrel, data)))
            break;
    }
    return cnt;
}

_AFXINL afxError AfxAppendArray(afxArray *arr, afxArray const *src)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(arr, afxFcc_ARR);
    AfxAssertType(src, afxFcc_ARR);
    afxNat idx;

    if (AfxAddArrayUnits(arr, arr->cnt, arr->bytemap, arr->unitSiz, &idx))
        AfxThrowError();

    return err;
}

// AfxSwapArray() - Exchanges the contents of the container with those of other.Does not invoke any move, copy, or swap operations on individual elements.
// All iterators and references remain valid. The past-the-end iterator is invalidated.

_AFXINL afxError AfxSwapArray(afxArray *arr, afxArray *other)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(arr, afxFcc_ARR);
    AfxAssertType(other, afxFcc_ARR);

    afxNat32 stride = other->unitSiz, cap = other->cap, pop = other->cnt;
    afxByte *bytemap = other->bytemap;
    
    other->unitSiz = arr->unitSiz;
    other->cap = arr->cap;
    other->cnt = arr->cnt;
    other->bytemap = arr->bytemap;

    arr->unitSiz = stride;
    arr->cap = cap;
    arr->cnt = pop;
    arr->bytemap = bytemap;

    return err;
}

#endif
