/*
 *          ::::::::  :::       :::     :::     :::::::::  :::::::::   ::::::::
 *         :+:    :+: :+:       :+:   :+: :+:   :+:    :+: :+:    :+: :+:    :+:
 *         +:+    +:+ +:+       +:+  +:+   +:+  +:+    +:+ +:+    +:+ +:+    +:+
 *         +#+    +:+ +#+  +:+  +#+ +#++:++#++: +#+    +:+ +#++:++#:  +#+    +:+
 *         +#+  # +#+ +#+ +#+#+ +#+ +#+     +#+ +#+    +#+ +#+    +#+ +#+    +#+
 *         #+#   +#+   #+#+# #+#+#  #+#     #+# #+#    #+# #+#    #+# #+#    #+#
 *          ###### ###  ###   ###   ###     ### #########  ###    ###  ########
 *
 *              T H E   Q W A D R O   E X E C U T I O N   E C O S Y S T E M
 *
 *                                   Public Test Build
 *                   (c) 2017 SIGMA Technology Group � Federa��o SIGMA
 *                                    www.sigmaco.org
 */

#include "afx/core/afxClass.h"
#include "afx/core/afxInstance.h"
#include "afx/core/afxThread.h"
#include "afx/core/afxContext.h"

_AFX afxBool metaObjectMgrInited = FALSE;
_AFX afxChain orphanClassChain =
{
    {
        &(orphanClassChain.anchor),
        &(orphanClassChain.anchor),
        &(orphanClassChain)
    },
    { NIL },
    0
};

_AFX afxResult _AfxUninstallChainedClasses(afxChain *provisions)
{
    afxError err = AFX_ERR_NONE;
    afxResult cnt = 0;

    while (1)
    {
        afxLinkage *first = AfxGetLastLinkage(provisions);

        if (!first) break;
        else
        {
            afxClass *cls = AFX_REBASE(first, afxClass, provider);
            AfxAssertType(cls, afxFcc_CLS);
            ++cnt;

            if (cls->objFcc != afxFcc_SYS)
                AfxDismountClass(cls);
            else if (provisions->cnt == 1) // has only the SYS. We can't drop it or will shit the entire platform. Break.
                break;
        }
    }
    return cnt;
}

_AFX afxResult _AfxShutdownOrphanClasses(void)
{
    return _AfxUninstallChainedClasses(&orphanClassChain);
}

_AFX void AfxClassLockInclusive(afxClass *cls)
{
    AfxEnterSlockShared(&cls->slock);
}

_AFX void AfxClassLockExclusive(afxClass *cls)
{
    AfxEnterSlockExclusive(&cls->slock);
}

_AFX void AfxClassUnlockInclusive(afxClass *cls)
{
    AfxExitSlockShared(&cls->slock);
}

_AFX void AfxClassUnlockExclusive(afxClass *cls)
{
    AfxExitSlockExclusive(&cls->slock);
}

_AFX afxBool AfxClassTryLockInclusive(afxClass *cls)
{
    return AfxTryEnterSlockShared(&cls->slock);
}

_AFX afxBool AfxClassTryLockExclusive(afxClass *cls)
{
    return AfxTryEnterSlockExclusive(&cls->slock);
}

_AFXINL afxClass* AfxGetBaseClass(afxClass const *cls)
{
    afxError err = AFX_ERR_NONE;
    AfxAssert(cls);
    AfxAssertType(cls, afxFcc_CLS);
    return cls->base.chain ? cls->base.chain->owner : NIL;
}

_AFXINL void const* AfxClassGetVmt(afxClass const *cls)
{
    afxError err = AFX_ERR_NONE;
    AfxAssert(cls);
    AfxAssertType(cls, afxFcc_CLS);
    return cls->vmt;
}

_AFXINL afxNat AfxGetInstanceSize(afxClass const *cls)
{
    afxError err = AFX_ERR_NONE;
    AfxAssert(cls);
    AfxAssertType(cls, afxFcc_CLS);
    return cls->siz;
}

_AFXINL afxNat AfxGetInstanceAddedSsize(afxClass const *cls)
{
    afxError err = AFX_ERR_NONE;
    AfxAssert(cls);
    AfxAssertType(cls, afxFcc_CLS);
    afxClass *base = AfxGetBaseClass(cls);
    return (base ? cls->siz - base->siz : cls->siz);
}

_AFXINL afxNat AfxCountInstances(afxClass const *cls)
{
    afxError err = AFX_ERR_NONE;
    AfxAssert(cls);
    AfxAssertType(cls, afxFcc_CLS);
    return cls->pool.totalUsedCnt;
}

_AFXINL afxBool AfxGetInstance(afxClass const* cls, afxNat32 uniqueId, afxHandle* obj)
{
    afxError err = AFX_ERR_NONE;
    AfxAssert(cls);
    AfxAssertType(cls, afxFcc_CLS);
    //return AfxGetPoolUnit(&cls->pool, uniqueId, obj);
    return AfxEnumerateInstances(cls, uniqueId, 1, obj);
}

_AFXINL afxNat _AfxClsEnumerateInstances(afxClass const* cls, afxBool fromLast, afxNat first, afxNat cnt, afxHandle obj[])
{
    afxError err = AFX_ERR_NONE;
    AfxAssert(cls);
    AfxAssertType(cls, afxFcc_CLS);
    afxNat rslt = 0;

    rslt = AfxEnumeratePoolItems(&cls->pool, first, cnt, (void**)obj);

    if (rslt)
    {
        for (afxNat i = 0; i < rslt; i++)
        {
            afxInstance* inst = obj[i];
            AfxAssertType(inst, afxFcc_OBJ);
            //afxModule inst2 = (inst + 1);
            //AfxAssertObjects(1, &inst2, cls->objFcc);
            obj[i] = (inst + 1);
            AfxAssertObjects(1, &obj[i], cls->objFcc);
        }
    }

    if (rslt < cnt)
    {
        afxChain const *supersets = &cls->deriveds;

        afxClass *superset;
        AfxChainForEveryLinkage(supersets, afxClass, base, superset)
        {
            AfxAssertType(superset, afxFcc_CLS);

            if (0 == superset->pool.totalUsedCnt) continue;
            else
            {
                rslt += _AfxClsEnumerateInstances(superset, fromLast, rslt - first, cnt - rslt, &obj[rslt]);

                if (rslt == cnt)
                    break;
            }
        }
    }

    return rslt;
}

_AFXINL afxNat AfxEnumerateInstances(afxClass const* cls, afxNat first, afxNat cnt, afxHandle obj[])
{
    afxError err = AFX_ERR_NONE;
    AfxAssert(cls);
    AfxAssertType(cls, afxFcc_CLS);
    AfxClassLockInclusive((afxClass*)cls);
    afxNat rslt = _AfxClsEnumerateInstances(cls, FALSE, first, cnt, obj);
    AfxClassUnlockInclusive((afxClass*)cls);
    return rslt;
}

_AFXINL afxNat _AfxClsCurateInstances(afxClass const* cls, afxBool fromLast, afxNat first, afxNat cnt, afxBool(*f)(afxHandle obj, void *udd), void *udd)
{
    afxError err = AFX_ERR_NONE;
    AfxAssert(cls);
    AfxAssertType(cls, afxFcc_CLS);
    AfxAssert(f);
    afxNat rslt = 0;

    afxNat i = 0, posn = 0;
    afxHandle obj;
    while (_AfxClsEnumerateInstances(cls, fromLast, i, 1, &obj))
    {
        AfxAssertObjects(1, &obj, cls->objFcc);

        if (posn >= first)
        {
            ++rslt;


            if (f(obj, udd))
                break;
        }
        ++posn;
        ++i;

        if (i == cnt)
            break;
    }

    if (rslt < cnt)
    {
        afxChain const *supersets = &cls->deriveds;

        afxClass *superset;
        AfxChainForEveryLinkage(supersets, afxClass, base, superset)
        {
            AfxAssertType(superset, afxFcc_CLS);

            if (0 == superset->pool.totalUsedCnt) continue;
            else
            {
                rslt += _AfxClsCurateInstances(superset, fromLast, rslt - first, cnt - rslt, f, udd);

                if (rslt == cnt)
                    break;
            }
        }
    }

    return rslt;
}

AFXINL afxNat AfxCurateInstances(afxClass const* cls, afxNat first, afxNat cnt, afxBool(*f)(afxHandle obj, void *udd), void *udd)
{
    afxError err = AFX_ERR_NONE;
    AfxAssert(cls);
    AfxAssertType(cls, afxFcc_CLS);
    AfxClassLockInclusive((afxClass*)cls);
    afxNat rslt = _AfxClsCurateInstances(cls, FALSE, first, cnt, f, udd);
    AfxClassUnlockInclusive((afxClass*)cls);
    return rslt;
}

#if 0
_AFXINL afxError AfxClassDeallocateObjects(afxClass *cls, afxNat cnt, afxHandle obj[])
{
    afxError err = AFX_ERR_NONE;
    AfxAssert(cls);
    AfxAssertType(cls, afxFcc_CLS);
    AfxAssert(cnt);
    AfxAssert(obj);
    AfxEcho("afxClass<%s>::DeallocateObjects(%d, %p)", cls->name, cnt, obj);
    
    for (afxNat i = 0; i < cnt; i++)
    {
        afxInstance *item = (afxInstance *)obj[i];
        AfxAssert(item);
        --item;
        AfxDeallocatePoolUnit(&cls->pool, item->instIdx);
    }
    return err;
}

_AFXINL afxError AfxClassAllocateObjects(afxClass *cls, afxNat cnt, afxHandle obj[])
{
    afxError err = AFX_ERR_NONE;
    AfxAssert(cls);
    AfxAssertType(cls, afxFcc_CLS);
    AfxAssert(cnt);
    AfxEcho("afxClass<%s>::AllocateObjects(%d, %p, %p)", cls->name, cnt, obj);
    
    if (cls->maxInstCnt && ((cls->maxInstCnt - cls->pool.totalUsedCnt) == 0)) AfxThrowError();
    else
    {
        for (afxNat i = 0; i < cnt; i++)
        {
            afxInstance* ptr;
            afxSize idx;
            AfxAllocatePoolUnit(&cls->pool, &idx);
            AfxGetPoolUnit(&cls->pool, idx, (void**)&ptr);
            ptr->instIdx = idx;
            obj[i] = (afxHandle)(ptr + 1);

            if (err)
            {
                if (i > 0)
                    AfxClassDeallocateObjects(cls, i, obj);

                break;
            }
        }
    }
    return err;
}
#endif

_AFXINL afxError _AfxClsRunSubsetDtor(afxClass *cls, afxHandle obj)
{
    afxError err = AFX_ERR_NONE;
    AfxAssert(cls);
    AfxAssertType(cls, afxFcc_CLS);

    AfxEcho("Destructing instance %p of %s class.", obj, cls->name);

    if (cls->dtor && cls->dtor(obj))
        AfxThrowError();

    if (cls->base.chain)
    {
        AfxEcho("Destructing instance %p of %s : %s class.", obj, cls->name, ((afxClass*)cls->base.chain->owner)->name);

        if (_AfxClsRunSubsetDtor(cls->base.chain->owner, obj))
            AfxThrowError();
    }

    return err;
}

_AFX afxError AfxClassDismantleObjects(afxClass *cls, afxNat cnt, afxHandle obj[])
{
    afxError err = AFX_ERR_NONE;
    AfxAssert(cls);
    AfxAssertType(cls, afxFcc_CLS);
    AfxAssert(cnt);
    AfxAssert(obj);
 
    for (afxNat i = cnt; i-- > 0;)
    {
        afxHandle item = obj[i];
        AfxEcho("Dismantling %s object (#%d) %p...", cls->name, i, obj[i]);
        afxInstance *itemD = (afxInstance *)item;
        --itemD;
        AfxAssertType(itemD, afxFcc_OBJ);
        AfxAssert(AfxObjectGetClass(item) == cls);

        //afxFcc fcc = AfxObjectGetFcc(item);
        //afxNat refCnt = AfxGetRefCount(item);
        //AfxEcho("Destroying %s... %p[%.4s]^%i", cls->name, item, (afxChar*)&fcc, item->refCnt);

        {
            AfxObjectSignalConnections(item, AFX_EVENT_OBJ_DESTROYED, NIL);

            afxConnection *objc;
            afxList *connections = &itemD->handling;

            while (1)
            {
                afxLink *first = AfxGetFirstLink(connections), *head = AfxGetListHead(connections);

                if (first == head) break;
                else
                {
                    objc = AFX_REBASE(first, afxConnection, holderLink);
                    AfxAssertConnection(objc);
                    AfxConnectionDrop(objc);
                }
            }

            connections = &itemD->signaling;

            while (1)
            {
                afxLink *first = AfxGetFirstLink(connections), *head = AfxGetListHead(connections);

                if (first == head) break;
                else
                {
                    objc = AFX_REBASE(first, afxConnection, objLink);
                    AfxAssertConnection(objc);
                    AfxConnectionDrop(objc);
                }
            }
        }

        {
            afxEvent ev;
            AfxEventDeploy(&ev, AFX_EVENT_OBJ_DESTROYED, item, NIL);
            AfxObjectEmitEvent(item, &ev);

            afxEventFilter *flt;

            while (itemD->watching)
            {
                afxLinkage *first = AfxGetLastLinkage(itemD->watching);

                if (!first)
                {
                    AfxAssert(!itemD->watching);
                    break;
                }
                else
                {
                    flt = AFX_REBASE(first, afxEventFilter, holder);
                    AfxAssert(flt->holder.chain->owner == item);
                    AfxAssertType((afxInstance*)flt->watched.chain->owner, afxFcc_OBJ);
                    AfxObjectRemoveEventFilter(flt->watched.chain->owner, item);
                }
            }

            while (itemD->watchers)
            {
                afxLinkage *first = AfxGetLastLinkage(itemD->watchers);

                if (!first)
                {
                    AfxAssert(!itemD->watchers);
                    break;
                }
                else
                {
                    flt = AFX_REBASE(first, afxEventFilter, watched);
                    AfxAssert(flt->watched.chain->owner == item);
                    AfxAssertType((afxInstance*)flt->holder.chain->owner, afxFcc_OBJ);
                    AfxObjectRemoveEventFilter(item, flt->holder.chain->owner);
                }
            }
        }

        if (_AfxClsRunSubsetDtor(cls, item))
            AfxThrowError();

        AfxZero(itemD, sizeof(*itemD));
        //AfxDeallocate(NIL, cls->all, item);

        //AfxEcho("Instance %p[%.4s]^%i destroyed.", item, (afxChar const*)&(fcc), refCnt);
    }
    return err;
}

_AFXINL afxError _AfxClsRunSubsetCtor(afxClass *cls, afxHandle obj, afxCookie const* cookie)
{
    afxError err = AFX_ERR_NONE;
    AfxAssert(cls);
    AfxAssertType(cls, afxFcc_CLS);

    if (cls->base.chain)
    {
        AfxEcho("afxClass<%s, %s>ConstructingObject(%p)", cls->name, ((afxClass*)cls->base.chain->owner)->name, obj);
        
        if (_AfxClsRunSubsetCtor(cls->base.chain->owner, obj, cookie))
            AfxThrowError();
    }

    if (!err)
    {
        AfxEcho("afxClass<%s>::ConstructObject(%p)", cls->name, obj);

        if (cls->ctor && cls->ctor(obj, cookie))
        {
            AfxThrowError();

            if (cls->base.chain)
                _AfxClsRunSubsetDtor(cls, obj);
        }
    }
    return err;
}

_AFX afxError AfxClassBuildObjects(afxClass *cls, afxNat cnt, afxHandle obj[], void* udd)
{
    afxError err = AFX_ERR_NONE;
    AfxAssert(cls);
    AfxAssertType(cls, afxFcc_CLS);
    AfxAssert(cnt);
    AfxAssert(obj);
    //AfxAssert(blueprint);

    for (afxNat i = 0; i < cnt; i++)
    {
        afxHandle item = obj[i];
        AfxEcho("Building %s object (#%d*) %p...", cls->name, i, obj[i]);
        afxInstance *itemD = (afxInstance *)item;
        AfxAssert(item);
        --itemD;
        //AfxAssertType(item, afxFcc_OBJ);
        AfxZero(itemD, sizeof(*itemD));

        itemD->fcc = afxFcc_OBJ;
        itemD->cls = cls;

        itemD->refCnt = 1;
        AfxDeployList(&itemD->signaling);
        AfxDeployList(&itemD->handling);

        itemD->tid;
        AfxGetThreadingId(&itemD->tid);

        itemD->watchers = NIL;
        itemD->watching = NIL;

        AfxClassLockExclusive(cls);
        
        if (_AfxClsRunSubsetCtor(cls, item, udd))
            AfxThrowError();
        
        AfxClassUnlockExclusive(cls);

        if (!err)
        {
            //afxFcc fcc = AfxObjectGetFcc(item);
            //AfxEcho("Instance %p[%.4s]^%i built.", item, (afxChar const*)&(fcc), item->refCnt);
            AfxAssert(itemD->refCnt == 1);
        }
        else
        {
            AfxClassDismantleObjects(cls, i, obj);

            break;
        }
    }
    return err;
}

_AFX afxError AfxDismountClass(afxClass *cls)
{
    afxError err = AFX_ERR_NONE;

    AfxAssert(cls);
    AfxAssertType(cls, afxFcc_CLS);
    AfxEcho("Dismounting %s class... (%p)", cls->name, cls);

    AfxEnterSlockExclusive(&cls->slock);

    _AfxUninstallChainedClasses(&cls->deriveds);

    AfxAssert(0 == AfxGetChainLength(&cls->deriveds));

    afxNat i = 0;
    afxHandle obj;
    while (_AfxClsEnumerateInstances(cls, TRUE, i, 1, &obj))
    {
        while (TRUE != AfxReleaseObjects(1, &obj));
        ++i;
    }

    AfxAssert(0 == cls->pool.totalUsedCnt);
    AfxReleasePool(&cls->pool);

    if (cls->base.chain)
        AfxPopLinkage(&cls->base);

    if (cls->provider.chain)
        AfxPopLinkage(&cls->provider);

    if (cls->ctx)
        AfxReleaseObjects(1, (void*[]) { cls->ctx });

    AfxExitSlockExclusive(&cls->slock);
    AfxReleaseSlock(&cls->slock);
    return err;
}

_AFXINL afxError _AfxClsDummyDtor(afxHandle obj)
{
    (void)obj;
    return 0;
}

_AFXINL afxError _AfxClsDummyCtor(afxHandle obj, afxCookie const* cookie)
{
    (void)obj;
    (void)cookie;
    return 0;
}

_AFX afxError AfxInstallClassExtension(afxClass *cls, afxClass *base, afxChain* provider, afxClassConfig const *config)
{
    afxError err = AFX_ERR_NONE;
    AfxAssert(cls);
    AfxAssert(config);

    AfxEcho("Installing %s at %p by %p over %p with %p)", config->name, cls, provider, base, config);
    
    AfxAcquireSlock(&cls->slock);
    AfxEnterSlockExclusive(&cls->slock);

    cls->fcc = afxFcc_CLS;
    AfxAssert(config->fcc);
    cls->objFcc = config->fcc;
    AfxAssert(base || config->size);
    cls->siz = config->size;

    if (!base)
    {
        AfxPushLinkage(&cls->base, NIL);
        cls->level = _AFX_CLASS_BASE_LEVEL;
    }
    else
    {
        AfxAssert(base != cls);
        AfxAssertType(base, afxFcc_CLS);
        AfxAssert(config->size >= base->siz);
        AfxClassLockExclusive(base);
        AfxPushLinkage(&cls->base, &base->deriveds);
        cls->level = base->level + 1;
        AfxClassUnlockExclusive(base);
    }

    cls->levelMask = (_AFX_CLASS_LEVEL_MASK << cls->level);
    cls->maxInstCnt = config->maxCnt;
    cls->ctor = config->ctor ? config->ctor : _AfxClsDummyCtor;
    cls->dtor = config->dtor ? config->dtor : _AfxClsDummyDtor;
    AfxAssert(config->name && config->name[0]);
    AfxCopyRawString(cls->name, config->name);
    cls->input = NIL;
    cls->output = NIL;
    cls->event = config->event;
    cls->eventFilter = config->eventFilter;
    cls->vmt = config->vmt;

    AfxAcquirePool(&cls->pool, AFX_ALIGN(cls->siz + sizeof(afxInstance), sizeof(void*)), config->unitsPerPage);

    if ((cls->ctx = config->ctx))
    {
        AfxAssertObjects(1, &cls->ctx, afxFcc_CTX);

        if (AfxReacquireObjects(1, (void*[]) { cls->ctx }))
            AfxThrowError();

        if (err)
            cls->ctx = NIL;
    }

    AfxAcquireChain(&cls->deriveds, cls);
    AfxPushLinkage(&cls->provider, provider ? provider : &orphanClassChain);

    AfxExitSlockExclusive(&cls->slock);
    return err;
}

_AFX afxError AfxMountClass(afxClass *cls, afxChain* provider, afxClassConfig const *config)
{
    return AfxInstallClassExtension(cls, NIL, provider, config);
}

_AFX afxNat AfxIdentifyObject(afxHandle obj)
{
    afxError err = AFX_ERR_NONE;
    afxInstance* inst = (afxInstance*)obj;
    --inst;
    AfxAssertType(inst, afxFcc_OBJ);
    
    afxPool* pool = &(AfxObjectGetClass(obj)->pool);
    AfxAssertType(pool, afxFcc_POOL);
    afxNat idx = AFX_INVALID_INDEX;
    AfxFindPoolUnitIndex(pool, (afxByte*)inst, &idx, NIL);
    return idx;
}

_AFX afxError AfxAcquireObjects(afxClass *cls, afxNat cnt, afxHandle obj[], void **udd)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(cls, afxFcc_CLS);
    AfxAssert(cnt);
    AfxAssert(obj);

    if (cls->maxInstCnt && ((cls->maxInstCnt - cls->pool.totalUsedCnt) == 0)) AfxThrowError();
    else
    {
        AfxClassLockExclusive(cls);
        afxInstance* ptr, *ptr2;

        for (afxNat i = 0; i < cnt; i++)
        {
            afxSize idx;
            
            if (!(ptr = (void*)AfxAllocatePoolUnit(&cls->pool, &idx))) AfxThrowError();
            else
            {
                if (!(AfxGetPoolUnit(&cls->pool, idx, (void**)&ptr2))) AfxThrowError();
                else
                {
                    AfxAssert(ptr == ptr2);
                    ptr->instIdx = (afxNat)idx;
                    ptr->fcc = afxFcc_OBJ;
                    ptr->cls = cls;

                    ptr->refCnt = 1;
                    AfxDeployList(&ptr->signaling);
                    AfxDeployList(&ptr->handling);

                    ptr->tid;
                    AfxGetThreadingId(&ptr->tid);

                    ptr->watchers = NIL;
                    ptr->watching = NIL;

                    obj[i] = ptr + 1;
                    AfxAssert(idx == AfxIdentifyObject(obj[i]));
                }
            }

            if (err)
            {
                for (afxNat j = i; j-- > 0;)
                {
                    ptr = obj[i];
                    --ptr;
                    AfxAssertType(ptr, afxFcc_OBJ);
                    AfxDeallocatePoolUnit(&cls->pool, (void*)ptr);
                }
                break;
            }
        }

        if (!err) // initialize
        {
            afxCookie cookie = { 0 };
            cookie.udd = udd;

            for (afxNat i = 0; i < cnt; i++)
            {
                cookie.no = i;

                AfxAssertObjects(1, &obj[i], cls->objFcc);

                if (_AfxClsRunSubsetCtor(cls, obj[i], &cookie))
                    AfxThrowError();

                AfxAssertObjects(1, &obj[i], cls->objFcc);

                if (err)
                {
                    AfxClassDismantleObjects(cls, i, obj);
                    break;
                }
            }

            if (err)
            {
                for (afxNat j = cnt; j-- > 0;)
                {
                    ptr = obj[j];
                    --ptr;
                    AfxAssertType(ptr, afxFcc_OBJ);
                    AfxDeallocatePoolUnit(&cls->pool, (void*)ptr);
                }
            }
        }

        AfxClassUnlockExclusive(cls);
    }

    if (!err)
    {
        AfxAssertObjects(cnt, obj, cls->objFcc);
    }
    return err;
}

_AFX afxError AfxReacquireObjects(afxNat cnt, afxHandle obj[])
{
    afxError err = NIL;
    AfxAssert(cnt);
    AfxAssert(obj);

    for (afxNat i = 0; i < cnt; i++)
    {
        afxInstance* inst = (afxInstance*)(obj[i]);
        --inst;
        AfxAssertType(inst, afxFcc_OBJ);
        ++inst->refCnt;
    }
    return err;
}

_AFX afxBool AfxReleaseObjects(afxNat cnt, void* obj[])
{
    afxError err = NIL;
    AfxAssert(cnt);
    AfxAssert(obj);
    afxBool rslt = 0;

    for (afxNat i = 0; i < cnt; i++)
    {
        afxInstance* inst = (afxInstance*)(obj[i]);
        --inst;
        AfxAssertType(inst, afxFcc_OBJ);
        
        if (inst->refCnt && (0 == --inst->refCnt))
        {
            ++rslt;
            afxClass* cls = inst->cls;
            AfxAssertType(cls, afxFcc_CLS);
            AfxClassLockExclusive(cls);

            AfxAssert(inst->instIdx == AfxIdentifyObject(obj[i]));

            if (err)
            {
                int a = 0;
            }


            AfxClassDismantleObjects(cls, 1, &obj[i]);


            AfxDeallocatePoolUnit(&cls->pool, (void*)inst);
            AfxClassUnlockExclusive(cls);
        }
    };

    return rslt;
}

_AFX afxResult _AfxAssertObjects(afxNat cnt, afxHandle const obj[], afxFcc fcc)
{
    afxError err = NIL;
    AfxAssert(cnt);
    AfxAssert(obj);
    afxResult rslt = 0;

    for (afxNat i = 0; i < cnt; i++)
    {
        if (!obj[i]) err = -1;
        else
        {
            afxInstance* inst = obj[i];
            --inst;
            AfxAssertType(inst, afxFcc_OBJ);
            afxClass* cls = inst->cls;
            AfxAssertType(cls, afxFcc_CLS);

            do if (cls->objFcc == fcc) break;
            while ((cls = AfxGetBaseClass(cls)));

            AfxAssertClass(cls, fcc);
            AfxAssert(inst->instIdx == AfxIdentifyObject(obj[i]));

            if (err)
            {
                int a = 0;
            }
        }

        if (!err)
            ++rslt;
    }
    return rslt;
}
