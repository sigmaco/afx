/*
 *          ::::::::  :::       :::     :::     :::::::::  :::::::::   ::::::::
 *         :+:    :+: :+:       :+:   :+: :+:   :+:    :+: :+:    :+: :+:    :+:
 *         +:+    +:+ +:+       +:+  +:+   +:+  +:+    +:+ +:+    +:+ +:+    +:+
 *         +#+    +:+ +#+  +:+  +#+ +#++:++#++: +#+    +:+ +#++:++#:  +#+    +:+
 *         +#+  # +#+ +#+ +#+#+ +#+ +#+     +#+ +#+    +#+ +#+    +#+ +#+    +#+
 *         #+#   +#+   #+#+# #+#+#  #+#     #+# #+#    #+# #+#    #+# #+#    #+#
 *          ###### ###  ###   ###   ###     ### #########  ###    ###  ########
 *
 *              T H E   Q W A D R O   E X E C U T I O N   E C O S Y S T E M
 *
 *                                   Public Test Build
 *                   (c) 2017 SIGMA Technology Group � Federa��o SIGMA
 *                                    www.sigmaco.org
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdarg.h>

#include "afx/core/afxContext.h"
#include "afx/core/afxUri.h"

typedef enum
{
    HOST_IPV4,
    HOST_IPV6,
    HOST_DOMAIN
} host_type_t;

typedef struct _url_field
{
    host_type_t host_type;
    char const *href;
    int hrefsiz;
    char const*schema;
    int schemasiz;
    char const*username;
    int usersiz;
    char const*password;
    int passsiz;
    char const*host;
    int hostsiz;
    char const*port;
    int portsiz;
    char const*path;
    int pathsiz;
    char const*fdir;
    int fdirsiz;
    char const*fname;
    int fnamesiz;
    char const*fext;
    int fextsiz;
    char const*query;
    int querysiz;
    char const*fragment;
    int fragsiz;
} url_field_t;

// AUXILIAR FUNCTIONS /////////////////////////////////////////////////////////

#if 0
_AFXINL int host_is_ipv4(char const*str)
{
    if (!str) return 0;
    while (*str)
    {
        if ((*str >= '0' && *str <= '9') || *str == '.')
            str++;
        else
            return 0;
    }
    return 1;
}

_AFXINL char * strndup(const char *a, unsigned long long c)
{
    (void)a;
    (void)c;
    return NIL;
}

_AFXINL void parse_query(url_field_t *url, char *query)
{
    int length;
    int offset;
    char *chr;
    length = strlen(query);
    offset = 0;
    chr = strchr(query, '=');
    while (chr)
    {
        if (url->query)
            url->query = realloc(url->query, (url->query_num + 1) * sizeof(*url->query));
        else
            url->query = malloc(sizeof(*url->query));
        url->query[url->query_num].name = strndup(query, chr - query);
        query = chr + 1;
        chr = strchr(query, '&');
        if (chr)
        {
            url->query[url->query_num].value = strndup(query, chr - query);
            url->query_num++;
            query = chr + 1;
            chr = strchr(query, '=');
        }
        else
        {
            url->query[url->query_num].value = strndup(query, -1);
            url->query_num++;
            break;
        }
    }
}
#endif

_AFXINL afxResult _AfxUrlParseRaw(const char *str, afxNat strLenTotal, url_field_t *url)
{
    afxNat strLen = strLenTotal;
    const char *pch, *start = str, *end = str + strLen;
    *url = (url_field_t) { 0 };

    if (str && str[0] && strLen)
    {
        url->href = str;
        url->hrefsiz = strLen;// strlen(str);

        pch = memchr(str, ':', strLen);   /* parse schema */

        if (pch && pch[1] == '/' && pch[2] == '/')
        {
            url->schema = str;
            url->schemasiz = pch - str;
            strLen -= url->schemasiz;
            str = pch + 3;

            pch = memchr(str, '@', strLen);   /* parse user info */
            
            if (pch)
            {
                pch = memchr(str, ':', strLen);

                if (pch)
                {
                    url->username = str;
                    url->usersiz = pch - str;
                    strLen -= url->usersiz;

                    str = pch + 1;
                    pch = memchr(str, '@', strLen);

                    if (pch)
                    {
                        url->password = str;
                        url->passsiz = pch - str;
                        strLen -= url->passsiz;
                        str = pch + 1;
                    }
                    else goto __fail;
                }
                else goto __fail;
            }

            if (str[0] == '[')        /* parse host info */
            {
                str++;
                pch = memchr(str, ']', strLen);

                if (pch)
                {
                    url->host = str;
                    url->hostsiz = pch - str;
                    strLen -= url->hostsiz;
                    str = pch + 1;

                    if (str[0] == ':')
                    {
                        str++;
                        pch = memchr(str, '/', strLen);

                        if (pch)
                        {
                            url->port = str;
                            url->portsiz = pch - str;
                            strLen -= url->portsiz;
                            str = pch + 1;
                        }
                        else
                        {
                            url->port = str;
                            url->portsiz = strLen - (str - start);// strlen(str);
                            strLen -= url->portsiz;
                            str = str + strLen - (str - start);//strlen(str);
                        }
                    }
                    url->host_type = HOST_IPV6;
                }
                else goto __fail;
            }
            else
            {
                const char *pch_slash;
                pch = memchr(str, ':', strLen);
                pch_slash = memchr(str, '/', strLen);

                if (pch && (!pch_slash || (pch_slash && pch < pch_slash)))
                {
                    url->host = str;
                    url->hostsiz = pch - str;
                    strLen -= url->hostsiz;
                    str = pch + 1;
                    pch = memchr(str, '/', strLen);

                    if (pch)
                    {
                        url->port = str;
                        url->portsiz = pch - str;
                        strLen -= url->portsiz;
                        str = pch + 1;
                    }
                    else
                    {
                        url->port = str;
                        url->portsiz = strLen - (str - start);//strlen(str);
                        strLen -= url->portsiz;
                        str = str + strLen - (str - start);//strlen(str);
                    }
                }
                else
                {
                    pch = memchr(str, '/', strLen);

                    if (pch)
                    {
                        url->host = str;
                        url->hostsiz = pch - str;
                        strLen -= url->hostsiz;
                        str = pch + 1;
                    }
                    else
                    {
                        url->host = str;
                        url->hostsiz = strLen - (str - start);//strlen(str);
                        strLen -= url->hostsiz;
                        str = str + strLen - (str - start);//strlen(str);
                    }
                }
                url->host_type = 0;//host_is_ipv4(url->host) ? HOST_IPV4 : HOST_DOMAIN;
            }
        }

        if (str[0]) /* parse path, query and fragment */
        {
            url->path = str;
            pch = memchr(str, '?', strLen);

            if (pch) // has query
            {
                //url->path = str;
                url->pathsiz = pch - url->path;
                strLen -= url->pathsiz;
                str = pch/* + 1*/;
                url->query = pch;
                pch = memchr(str, '#', strLen);

                if (pch) // has fragment
                {
                    url->querysiz = pch - url->query;
                    strLen -= url->querysiz;
                    str = pch/* + 1*/;
                    url->fragment = pch;
                    url->fragsiz = end - url->fragment;//strlen(str);
                    strLen -= url->fragsiz;

                    if (url->fragsiz != 0 || url->fragsiz == 65511)
                    {
                        int a = 0;
                    }
                }
                else
                {
                    // has query but no fragment

                    //url->query = str;
                    url->querysiz = end - url->query;//strlen(str);
                    strLen -= url->querysiz;
                    //str = str + strLen - (str - start);//strlen(str);
                    url->fragment = 0;
                    url->fragsiz = 0;
                    strLen -= url->fragsiz;

                    if (url->fragsiz != 0 || url->fragsiz == 65511)
                    {
                        int a = 0;
                    }
                }
            }
            else
            {
                // doesnt has query
                url->query = 0;
                url->querysiz = 0;
                strLen -= url->querysiz;
                pch = memchr(str, '#', strLen);

                if (pch) // has fragment but no query
                {
                    //url->path = str;
                    url->pathsiz = pch - url->path;
                    strLen -= url->pathsiz;
                    str = pch/* + 1*/;
                    url->fragment = pch;
                    url->fragsiz = end - url->fragment;//strlen(str);
                    strLen -= url->fragsiz;
                    //str = str + strLen - (str - start);//strlen(str);


                    if (url->fragsiz != 0 || url->fragsiz == 65511)
                    {
                        int a = 0;
                    }
                }
                else
                {
                    // doesnt has fragment nor query

                    //url->path = str;
                    url->pathsiz = strLen - (str - start);//strlen(str);
                    strLen -= url->pathsiz;
                    //str = str + strLen - (str - start);//strlen(str);
                    url->fragment = 0;
                    url->fragsiz = 0;
                    strLen -= url->fragsiz;


                    if (url->fragsiz != 0 || url->fragsiz == 65511)
                    {
                        int a = 0;
                    }
                }
            }

            // fdir, fname and fext
            if (url->pathsiz)
            {
                pch = url->path + url->pathsiz;

                while (url->path != pch)
                {
                    --pch;

                    if (*pch == '/' || *pch == '\\') // normalize this shit
                    {
                        // if path terminates with (back)slash, it is a directory
                        url->fdir = url->path;
                        url->fdirsiz = pch - url->fdir + 1;
                        break; // if a directory is found, there's no more chance to get a filename or file extension, so we break it here. We are looking for in reverse mode.
                    }
                }

                //pch = url->path + url->pathsiz;

                if (url->fdir)
                {
                    url->fname = url->fdir + url->fdirsiz;
                    url->fnamesiz = (url->path + url->pathsiz) - url->fname;
                }
                else
                {
                    url->fname = url->path;
                    url->fnamesiz = url->pathsiz;
                }
                 
                // ext
                if (url->fnamesiz)
                {
                    pch = url->fname + url->fnamesiz;

                    while (url->fname != pch)
                    {
                        --pch;

                        if (*pch == '.' && url->fname != pch && pch != url->fname + url->fnamesiz - 1)
                        {
                            url->fext = pch;
                            url->fextsiz = (url->fname + url->fnamesiz) - url->fext;
                            break;
                        }
                    }
                }
            }
        }
    }
    else
    {
__fail:
        return 0;
    }
    return 1;
}

// READ-ONLY METHODS //////////////////////////////////////////////////////////

_AFXINL afxBool AfxUriIsEquivalentToString(afxUri const *uri, afxString const *str)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(uri, afxFcc_URI);
    AfxAssertType(str, afxFcc_STR);

    afxString const *strA = AfxUriGetStringConst(uri);
    AfxAssertType(strA, afxFcc_STR);

    return (0 == AfxCompareString(strA, str));
}

_AFXINL afxBool AfxUriIsEquivalentToStringCi(afxUri const *uri, afxString const *str)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(uri, afxFcc_URI);
    AfxAssertType(str, afxFcc_STR);

    afxString const *strA = AfxUriGetStringConst(uri);
    AfxAssertType(strA, afxFcc_STR);

    return (0 == AfxCompareStringCi(strA, str));
}

_AFXINL afxBool AfxUriIsEquivalent(afxUri const *uri, afxUri const *other)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(uri, afxFcc_URI);
    AfxAssertType(other, afxFcc_URI);

    afxString const *strA = AfxUriGetStringConst(uri), *strB = AfxUriGetStringConst(other);
    AfxAssertType(strA, afxFcc_STR);
    AfxAssertType(strB, afxFcc_STR);

    if (err)
    {
        int a = 0;
    }

    return (0 == AfxCompareString(strA, strB));
}

_AFXINL afxBool AfxUriIsEquivalentCi(afxUri const *uri, afxUri const *other)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(uri, afxFcc_URI);
    AfxAssertType(other, afxFcc_URI);

    afxString const *strA = AfxUriGetStringConst(uri), *strB = AfxUriGetStringConst(other);
    AfxAssertType(strA, afxFcc_STR);
    AfxAssertType(strB, afxFcc_STR);

    return (0 == AfxCompareStringCi(strA, strB));
}

_AFXINL afxString* AfxUriGetString(afxUri *uri)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(uri, afxFcc_URI);
    return &(uri->str);
}

_AFXINL afxString const* AfxUriGetStringConst(afxUri const *uri)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(uri, afxFcc_URI);
    return &(uri->str);
}

_AFXINL void* AfxGetUriData(afxUri *uri, afxNat base)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(uri, afxFcc_URI);
    return AfxGetStringData(&(uri->str), base);
}

_AFXINL void const* AfxGetUriDataConst(afxUri const *uri, afxNat base)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(uri, afxFcc_URI);
    return AfxGetStringDataConst(&(uri->str), base);
}

_AFXINL afxNat AfxExcerptUriScheme(afxUri *uri, afxUri const *parent)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(parent, afxFcc_URI);
    AfxAssert(uri);

    AfxResetUri(uri);
    uri->schem = parent->schem;
    AfxExcerptStringRange(&(uri->str), &(parent->str), 0, uri->schem);
    afxNat len = AfxGetStringSize(&(uri->str));
    AfxAssert(len == uri->schem);
    return len;
}

_AFXINL afxNat AfxExcerptUriUsername(afxUri *uri, afxUri const *parent)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(parent, afxFcc_URI);
    AfxAssert(uri);

    AfxResetUri(uri);
    uri->user = parent->user;
    AfxExcerptStringRange(&(uri->str), &(parent->str), parent->schem, uri->user);
    afxNat len = AfxGetStringSize(&(uri->str));
    AfxAssert(len == uri->user);
    return len;
}

_AFXINL afxNat AfxExcerptUriPassword(afxUri *uri, afxUri const *parent)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(parent, afxFcc_URI);
    AfxAssert(uri);

    AfxResetUri(uri);
    uri->pass = parent->pass;
    AfxExcerptStringRange(&(uri->str), &(parent->str), parent->schem + parent->user, uri->pass);
    afxNat len = AfxGetStringSize(&(uri->str));
    AfxAssert(len == uri->pass);
    return len;
}

_AFXINL afxNat AfxExcerptUriHost(afxUri *uri, afxUri const *parent)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(parent, afxFcc_URI);
    AfxAssert(uri);

    AfxResetUri(uri);
    uri->host = parent->host;
    AfxExcerptStringRange(&(uri->str), &(parent->str), parent->schem + parent->user + parent->pass, uri->host);
    afxNat len = AfxGetStringSize(&(uri->str));
    AfxAssert(len == uri->host);
    return len;
}

_AFXINL afxNat AfxExcerptUriPort(afxUri *uri, afxUri const *parent)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(parent, afxFcc_URI);
    AfxAssert(uri);

    AfxResetUri(uri);
    uri->port = parent->port;
    AfxExcerptStringRange(&(uri->str), &(parent->str), parent->schem + parent->user + parent->pass + parent->host, uri->port);
    afxNat len = AfxGetStringSize(&(uri->str));
    AfxAssert(len == uri->port);
    return len;
}

_AFXINL afxNat AfxExcerptUriDirectory(afxUri *uri, afxUri const *parent)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(parent, afxFcc_URI);
    AfxAssert(uri);

    AfxResetUri(uri);
    uri->dir = parent->dir;
    AfxExcerptStringRange(&(uri->str), &(parent->str), parent->schem + parent->user + parent->pass + parent->host + parent->port, uri->dir);
    afxNat len = AfxGetStringSize(&(uri->str));
    AfxAssert(len == uri->dir);
    return len;
}

_AFXINL afxNat AfxExcerptUriName(afxUri *uri, afxUri const *parent)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(parent, afxFcc_URI);
    AfxAssert(uri);

    AfxResetUri(uri);
    uri->fname = parent->fname;
    AfxExcerptStringRange(&(uri->str), &(parent->str), parent->schem + parent->user + parent->pass + parent->host + parent->port + parent->dir, uri->fname);
    afxNat len = AfxGetStringSize(&(uri->str));
    AfxAssert(len == uri->fname);
    return len;
}

_AFXINL afxNat AfxExcerptUriExtension(afxUri *uri, afxUri const *parent, afxBool skipDot)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(parent, afxFcc_URI);
    AfxAssert(uri);

    AfxResetUri(uri);
    afxNat additive = skipDot && parent->fext ? 1 : 0;
    uri->fext = parent->fext - additive;
    AfxExcerptStringRange(&(uri->str), &(parent->str), parent->schem + parent->user + parent->pass + parent->host + parent->port + parent->dir + parent->fname + additive, uri->fext);
    afxNat len = AfxGetStringSize(&(uri->str));
    AfxAssert(len == uri->fext);
    return len;
}

_AFXINL afxNat AfxExcerptUriObject(afxUri *uri, afxUri const *parent)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(parent, afxFcc_URI);
    AfxAssert(uri);

    AfxResetUri(uri);
    uri->fname = parent->fname;
    uri->fext = parent->fext;
    AfxExcerptStringRange(&(uri->str), &(parent->str), parent->schem + parent->user + parent->pass + parent->host + parent->port + parent->dir, uri->fname + uri->fext);
    afxNat len = AfxGetStringSize(&(uri->str));
    AfxAssert(len == uri->fname + uri->fext);
    return len;
}

_AFXINL afxNat AfxExcerptUriPath(afxUri *uri, afxUri const *parent)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(parent, afxFcc_URI);
    AfxAssert(uri);

    AfxResetUri(uri);
    uri->dir = parent->dir;
    uri->fname = parent->fname;
    uri->fext = parent->fext;
    AfxExcerptStringRange(&(uri->str), &(parent->str), parent->schem + parent->user + parent->pass + parent->host + parent->port, parent->dir + parent->fname + parent->fext);
    afxNat len = AfxGetStringSize(&(uri->str));
    AfxAssert(len == parent->dir + parent->fname + parent->fext);
    return len;
}

_AFXINL afxNat AfxExcerptUriDirectoryRW(afxUri *uri, afxUri *parent)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(parent, afxFcc_URI);
    AfxAssert(uri);

    AfxResetUri(uri);
    uri->dir = parent->dir;
    AfxWrapStringLiteralRW(&(uri->str), AfxGetUriData(parent, parent->schem + parent->user + parent->pass + parent->host + parent->port), uri->dir);
    afxNat len = AfxGetStringSize(&(uri->str));
    AfxAssert(len == uri->dir);
    return len;
}

_AFXINL afxNat AfxExcerptUriNameRW(afxUri *uri, afxUri *parent)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(parent, afxFcc_URI);
    AfxAssert(uri);

    AfxResetUri(uri);
    uri->fname = parent->fname;
    AfxWrapStringLiteralRW(&(uri->str), AfxGetUriData(parent, parent->schem + parent->user + parent->pass + parent->host + parent->port + parent->dir), uri->fname);
    afxNat len = AfxGetStringSize(&(uri->str));
    AfxAssert(len == uri->fname);
    return len;
}

_AFXINL afxNat AfxExcerptUriExtensionRW(afxUri *uri, afxUri *parent)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(parent, afxFcc_URI);
    AfxAssert(uri);

    AfxResetUri(uri);
    uri->fext = parent->fext;
    AfxWrapStringLiteralRW(&(uri->str), AfxGetUriData(parent, parent->schem + parent->user + parent->pass + parent->host + parent->port + parent->dir + parent->fname), uri->fext);
    afxNat len = AfxGetStringSize(&(uri->str));
    AfxAssert(len == uri->fext);
    return len;
}

_AFXINL afxNat AfxExcerptUriObjectRW(afxUri *uri, afxUri *parent)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(parent, afxFcc_URI);
    AfxAssert(uri);

    AfxResetUri(uri);
    uri->fname = parent->fname;
    uri->fext = parent->fext;
    AfxWrapStringLiteralRW(&(uri->str), AfxGetUriData(parent, parent->schem + parent->user + parent->pass + parent->host + parent->port + parent->dir), uri->fname + uri->fext);
    afxNat len = AfxGetStringSize(&(uri->str));
    AfxAssert(len == uri->fname + uri->fext);
    return len;
}

_AFXINL afxNat AfxExcerptUriPathRW(afxUri *uri, afxUri *parent)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(parent, afxFcc_URI);
    AfxAssert(uri);

    AfxResetUri(uri);
    uri->dir = parent->dir;
    uri->fname = parent->fname;
    uri->fext = parent->fext;
    AfxWrapStringLiteralRW(&(uri->str), AfxGetUriData(parent, parent->schem + parent->user + parent->pass + parent->host + parent->port), parent->dir + parent->fname + parent->fext);
    afxNat len = AfxGetStringSize(&(uri->str));
    AfxAssert(len == parent->dir + parent->fname + parent->fext);
    return len;
}

_AFXINL afxNat AfxExcerptUriQuery(afxUri *uri, afxUri const *parent, afxBool skipSep)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(parent, afxFcc_URI);
    AfxAssert(uri);

    AfxResetUri(uri);
    afxNat additive = skipSep && parent->query ? 1 : 0;
    uri->query = parent->query - additive;
    AfxExcerptStringRange(&(uri->str), &(parent->str), parent->schem + parent->user + parent->pass + parent->host + parent->port + parent->dir + parent->fname + parent->fext + additive, uri->query);
    afxNat len = AfxGetStringSize(&(uri->str));
    AfxAssert(len == uri->query);
    return len;
}

_AFXINL afxNat AfxExcerptUriFragment(afxUri *uri, afxUri const *parent, afxBool skipSep)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(parent, afxFcc_URI);
    AfxAssert(uri);

    AfxResetUri(uri);
    afxNat additive = skipSep && parent->frag ? 1 : 0;
    uri->frag = parent->frag - additive;
    AfxExcerptStringRange(&(uri->str), &(parent->str), parent->schem + parent->user + parent->pass + parent->host + parent->port + parent->dir + parent->fname + parent->fext + parent->query + additive, uri->frag);
    afxNat len = AfxGetStringSize(&(uri->str));
    AfxAssert(len == uri->frag);
    return len;
}

_AFXINL void AfxReflectUri(afxUri *uri, afxUri const *in)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(in, afxFcc_URI);
    AfxAssert(uri);

    AfxExcerptString(&(uri->str), &(in->str));

    AfxAssignTypeFcc(uri, afxFcc_URI);
    uri->schem = in->schem;
    uri->user = in->user;
    uri->pass = in->pass;
    uri->host = in->host;
    uri->port = in->port;
    uri->dir = in->dir;
    uri->fname = in->fname;
    uri->fext = in->fext;
    uri->query = in->query;
    uri->frag = in->frag;
}

_AFXINL afxError AfxCopyUriScheme(afxUri *uri, afxUri const *src)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(uri, afxFcc_URI);
    AfxAssertType(src, afxFcc_URI);

    afxUri excerpt;
    AfxExcerptUriScheme(&excerpt, src);

    if (AfxCopyUri(uri, &excerpt))
        AfxThrowError();

    return err;
}

_AFXINL afxError AfxCopyUriUsername(afxUri *uri, afxUri const *src)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(uri, afxFcc_URI);
    AfxAssertType(src, afxFcc_URI);

    afxUri excerpt;
    AfxExcerptUriUsername(&excerpt, src);

    if (AfxCopyUri(uri, &excerpt))
        AfxThrowError();

    return err;
}

_AFXINL afxError AfxCopyUriPassword(afxUri *uri, afxUri const *src)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(uri, afxFcc_URI);
    AfxAssertType(src, afxFcc_URI);

    afxUri excerpt;
    AfxExcerptUriPassword(&excerpt, src);

    if (AfxCopyUri(uri, &excerpt))
        AfxThrowError();

    return err;
}

_AFXINL afxError AfxCopyUriHost(afxUri *uri, afxUri const *src)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(uri, afxFcc_URI);
    AfxAssertType(src, afxFcc_URI);

    afxUri excerpt;
    AfxExcerptUriHost(&excerpt, src);

    if (AfxCopyUri(uri, &excerpt))
        AfxThrowError();

    return err;
}

_AFXINL afxError AfxCopyUriPort(afxUri *uri, afxUri const *src)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(uri, afxFcc_URI);
    AfxAssertType(src, afxFcc_URI);

    afxUri excerpt;
    AfxExcerptUriPort(&excerpt, src);

    if (AfxCopyUri(uri, &excerpt))
        AfxThrowError();

    return err;
}

_AFXINL afxError AfxCopyUriDirectory(afxUri *uri, afxUri const *src)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(uri, afxFcc_URI);
    AfxAssertType(src, afxFcc_URI);

    afxUri excerpt;
    AfxExcerptUriDirectory(&excerpt, src);

    if (AfxCopyUri(uri, &excerpt))
        AfxThrowError();

    return err;
}

_AFXINL afxError AfxCopyUriObject(afxUri *uri, afxUri const *src)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(uri, afxFcc_URI);
    AfxAssertType(src, afxFcc_URI);

    afxUri excerpt;
    AfxExcerptUriObject(&excerpt, src);

    if (AfxCopyUri(uri, &excerpt))
        AfxThrowError();

    return err;
}

_AFXINL afxError AfxCopyUriName(afxUri *uri, afxUri const *src)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(uri, afxFcc_URI);
    AfxAssertType(src, afxFcc_URI);

    afxUri excerpt;
    AfxExcerptUriName(&excerpt, src);

    if (AfxCopyUri(uri, &excerpt))
        AfxThrowError();

    return err;
}

_AFXINL afxError AfxCopyUriExtension(afxUri *uri, afxUri const *src, afxBool skipDot)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(uri, afxFcc_URI);
    AfxAssertType(src, afxFcc_URI);

    afxUri excerpt;
    AfxExcerptUriExtension(&excerpt, src, skipDot);

    if (AfxCopyUri(uri, &excerpt))
        AfxThrowError();

    return err;
}

_AFXINL afxError AfxCopyUriPath(afxUri *uri, afxUri const *src)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(uri, afxFcc_URI);
    AfxAssertType(src, afxFcc_URI);

    afxUri excerpt;
    AfxExcerptUriPath(&excerpt, src);

    if (AfxCopyUri(uri, &excerpt))
        AfxThrowError();

    return err;
}

_AFXINL afxError AfxCopyUriQuery(afxUri *uri, afxUri const *src, afxBool skipSep)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(uri, afxFcc_URI);
    AfxAssertType(src, afxFcc_URI);

    afxUri excerpt;
    AfxExcerptUriQuery(&excerpt, src, skipSep);

    if (AfxCopyUri(uri, &excerpt))
        AfxThrowError();

    return err;
}

_AFXINL afxError AfxCopyUriFragment(afxUri *uri, afxUri const *src, afxBool skipSep)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(uri, afxFcc_URI);
    AfxAssertType(src, afxFcc_URI);

    afxUri excerpt;
    AfxExcerptUriFragment(&excerpt, src, skipSep);
    
    if (AfxCopyUri(uri, &excerpt))
        AfxThrowError();

    return err;
}

_AFXINL afxBool AfxUriIsPathRelative(afxUri const *uri)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(uri, afxFcc_URI);

    afxUri excerpt;
    AfxExcerptUriPath(&excerpt, uri);
    afxByte const* data = AfxGetUriDataConst(&excerpt, 0);

    return (!data || (data[0] != '/' && data[1] != ':'));
}

_AFXINL afxBool AfxUriIsWriteable(afxUri const *uri)
{
    return AfxStringIsWriteable(&uri->str);
}

_AFXINL afxBool AfxUriIsBlank(afxUri const *uri)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(uri, afxFcc_URI);
    return 0 == (uri->schem + uri->user + uri->pass + uri->host + uri->port + uri->dir + uri->fname + uri->fext + uri->query + uri->frag);
}

_AFXINL afxBool AfxUriHasScheme(afxUri const *uri)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(uri, afxFcc_URI);
    return (!!(uri->schem));
}

_AFXINL afxBool AfxUriHasPassword(afxUri const *uri)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(uri, afxFcc_URI);
    return (!!(uri->pass));
}

_AFXINL afxBool AfxUriHasUsername(afxUri const *uri)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(uri, afxFcc_URI);
    return (!!(uri->user));
}

_AFXINL afxBool AfxUriHasHost(afxUri const *uri)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(uri, afxFcc_URI);
    return (!!(uri->host));
}

_AFXINL afxBool AfxUriHasPort(afxUri const *uri)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(uri, afxFcc_URI);
    return (!!(uri->port));
}

_AFXINL afxBool AfxUriHasPath(afxUri const *uri)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(uri, afxFcc_URI);
    return (!!(uri->dir + uri->fname + uri->fext));
}

_AFXINL afxBool AfxUriHasDirectory(afxUri const *uri)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(uri, afxFcc_URI);
    return (!!(uri->dir));
}

_AFXINL afxBool AfxUriHasName(afxUri const *uri)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(uri, afxFcc_URI);
    return (!!(uri->fname));
}

_AFXINL afxBool AfxUriHasExtension(afxUri const *uri)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(uri, afxFcc_URI);
    return (!!(uri->fext));
}

_AFXINL afxBool AfxUriHasQuery(afxUri const *uri)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(uri, afxFcc_URI);
    return (!!(uri->query));
}

_AFXINL afxBool AfxUriHasFragment(afxUri const *uri)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(uri, afxFcc_URI);
    return (!!(uri->frag));
}

_AFXINL afxResult _AfxFindUriQueryAttribute(afxString *attr, afxString *value, void* data)
{
    afxError err = AFX_ERR_NONE;
    AfxAssert(attr);
    AfxAssert(value);
    AfxAssert(data);
    struct { afxString const* key; afxString* dst; afxBool success; } *data2 = data;

    if (0 == AfxCompareString(data2->key, attr))
    {
        AfxCopyString(data2->dst, value);
        data2->success = TRUE;
        return 0; // break
    }
    return 1; // continue
}

_AFXINL afxResult AfxUriForEachQueryKey(afxUri const *uri, afxResult(*f)(afxString *attr, afxString *value, void* data), void* data)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(uri, afxFcc_URI);
    AfxAssert(f);
    afxResult cnt = 0;

    afxUri query2;
    AfxExcerptUriQuery(&query2, uri, FALSE);
    afxChar const* query = AfxGetUriDataConst(&query2,0);
#if 0
    afxString64 attr;
    afxString512 value;
    AfxString64(&attr, NIL);
    AfxString512(&value, NIL);

    char *chr;
    chr = strchr(query, '=');
    while (chr)
    {
        AfxCopyStringLiteral(&attr.str, 0, chr - query, query);
        query = chr + 1;
        chr = strchr(query, '&');
        if (chr)
        {
            AfxCopyStringLiteral(&value.str, 0, chr - query, query);
            query = chr + 1;
            chr = strchr(query, '=');

            cnt++;

            if (!f(&attr.str, &value.str, data))
                break;
        }
        else
        {
            AfxCopyStringLiteral(&value.str, 0, 0, query);

            cnt++;

            if (!f(&attr.str, &value.str, data)) // faz sentido se � o �ltimo?
                break;

            break;
        }
    }
#endif
    return cnt;
}

_AFXINL afxResult AfxUriMapQueryPairs(afxUri const *uri, afxNat base, afxNat cnt, afxString keys[], afxString values[])
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(uri, afxFcc_URI);
    AfxAssert(keys);
    AfxAssert(base == 0);
    AfxAssert(cnt);
    (void)values;
    afxResult rslt = 0;

    afxUri query2;
    AfxExcerptUriQuery(&query2, uri, FALSE);
    afxChar const* start = AfxGetUriDataConst(&query2,0);
    afxChar const *chr = start;

    while (1)
    {

    }
    return rslt;
}

_AFXINL void AfxNormalizeUriPath(afxUri *uri) // c:\shit\\\by\\M$\foo.poo -> /c/shit/by/M$/unshitted/foo.poo
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(uri, afxFcc_URI);
    AfxAssert(AfxUriIsWriteable(uri));
    afxUri path, query, frag;
    
    if (AfxExcerptUriPathRW(&path, uri))
    {
        AfxExcerptUriQuery(&query, uri, FALSE);
        AfxExcerptUriFragment(&frag, uri, FALSE);

        afxString *pathStr = AfxUriGetString(&path);

        // TODO move query and fragment to end of path, once normalization never increase size of string.
            
        afxChar *ptr, *end;
        afxInt len;
        afxChar dst[4096];
        afxChar const *src2 = AfxGetStringDataConst(pathStr, 0);

        // Check for maximum filename length
        if (!src2)
        {
            AfxThrowError(); //errno = EINVAL;
            return;
        }

        // Remove drive letter from filename (e.g. c:)
        if (src2[0] != 0 && src2[1] == ':')
            if (0)
                src2 += 2;

        // Initialize buffer
        ptr = dst;
        end = dst + sizeof(dst);

        // Add current directory to filename if relative path
        if (*src2 == '/' || *src2 == '\\')
        {
            //char cxmlir[FILENAME_MAX];

            // Do not add current directory if it is root directory
            len = strlen("");

            if (len > 1)
            {
                memcpy(ptr, "", len);
                ptr += len;
            }
        }

        while (*src2)
        {
            // Parse path separator
            if (*src2 == '/' || *src2 == '\\')
                src2++;

            if (ptr == end)
            {
                AfxThrowError(); //errno = ENAMETOOLONG;
                return;
            }

            //if (fsys->realCfg.rootEmptyPath)
            if (ptr != dst)
                * ptr++ = '/';

            // Parse next name part in path
            len = 0;
            while (*src2 && *src2 != '/' && *src2 != '\\')
            {
                // We do not allow control characters in filenames
                if (*src2 > 0 && *src2 < ' ')
                {
                    AfxThrowError(); //errno = EINVAL;
                    return;
                }

                if (ptr == end)
                {
                    AfxThrowError(); //errno = ENAMETOOLONG;
                    return;
                }
                *ptr++ = *src2++;
                len++;
            }

            // Handle empty name parts and '.' and '..'
            if (len == 0) ptr--;
            else if (len == 1 && src2[-1] == '.') ptr -= 2;
            else if (len == 2 && src2[-1] == '.' && src2[-2] == '.')
            {
                ptr -= 4;

                if (ptr < dst)
                {
                    AfxThrowError(); //errno = EINVAL;
                    return;
                }
                while (*ptr != '/') ptr--;
            }
        }

        // Convert empty filename to /
        if (ptr == dst)
        {
            //if (fsys->realCfg.rootEmptyPath)
            //*ptr++ = '/';
        }

        // Terminate string
        if (ptr == end)
        {
            AfxThrowError(); //errno = ENAMETOOLONG;
            return;
        }

        *ptr = 0;

        _AfxWriteString(pathStr, 0, dst, ptr - dst); // TODO move query and fragment to end of path, once normalization never increase size of string.
        afxByte *_bytemap = AfxGetStringData(pathStr, 0);
        _bytemap[ptr - dst] = '\0';
        uri->str.range = /*uri->str._range -*/ (ptr - dst); // se os seguintes componentes foram escritos incorretamente, mova isto para depois da concatena��o deles.
#if 0
        uri->dir.base = path.;
        uri->dir.range;
        uri->file.base;
        uri->file.range;
        uri->ext.base;
        uri->ext.range;
#endif
        if (AfxUriHasQuery(&query))
            AfxAppendString(pathStr, AfxUriGetString(&query));

        if (AfxUriHasFragment(&frag))
            AfxAppendString(pathStr, AfxUriGetString(&frag));

        AfxReparseUri(uri);
    }
}

_AFXINL void AfxReparseUri(afxUri *uri)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(uri, afxFcc_URI);

    afxChar* data = AfxGetStringData(&uri->str, 0);

    url_field_t split = { 0 };
    _AfxUrlParseRaw(data, AfxGetStringSize(&uri->str), &split);

    uri->schem = split.schemasiz;
    uri->user = split.usersiz;
    uri->pass = split.passsiz;
    uri->host = split.hostsiz;
    uri->port = split.portsiz;
    uri->dir = split.fdirsiz;
    uri->fname = split.fnamesiz - split.fextsiz;
    uri->fext = split.fextsiz;
    uri->query = split.querysiz;
    uri->frag = split.fragsiz;

    if (uri->frag == 65511)
    {
        int a = 0;
    }

    if (split.fnamesiz)
    {
        if (data[uri->schem + uri->user + uri->pass + uri->host + uri->port + uri->dir] == '/' || data[uri->schem + uri->user + uri->pass + uri->host + uri->port + uri->dir] == '\\') // '\\' is unneeded once it is already normalized
        {
            uri->fname--, uri->dir++;
            split.fnamesiz--, split.fdirsiz++;
        }
    }


    int a = 0;
}

_AFXINL void AfxFormatUri(afxUri *uri, afxChar const *fmt, ...)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(uri, afxFcc_URI);
    AfxAssert(AfxUriIsWriteable(uri));

    AfxAssert(fmt);

    afxString *str = AfxUriGetString(uri);
    AfxAssertString(str);

    va_list args;
    va_start(args, fmt);
    AfxFormatStringArg(str, fmt, args);
    va_end(args);
    AfxReparseUri(uri);
    AfxNormalizeUriPath(uri);
}

_AFXINL afxError AfxCopyUri(afxUri *uri, afxUri const *src)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(src, afxFcc_URI);
    AfxAssertType(uri, afxFcc_URI);
    AfxAssert(AfxUriIsWriteable(uri));
    
    if (AfxCopyString(&uri->str, &src->str))
        AfxThrowError();

    AfxReparseUri(uri); // Strings can have differently sized buffers. So we recalc it instead of just copy offsets and ranges.

    return err;
}

_AFXINL void AfxReflectUriString(afxUri *uri, afxString const *src)
{
    afxError err = AFX_ERR_NONE;
    AfxAssert(uri);
    
    AfxResetUri(uri);
    AfxExcerptString(&uri->str, src);
    AfxReparseUri(uri);
    //AfxNormalizeUriPath(uri);  // can't change static data, will cause access violation
}

_AFXINL void AfxUriWrapLiteralRW(afxUri *uri, void *start, afxNat range)
{
    afxError err = AFX_ERR_NONE;
    AfxAssert(uri);
    
    AfxResetUri(uri);
    AfxWrapStringLiteralRW(&uri->str, start, range);
    AfxAssert(AfxUriIsWriteable(uri));
    AfxReparseUri(uri);
    AfxNormalizeUriPath(uri);
}

_AFXINL void AfxUriWrapLiteral(afxUri *uri, void const *start, afxNat range)
{
    afxError err = AFX_ERR_NONE;
    AfxAssert(uri);

    AfxResetUri(uri);
    AfxWrapStringLiteral(&uri->str, start, range);
    AfxReparseUri(uri);
    //AfxNormalizeUriPath(uri); // can't change static data, will cause access violation
}

_AFXINL void AfxUriWrapBuffer(afxUri *uri, void const *start, afxNat cap)
{
    afxError err = AFX_ERR_NONE;
    AfxAssert(uri);

    AfxResetUri(uri);
    AfxWrapStringBuffer(&uri->str, (void*)start, cap);
}

_AFXINL void AfxResetUri(afxUri *uri)
{
    afxError err = AFX_ERR_NONE;
    AfxAssert(uri);
    AfxAssignTypeFcc(uri, afxFcc_URI);

    AfxResetString(&uri->str);

    uri->schem = 0;
    uri->user = 0;
    uri->pass = 0;
    uri->host = 0;
    uri->port = 0;
    uri->dir = 0;
    uri->fname = 0;
    uri->fext = 0;
    uri->query = 0;
    uri->frag = 0;
}

_AFXINL void AfxEraseUri(afxUri *uri)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(uri, afxFcc_URI);

    AfxClearString(&uri->str);

    uri->schem = 0;
    uri->user = 0;
    uri->pass = 0;
    uri->host = 0;
    uri->port = 0;
    uri->dir = 0;
    uri->fname = 0;
    uri->fext = 0;
    uri->query = 0;
    uri->frag = 0;
}

_AFXINL void AfxUriDeallocate(afxUri *uri)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(uri, afxFcc_URI);
    //AfxAssert(uri->str.flags & _AFX_STR_FLAG_ALLOCED);
    
    AfxDeallocateString(&uri->str);
    AfxResetUri(uri);
}

_AFXINL afxError AfxUriAllocate(afxUri* uri, afxNat cap, void const *start, afxNat range)
{
    afxError err = AFX_ERR_NONE;
    AfxResetUri(uri);

    if (AfxAllocateString(&uri->str, cap, start, range))
        AfxThrowError();

    AfxReparseUri(uri);
    return err;
}

#if 0
_AFXINL afxError AfxUriReallocate(afxUri *uri, afxNat cap, void const *start, afxNat range)
{
    afxError err = AFX_ERR_NONE;
    AfxTryAssertType(uri, afxFcc_URI);
    void *buf = NIL;

    if (start && !range)
        range = AfxMeasureRawString(start);

    AfxAssert(!range || (range && start));

    {
        AfxAssertType(uri, afxFcc_URI);
        //AfxAssert(uri->str.flags & _AFX_STR_FLAG_ALLOCED);

        afxNat effectiveCap = cap ? cap : range;
        AfxAssert(effectiveCap);

        if (AfxReallocateString(&uri->str, effectiveCap, start, range))
             AfxThrowError();

        AfxReparseUri(uri);
    }
    return err;
}
#endif

_AFXINL afxError AfxCloneUriPath(afxUri* uri, afxUri const *in)
{
    afxError err = AFX_ERR_NONE;

    if (in)
    {
        AfxAssertType(in, afxFcc_URI);
        afxUri *uri2 = NIL;

        afxUri path;
        afxNat pathLen = AfxExcerptUriPath(&path, in);
        AfxAssert(pathLen);

        if (pathLen)
        {
            if (AfxCloneUri(uri, &path))
                AfxThrowError();

            AfxAssert(uri);
        }
    }
    else
    {
        AfxResetUri(uri);
    }
    return err;
}

_AFXINL afxError AfxCloneUriName(afxUri* uri, afxUri const *in)
{
    afxError err = AFX_ERR_NONE;

    if (in)
    {
        AfxAssertType(in, afxFcc_URI);
        afxUri *uri2 = NIL;

        afxUri name;
        afxNat nameLen = AfxExcerptUriName(&name, in);
        AfxAssert(nameLen);

        if (nameLen)
        {
            if (AfxCloneUri(uri, &name))
                AfxThrowError();

            AfxAssert(uri);
        }
    }
    else
    {
        AfxResetUri(uri);
    }
    return err;
}

_AFXINL afxError AfxCloneUri(afxUri* uri, afxUri const *in)
{
    afxError err = AFX_ERR_NONE;

    if (in)
    {
        AfxAssertType(in, afxFcc_URI);
        afxNat strLen = AfxGetStringSize(&in->str);
        AfxAssert(strLen);
        void const *strData = AfxGetStringDataConst(&in->str, 0);
        AfxAssert(strData);

        if (AfxUriAllocate(uri, 0, strData, strLen))
            AfxThrowError();

        AfxAssert(uri);
    }
    else
    {
        AfxResetUri(uri);
    }
    return err;
}

_AFX void AfxUri128(afxUri128 *uri)
{
    afxError err = AFX_ERR_NONE;
    AfxAssert(uri);
    AfxUriWrapBuffer(&uri->uri, uri->buf, sizeof(uri->buf));
}

_AFX void AfxUri2048(afxUri2048 *uri)
{
    afxError err = AFX_ERR_NONE;
    AfxAssert(uri);
    AfxUriWrapBuffer(&uri->uri, uri->buf, sizeof(uri->buf));
}
