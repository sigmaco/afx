/*
 *          ::::::::  :::       :::     :::     :::::::::  :::::::::   ::::::::
 *         :+:    :+: :+:       :+:   :+: :+:   :+:    :+: :+:    :+: :+:    :+:
 *         +:+    +:+ +:+       +:+  +:+   +:+  +:+    +:+ +:+    +:+ +:+    +:+
 *         +#+    +:+ +#+  +:+  +#+ +#++:++#++: +#+    +:+ +#++:++#:  +#+    +:+
 *         +#+  # +#+ +#+ +#+#+ +#+ +#+     +#+ +#+    +#+ +#+    +#+ +#+    +#+
 *         #+#   +#+   #+#+# #+#+#  #+#     #+# #+#    #+# #+#    #+# #+#    #+#
 *          ###### ###  ###   ###   ###     ### #########  ###    ###  ########
 *
 *              T H E   Q W A D R O   E X E C U T I O N   E C O S Y S T E M
 *
 *                                   Public Test Build
 *                   (c) 2017 SIGMA Technology Group � Federa��o SIGMA
 *                                    www.sigmaco.org
 */

#define _CRT_SECURE_NO_WARNINGS 1
#include <stdio.h>
#include <string.h>

#define _AFX_CONTEXT_C
#define _AFX_CONTEXT_C
#define _AFX_CONTEXT_C
#define _AFX_SYSTEM_C
#include "afx/core/afxContext.h"
#include "afx/core/afxContext.h"
#include "afx/core/afxThread.h"
#include "afx/core/afxSystem.h"
#include "../src/e2coree/core/afxCoreHideout.h"

typedef struct _afxArbitraryChunk
{
#ifndef _AFX_DONT_DEBUG_MEM_LEAK
    afxNat16            line;
    afxChar const       *file;
#endif
    _AFX_DBG_FCC
    afxSimd(uintptr_t)  data[];
} _afxArbitraryChunk;

#if 0
_AFX afxBool _AfxGetMemD(afxContext ctx, struct _afxCtxD **ctx, struct _afxSysD* sysD)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertObjects(1, &ctx, afxFcc_CTX);
    AfxAssert(ctx);
    AfxAssertType(sysD, afxFcc_SYS);
    return AfxExposeResidentObjects(1, &ctx, (void**)ctx, &sysD->memories);
}
#endif

_AFX void _AfxMemAllocNotStd(afxContext ctx, afxSize siz, afxHint const hint)
{
    //AfxEntry("ctx=%p,p=%p,siz=%u,hint=\"%s:%i!%s\"", ctx, p, siz, AfxFindPathTarget((char const *const)hint[0]), (int)hint[1], (char const *const)hint[2]);
    afxError err = AFX_ERR_NONE;
    AfxAssertObjects(1, &ctx, afxFcc_CTX);
    //AfxAssert(p);
    AfxAssert(siz);
    AfxAssert(hint);
}

_AFX void _AfxMemDeallocNotStd(afxContext ctx, afxSize siz, afxHint const hint)
{
    //AfxEntry("ctx=%p,p=%p,siz=%u,hint=\"%s:%i!%s\"", ctx, p, siz, AfxFindPathTarget((char const *const)hint[0]), (int)hint[1], (char const *const)hint[2]);
    afxError err = AFX_ERR_NONE;
    AfxAssertObjects(1, &ctx, afxFcc_CTX);
    //AfxAssert(p);
    //AfxAssert(siz);
    AfxAssert(hint);
}

_AFX void _AfxMemDeallocStd(afxContext ctx, void *p)
{
    //AfxEntry("p=%p", p);
    afxError err = AFX_ERR_NONE;
    AfxAssertObjects(1, &ctx, afxFcc_CTX);

    AfxAssert(p);

    _aligned_free(p);

    if (ctx->deallocNotCb)
        ctx->deallocNotCb(ctx, 0, AfxSpawnHint());
}

_AFX void* _AfxMemReallocStd(afxContext ctx, void* p, afxSize siz, afxSize align, afxHint const hint)
{
    //AfxEntry("ctx=%p,p=%p,siz=%u,hint=\"%s:%i!%s\"", ctx, p, siz, AfxFindPathTarget((char const *const)hint[0]), (int)hint[1], (char const *const)hint[2]);
    afxError err = AFX_ERR_NONE;
    AfxAssertObjects(1, &ctx, afxFcc_CTX);
    //AfxAssert(p);
    AfxAssert(siz);
    void *neo = NIL;

    // TODO Allow rememocate to an or another memocator.

    if (!(neo = _aligned_realloc(p, siz, align ? align : AFX_SIMD_ALIGN)))
        AfxThrowError();

    return neo;
}

_AFX void* _AfxMemAllocStd(afxContext ctx, afxSize siz, afxSize align, afxHint const hint)
{
    //AfxEntry("ctx=%p,siz=%u,hint=\"%s:%i!%s\"", ctx, siz, AfxFindPathTarget((char const *const)hint[0]), (int)hint[1], (char const *const)hint[2]);
    afxError err = AFX_ERR_NONE;
    AfxAssertObjects(1, &ctx, afxFcc_CTX);
    AfxAssert(siz);
    AfxAssert(hint);
    void *p = NIL;

    if (!(p = _aligned_malloc(siz, align ? align : AFX_SIMD_ALIGN)))
        AfxThrowError();

    return p;
}

// ALL API

_AFX afxSize AfxMemoryGetDefaultAlignment(afxContext ctx)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertObjects(1, &ctx, afxFcc_CTX);
    return ctx->defAlign;
}

_AFX afxError AfxMemoryEnableDebugging(afxContext ctx, afxNat level)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertObjects(1, &ctx, afxFcc_CTX);
    ctx->dbgLevel = level;
    return err;
}

_AFX afxNat AfxEnumerateContexts(afxNat first, afxNat cnt, afxContext mem[])
{
    afxError err = AFX_ERR_NONE;
    AfxAssert(cnt);
    AfxAssert(mem);
    afxSystem sys;
    AfxGetSystem(&sys);
    AfxAssertObjects(1, &sys, afxFcc_SYS);
    AfxAssertClass(&sys->memories, afxFcc_CTX);
    return AfxEnumerateInstances(&sys->memories, first, cnt, (afxHandle*)mem);
}

_AFX afxError _AfxCtxDtor(afxContext ctx)
{
    AfxEntry("ctx=%p", ctx);
    afxError err = AFX_ERR_NONE;

    AfxAssertObjects(1, &ctx, afxFcc_CTX);
    
    ctx->dbgLevel = 3;

    //afxResult rslt = AfxMemoryExhaust(ctx);

    //if (rslt)
//        AfxAdvertise("Recovered. %i bytes orphaned @ (ctx)%p", rslt, ctx);

    return err;
}

_AFX afxError _AfxCtxCtor(afxContext ctx, afxCookie const* cookie)
{
    AfxEntry("ctx=%p", ctx);
    afxError err = AFX_ERR_NONE;

    AfxAssertObjects(1, &ctx, afxFcc_CTX);

    afxAllocationStrategy const *as = cookie->udd[0] ? ((afxAllocationStrategy const*)cookie->udd[0]) + cookie->no : NIL;
    afxSize const *hint = ((afxSize const*)cookie->udd[1]) + cookie->no;
    //AfxAssert(as);

    //AfxAssert(!as->align || as->align >= AFX_SIMD_ALIGN);
    ctx->defAlign = AFX_SIMD_ALIGN;

    ctx->dbgLevel = 3;

    ctx->fname = (char const *const)hint[0];
    ctx->fline = (int)hint[1];
    ctx->func = (char const *const)hint[2];

    if (as)
    {
        if (as->align)
            ctx->defAlign = as->align;
    }


    // Choose which memocation mechanism to be used. Actumemy there's just two: standard (arbitrary) and arena.

    //if (ctx->cap != (afxSize)0) _AfxArenaAllCtor(ctx, paradigm);
    //else
    {
        ctx->allocCb = _AfxMemAllocStd;
        ctx->reallocCb = _AfxMemReallocStd;
        ctx->deallocCb = _AfxMemDeallocStd;
        ctx->allocNotCb = _AfxMemAllocNotStd;
        ctx->deallocNotCb = _AfxMemDeallocNotStd;

        //_AfxMemCtorArena(ctx);
    }
    return err;
}

_AFX afxError AfxAcquireContexts(afxNat cnt, afxContext ctx[], afxAllocationStrategy const strategy[], afxHint const hint)
{
    AfxEntry("cnt=%u,app=%p,strategy=%p", cnt, ctx, strategy);
    afxError err = AFX_ERR_NONE;

    afxSystem sys;
    AfxGetSystem(&sys);
    AfxAssertObjects(1, &sys, afxFcc_SYS);
    AfxAssertClass(&sys->memories, afxFcc_CTX);

    if (AfxAcquireObjects(&sys->memories, cnt, (afxHandle*)ctx, (void*[]) { (void*)strategy, (void*)hint }))
        AfxThrowError();

    return err;
}

// MEMORY API

_AFX void AfxStream(afxNat cnt, afxSize srcStride, afxNat dstStride, void const* src, void* dst)
{
    afxError err = AFX_ERR_NONE;
    AfxAssert(src);
    AfxAssert(dst);
    AfxAssert(src != dst);
    AfxAssert(cnt);
    AfxAssert(srcStride);
    AfxAssert(dstStride);

    afxByte* dst2 = dst;
    afxByte const* src2 = src;
    afxSize unitSiz = AfxMinor(dstStride, srcStride);

    if ((dstStride == srcStride) && dstStride) AfxCopy(dst2, src2, unitSiz * cnt);
    else for (afxNat i = 0; i < cnt; i++)
        AfxCopy(&dst2[i * dstStride], &src2[i * srcStride], unitSiz);
}

_AFX void AfxCopy(void *dst, void const *src, afxSize range)
{
    afxError err = AFX_ERR_NONE;
    AfxAssert(src);
    AfxAssert(dst);
    AfxAssert(src != dst);
    AfxAssert(range);

    memcpy(dst, src, range);
    return;
    
    register afxChar* dst2 = dst;
    register afxChar const* src2 = src;
    register afxSize t = (afxOffset)src2;

    if ((afxSize)dst2 < (afxSize)src2)
    {
        if ((t | (afxOffset)dst2) & (sizeof(afxSize) - 1))
        {
            t = ((t ^ (afxOffset)dst2) & (sizeof(afxSize) - 1) || range < sizeof(afxSize)) ? range : (sizeof(afxSize) - (t & (sizeof(afxSize) - 1)));
            range -= t;
            do { (*(dst2)++ = *(src2)++); } while (--(t));
        }

        if ((t = range / sizeof(afxSize)))
            do { *(afxSize*)dst2 = *(afxSize*)src2; src2 += sizeof(afxSize); dst2 += sizeof(afxSize); } while (--(t));

        if ((t = range & (sizeof(afxSize) - 1)))
            do { *(dst2)++ = *(src2)++; } while (--(t));
    }
    else
    {
        src2 += range;
        dst2 += range;

        if ((t | (afxOffset)dst2) & (sizeof(afxSize) - 1))
        {
            if ((t ^ (afxOffset)dst2) & (sizeof(afxSize) - 1) || range <= sizeof(afxSize)) t = range;
            else t &= (sizeof(afxSize) - 1);

            range -= t;
            do { *(--(dst2)) = *(--(src2)); } while (--(t));
        }

        if ((t = range / sizeof(afxSize)))
            do { src2 -= sizeof(afxSize); dst2 -= sizeof(afxSize); *(afxSize*)dst2 = *(afxSize*)src2; } while (--(t));

        if ((t = range & (sizeof(afxSize) - 1)))
            do { *(--(dst2)) = *(--(src2)); } while (--(t));
    }
}

_AFX void AfxFill(void *p, afxNat cnt, afxNat unitSiz, void const* value)
{
    // This function fills the first 'cnt' sets of 'unitSiz' bytes of memory area pointed by 'p' with the constant 'value'.

    afxError err = AFX_ERR_NONE;
    AfxAssert(p);
    AfxAssert(cnt);
    //AfxAssert(value);
    AfxAssert(unitSiz);

    //afxApplication app = AfxApplicationGet();

    if (value)
    {
        for (afxNat i = 0; i < cnt; i++)
        {
            afxByte* ptr = (afxByte*)p;
            AfxCopy(&ptr[i * unitSiz], value, unitSiz);
        }
    }
    else
    {
        memset(p, 0, cnt * unitSiz);
    }
}

_AFX void AfxZero(void *p, afxSize range)
{
    afxError err = AFX_ERR_NONE;
    AfxAssert(p);
    AfxAssert(range);
    AfxFill(p, range, sizeof(afxByte), 0);
}

_AFX void AfxDeallocate(afxContext ctx, void *p)
{
    afxError err = AFX_ERR_NONE;

    if (p)
    {
        AfxAssert(p);
        afxSize freedSiz = 0;

        if (ctx)
        {
            AfxAssertObjects(1, &ctx, afxFcc_CTX);

            ctx->deallocCb(ctx, p);
        }
        else
        {
            _aligned_free(p);
        }
    }
}

_AFX void* AfxReallocate(afxContext ctx, void *p, afxSize siz, afxNat align, afxHint const hint)
{
    afxError err = AFX_ERR_NONE;
    AfxAssert(siz);
    AfxAssert(hint);
    //AfxEntry("p=%p,siz=%u,hint=\"%s:%i!%s\"", p, siz, AfxFindPathTarget((char const *const)hint[0]), (int)hint[1], (char const *const)hint[2]);
    void *out = NIL;

    if (p)
    {
        if (!ctx)
        {

            if (!(out = _aligned_realloc(p, siz, align ? align : AFX_SIMD_ALIGN)))
                AfxThrowError();

            return out;
        }
        else
        {
            AfxAssertObjects(1, &ctx, afxFcc_CTX);

            if (!(out = ctx->reallocCb(ctx, p, siz, align, hint)))
                AfxThrowError();

            return out;
        }
    }
    else
    {
        if (ctx)
        {
            AfxAssertObjects(1, &ctx, afxFcc_CTX);

            if (!(out = ctx->reallocCb(ctx, p, siz, align, hint)))
                AfxThrowError();

            return out;
        }
        else
        {
            if (!(out = _aligned_realloc(NIL, siz, align ? align : AFX_SIMD_ALIGN)))
                AfxThrowError();

            return out;
        }
    }
    return out;
}

_AFX void* AfxCoallocate(afxContext ctx, afxSize cnt, afxSize siz, afxNat align, afxHint const hint)
{
    //AfxEntry("ctx=%p,cnt=%u,siz=%u,hint=\"%s:%i!%s\"", ctx, cnt, siz, AfxFindPathTarget((char const *const)hint[0]), (int)hint[1], (char const *const)hint[2]);
    afxError err = AFX_ERR_NONE;
    AfxAssert(cnt);
    AfxAssert(siz);
    AfxAssert(hint);
    void *p = NIL;

    if (ctx)
    {
        AfxAssertObjects(1, &ctx, afxFcc_CTX);

        if (!(p = ctx->allocCb(ctx, cnt * siz, align, hint)))
            AfxThrowError();
    }
    else
    {
        if (!(p = _aligned_recalloc(NIL, 1, (cnt * siz), align ? align : AFX_SIMD_ALIGN)))
            AfxThrowError();
    }
    return p;
}

_AFX void* AfxAllocate(afxContext ctx, afxSize siz, afxNat align, afxHint const hint)
{
    //AfxEntry("ctx=%p,siz=%u,hint=\"%s:%i!%s\"", ctx, siz, AfxFindPathTarget((char const *const)hint[0]), (int)hint[1], (char const *const)hint[2]);
    afxError err = AFX_ERR_NONE;
    AfxAssert(hint);
    AfxAssert(siz);
    void *p = NIL;

    if (siz)
    {
        if (ctx)
        {
            AfxAssertObjects(1, &ctx, afxFcc_CTX);

            if (!(p = ctx->allocCb(ctx, siz, align, hint)))
                AfxThrowError();

            return p;
        }
        else
        {
            if (!(p = _aligned_malloc(siz, align ? align : AFX_SIMD_ALIGN)))
                AfxThrowError();

            return p;
        }
    }
    return p;
}













_AFX afxError AfxMapMemory(afxMem *mem, afxSize off, afxNat siz, void **ptr) // Map a memory object into application address space
{
    afxError err = NIL;
    AfxAssert(mem);
    return err;
}

_AFX void AfxUnmapMemory(afxMem *mem) // Unmap a previously mapped memory object
{
    afxError err = NIL;
    AfxAssert(mem);

}

_AFX afxError AfxAllocateMemory(afxMem *mem, afxMem *parent, afxNat siz, afxNat align) // Allocate memory
{
    afxError err = NIL;
    AfxAssert(mem);
    return err;
}

_AFX afxError AfxReallocateMemory(afxMem *mem, afxNat siz, afxNat align)
{
    afxError err = NIL;
    AfxAssert(mem);
    return err;
}

_AFX void AfxDeallocateMemory(afxMem *mem) // Free memory
{
    afxError err = NIL;
    AfxAssert(mem);
    
}

_AFX afxError AfxCopyMemoryRange(afxMem *mem, afxMem const* in, afxNat offset, afxNat range) // returns non-copied range in error occurence.
{
    afxError err = NIL;
    AfxAssert(mem);
    AfxAssert(in);
    AfxAssertRange(mem->siz, 0, range);
    AfxAssertRange(in->siz, offset, range);
    void *dst, *src;
    afxError errSiz;

    if ((errSiz = AfxMapMemory(mem, 0, range, &dst))) AfxThrowError();
    else
    {
        if ((errSiz = AfxMapMemory((void*)in, offset, range, &src))) AfxThrowError();
        else
        {
            AfxCopy(dst, src, AfxAbs(range - errSiz));
            AfxUnmapMemory((void*)in);
        }
        AfxUnmapMemory(mem);
    }
    return errSiz;
}

_AFX afxError AfxCopyMemory(afxMem *mem, afxMem const* in) // returns non-copied range in error occurence.
{
    afxError err = NIL;
    AfxAssert(mem);
    afxError errSiz;

    if ((errSiz = AfxCopyMemoryRange(mem, in, 0, mem->siz)))
        AfxThrowError();

    return errSiz;
}

_AFX afxError AfxZeroMemoryRange(afxMem *mem, afxNat offset, afxNat range) // returns non-copied range in error occurence.
{
    afxError err = NIL;
    AfxAssert(mem);
    AfxAssertRange(mem->siz, offset, range);
    afxError errSiz;
    void *ptr;

    if ((errSiz = AfxMapMemory(mem, offset, range, &ptr))) AfxThrowError();
    else
    {
        AfxZero(ptr, mem->siz);
        AfxUnmapMemory(mem);
    }
    return errSiz;
}

_AFX void AfxZeroMemory(afxMem *mem)
{
    afxError err = NIL;
    AfxAssert(mem);
    afxError errSiz;

    if ((errSiz = AfxZeroMemoryRange(mem, 0, mem->siz)))
        AfxThrowError();
}

_AFX afxClassConfig _AfxCtxClsConfig =
{
    .fcc = afxFcc_CTX,
    .name = "Context",
    .unitsPerPage = 1,
    .size = sizeof(AFX_OBJECT(afxContext)),
    .ctx = NIL,
    .ctor = (void*)_AfxCtxCtor,
    .dtor = (void*)_AfxCtxDtor
};
