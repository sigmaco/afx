/*
 *          ::::::::  :::       :::     :::     :::::::::  :::::::::   ::::::::
 *         :+:    :+: :+:       :+:   :+: :+:   :+:    :+: :+:    :+: :+:    :+:
 *         +:+    +:+ +:+       +:+  +:+   +:+  +:+    +:+ +:+    +:+ +:+    +:+
 *         +#+    +:+ +#+  +:+  +#+ +#++:++#++: +#+    +:+ +#++:++#:  +#+    +:+
 *         +#+  # +#+ +#+ +#+#+ +#+ +#+     +#+ +#+    +#+ +#+    +#+ +#+    +#+
 *         #+#   +#+   #+#+# #+#+#  #+#     #+# #+#    #+# #+#    #+# #+#    #+#
 *          ###### ###  ###   ###   ###     ### #########  ###    ###  ########
 *
 *              T H E   Q W A D R O   E X E C U T I O N   E C O S Y S T E M
 *
 *                                   Public Test Build
 *                   (c) 2017 SIGMA Technology Group � Federa��o SIGMA
 *                                    www.sigmaco.org
 */

#define _CRT_SECURE_NO_WARNINGS 1
#define WIN32_LEAN_AND_MEAN 1

#include <sys/stat.h>
#include <stdio.h>

#if (defined(_WIN32) || defined(_WIN64))
#   include <Windows.h>
#   include <Shlwapi.h>
#   include <combaseapi.h>
#else
#   include <unistd.h>
#endif

#define _AFX_MODULE_C
#define _AFX_SYSTEM_C
#include "afx/core/afxSystem.h"
#include "../src/e2coree/core/afxCoreHideout.h"

_AFX afxResult AfxFindModuleSymbols(afxModule mdle, afxNat cnt, afxChar const *name[], void *sym[])
{
    afxError err = AFX_ERR_NONE;
    AfxAssertObjects(1, &mdle, afxFcc_MDLE);

    AfxAssert(cnt);
    AfxAssert(name);
    afxResult hitCnt = 0;

    for (afxNat i = 0; i < cnt; i++)
    {
        if ((sym[i] = (void*)GetProcAddress(mdle->osHandle, name[i]))) hitCnt++;
        else
        {
            //AfxError("Symbol %s not found.", name[i]);
        }
    }
    return hitCnt;
}

_AFX void* AfxFindModuleSymbol(afxModule mdle, afxChar const *name)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertObjects(1, &mdle, afxFcc_MDLE);

    AfxAssert(name);    
    return (void*)GetProcAddress(mdle->osHandle, name);
}

_AFX afxUri const* AfxGetModulePath(afxModule mdle)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertObjects(1, &mdle, afxFcc_MDLE);
    return &mdle->path;
}

_AFX afxNat AfxEnumerateModules(afxNat first, afxNat cnt, afxModule mdle[])
{
    afxError err = AFX_ERR_NONE;
    AfxAssert(cnt);
    AfxAssert(mdle);
    afxSystem sys;
    AfxGetSystem(&sys);
    AfxAssertObjects(1, &sys, afxFcc_SYS);
    AfxAssertClass(&sys->modules, afxFcc_MDLE);
    return AfxEnumerateInstances(&sys->modules, first, cnt, (afxHandle*)mdle);
}

_AFX afxModule AfxFindModule(afxUri const *uri)
{
    afxError err = AFX_ERR_NONE;
    
    afxNat i = 0;
    afxModule mdle;
    while (AfxEnumerateModules(i, 1, &mdle))
    {
        AfxAssertObjects(1, &mdle, afxFcc_MDLE);

        if (AfxUriIsEquivalent(AfxGetModulePath(mdle), uri))
            return mdle;

        ++i;
    }
    return NIL;
}

_AFX afxError _AfxMdleDtor(afxModule mdle)
{
    AfxEntry("mdle=%p", mdle);
    afxError err = AFX_ERR_NONE;
    AfxAssertObjects(1, &mdle, afxFcc_MDLE);

    //if (mdle->osHandle != AfxApplicationGet()->e2coree->osHandle)

    AfxUriDeallocate(&mdle->path);

    if (mdle->hasBeenLoaded)
        FreeLibrary(mdle->osHandle);

    return err;
}

_AFX afxError _AfxMdleCtor(afxModule mdle, afxCookie const* cookie)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertObjects(1, &mdle, afxFcc_MDLE);

    afxUri const* uri = ((afxUri const*)cookie->udd[0]) + cookie->no;

    AfxEntry("uri:%.*s", AfxPushString(uri ? AfxUriGetStringConst(uri) : &AFX_STR_EMPTY));

    afxBool isEmpty = !uri || AfxUriIsBlank(uri);
    AfxAssert(!isEmpty);
    afxResult success = FALSE, loaded = FALSE;
    
    afxUri128 absUri;
    AfxUri128(&absUri);

    AfxResolveUri(uri, AFX_FILE_FLAG_R, &absUri.uri);

    //afxString1024 str;
    //AfxString1024(&str, 0, 0);
    afxUri path;
    //AfxCopyString(AfxExcerptUriPath(&absUri, &tmp), &str.str);
    AfxExcerptUriPath(&path, &absUri.uri);
    afxString const *pathStr = AfxUriGetString(&path);

    HMODULE oshandle;// = GetModuleHandleA(AfxGetStringDataConst(pathStr, 0));

    //if (!oshandle)
    {
        if (!(loaded = !!(oshandle = LoadLibraryA(AfxGetStringDataConst(pathStr, 0)))))
            AfxThrowError();
    }

    if (oshandle)
    {
        success = TRUE;
        AfxCloneUri(&mdle->path, uri);
        mdle->osHandle = oshandle;
        mdle->hasBeenLoaded = loaded;

        if (FALSE == success)
        {
            if (loaded)
                FreeLibrary(oshandle);
        }
    }
    return err;
}

_AFX afxError AfxAcquireModules(afxNat cnt, afxModule mdle[], afxUri const uri[])
{
    AfxEntry("cnt=%u,mdle=%p,uri=%p", cnt, mdle, uri);
    afxError err = AFX_ERR_NONE;

    afxSystem sys;
    AfxGetSystem(&sys);
    AfxAssertObjects(1, &sys, afxFcc_SYS);
    AfxAssertClass(&sys->modules, afxFcc_MDLE);

    for (afxNat i = 0; i < cnt; i++)
    {
        afxModule tmp = AfxFindModule(&uri[i]);

        if (tmp)
        {
            if (AfxReacquireObjects(1, (afxHandle*)&tmp)) AfxThrowError();
            else
            {
                mdle[i] = tmp;
            }
        }
        else
        {
            if (AfxAcquireObjects(&sys->modules, 1, (afxHandle*)&mdle[i], (void*[]) { (void*)&uri[i] }))
                AfxThrowError();
        }

        if (err)
        {
            AfxReleaseObjects(i, (afxHandle*)mdle);
            break;
        }
    }
    return err;
}

_AFX afxClassConfig _AfxMdleClsConfig =
{
    .fcc = afxFcc_MDLE,
    .name = "Module",
    .unitsPerPage = 10,
    .size = sizeof(AFX_OBJECT(afxModule)),
    .ctx = NIL,
    .ctor = (void*)_AfxMdleCtor,
    .dtor = (void*)_AfxMdleDtor
};
