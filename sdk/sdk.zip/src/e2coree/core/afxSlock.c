/*
 *          ::::::::  :::       :::     :::     :::::::::  :::::::::   ::::::::
 *         :+:    :+: :+:       :+:   :+: :+:   :+:    :+: :+:    :+: :+:    :+:
 *         +:+    +:+ +:+       +:+  +:+   +:+  +:+    +:+ +:+    +:+ +:+    +:+
 *         +#+    +:+ +#+  +:+  +#+ +#++:++#++: +#+    +:+ +#++:++#:  +#+    +:+
 *         +#+  # +#+ +#+ +#+#+ +#+ +#+     +#+ +#+    +#+ +#+    +#+ +#+    +#+
 *         #+#   +#+   #+#+# #+#+#  #+#     #+# #+#    #+# #+#    #+# #+#    #+#
 *          ###### ###  ###   ###   ###     ### #########  ###    ###  ########
 *
 *              T H E   Q W A D R O   E X E C U T I O N   E C O S Y S T E M
 *
 *                                   Public Test Build
 *                   (c) 2017 SIGMA Technology Group � Federa��o SIGMA
 *                                    www.sigmaco.org
 */

#define _CRT_SECURE_NO_WARNINGS 1
#define WIN32_LEAN_AND_MEAN 1

#include <sys/stat.h>
#include <stdio.h>

#if (defined(_WIN32) || defined(_WIN64))
#   include <Windows.h>
#   include <Shlwapi.h>
#   include <combaseapi.h>
#else
#   include <unistd.h>
#endif

#include "afx/core/afxSlock.h"
#include "afx/core/afxThread.h"


AFX afxBool AfxTryEnterSlockShared(afxSlock *slck)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(slck, afxFcc_SLCK);
    return TryAcquireSRWLockShared((PSRWLOCK)&slck->srwl);
}

AFX afxBool AfxTryEnterSlockExclusive(afxSlock *slck)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(slck, afxFcc_SLCK);
    afxBool rslt = TryAcquireSRWLockExclusive((PSRWLOCK)&slck->srwl);

    if (rslt)
    {
        slck->tidEx;
        AfxGetThreadingId(&slck->tidEx);
    }
    return rslt;
}

AFX void AfxEnterSlockShared(afxSlock *slck)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(slck, afxFcc_SLCK);
    AcquireSRWLockShared((PSRWLOCK)&slck->srwl);
}

AFX void AfxEnterSlockExclusive(afxSlock *slck)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(slck, afxFcc_SLCK);
    AcquireSRWLockExclusive((PSRWLOCK)&slck->srwl);
    AfxGetThreadingId(&slck->tidEx);
}

AFX void AfxExitSlockShared(afxSlock *slck)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(slck, afxFcc_SLCK);
    ReleaseSRWLockShared((PSRWLOCK)&slck->srwl);
}

AFX void AfxExitSlockExclusive(afxSlock *slck)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(slck, afxFcc_SLCK);
    afxNat32 tid;
    AfxGetThreadingId(&tid);
    AfxAssert(slck->tidEx = tid);
    ReleaseSRWLockExclusive((PSRWLOCK)&slck->srwl);
    slck->tidEx = 0;
}

AFX afxError AfxReleaseSlock(afxSlock *slck)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(slck, afxFcc_SLCK);
    AfxAssignTypeFcc(slck, 0);
    slck->srwl = 0;
    slck->tidEx = 0;
    return err;
}

AFX afxError AfxAcquireSlock(afxSlock *slck)
{
    afxError err = AFX_ERR_NONE;
    AfxAssert(slck);
    AfxAssignTypeFcc(slck, afxFcc_SLCK);
    InitializeSRWLock((PSRWLOCK)&slck->srwl);
    slck->tidEx = 0;
    return err;
}
