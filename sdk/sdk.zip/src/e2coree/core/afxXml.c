/*
 *          ::::::::  :::       :::     :::     :::::::::  :::::::::   ::::::::
 *         :+:    :+: :+:       :+:   :+: :+:   :+:    :+: :+:    :+: :+:    :+:
 *         +:+    +:+ +:+       +:+  +:+   +:+  +:+    +:+ +:+    +:+ +:+    +:+
 *         +#+    +:+ +#+  +:+  +#+ +#++:++#++: +#+    +:+ +#++:++#:  +#+    +:+
 *         +#+  # +#+ +#+ +#+#+ +#+ +#+     +#+ +#+    +#+ +#+    +#+ +#+    +#+
 *         #+#   +#+   #+#+# #+#+#  #+#     #+# #+#    #+# #+#    #+# #+#    #+#
 *          ###### ###  ###   ###   ###     ### #########  ###    ###  ########
 *
 *              T H E   Q W A D R O   E X E C U T I O N   E C O S Y S T E M
 *
 *                                   Public Test Build
 *                   (c) 2017 SIGMA Technology Group � Federa��o SIGMA
 *                                    www.sigmaco.org
 */

#define _CRT_SECURE_NO_WARNINGS 1
#include <assert.h>
#include <ctype.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define _AFX_XML_C
#include "afx/core/afxXml.h"
#include "afx/core/afxStream.h"
#include "afx/core/afxSystem.h"

static char* xml_strtok_r(char *str, const char *delim, char **nextp) {
    char *ret;

    if (str == NULL) {
        str = *nextp;
    }

    str += strspn(str, delim);

    if (*str == '\0') {
        return NULL;
    }

    ret = str;

    str += strcspn(str, delim);

    if (*str) {
        *str++ = '\0';
    }

    *nextp = str;

    return ret;
}

/**
 * [OPAQUE API]
 *
 * UTF-8 text
 */

/**
 * [OPAQUE API]
 *
 * An xml_attribute may contain text content.
 */

/**
 * [OPAQUE API]
 *
 * An xml_node will always contain a tag name, a 0-terminated list of attributes
 * and a 0-terminated list of children. Moreover it may contain text content.
 */

/**
 * [PRIVATE]
 *
 * Parser context
 */
struct xml_parser {
    afxByte *buffer;
    afxSize position;
    afxSize length;
};

/**
 * [PRIVATE]
 *
 * Character offsets
 */
enum xml_parser_offset {
    NO_CHARACTER = -1,
    CURRENT_CHARACTER = 0,
    NEXT_CHARACTER = 1,
};





/**
 * [PRIVATE]
 *
 * @return Number of attributes in 0-terminated array
 */
static size_t get_zero_terminated_array_attributes(afxXmlAttr** attributes)
{
    size_t elements = 0;

    while (attributes[elements]) {
        ++elements;
    }

    return elements;
}



/**
 * [PRIVATE]
 *
 * @return Number of nodes in 0-terminated array
 */
static size_t get_zero_terminated_array_nodes(afxXmlNode** nodes)
{
    size_t elements = 0;

    while (nodes[elements]) {
        ++elements;
    }

    return elements;
}


/**
 * [PRIVATE]
 *
 * Frees the resources allocated by the attribute
 */
static void AfxXmlNodeAttrDelete(afxXml* xml, afxXmlAttr* attribute)
{
    afxError err = AFX_ERR_NONE;
    AfxAssert(attribute);

    afxContext mem = AfxGetIoContext();
    AfxAssertObjects(1, &mem, afxFcc_CTX);

    AfxDeallocate(mem, attribute);
}

/**
 * [PRIVATE]
 *
 * Frees the resources allocated by the node
 */
static void AfxXmlNodeDelete(afxXml* xml, afxXmlNode *node)
{
    afxError err = AFX_ERR_NONE;
    AfxAssert(node);

    afxContext mem = AfxGetIoContext();
    AfxAssertObjects(1, &mem, afxFcc_CTX);

    afxXmlAttr** at = node->attributes;
    while (*at)
    {
        AfxXmlNodeAttrDelete(xml, *at);
        ++at;
    }

    AfxDeallocate(mem, node->attributes);

    afxXmlNode** it = node->children;

    while (*it)
    {
        AfxXmlNodeDelete(xml, *it);
        ++it;
    }

    AfxDeallocate(mem, node->children);

    AfxDeallocate(mem, node);
}


/**
 * [PRIVATE]
 *
 * Returns the n-th not-whitespace byte in parser and 0 if such a byte does not
 * exist
 */
static uint8_t _AfxXmlParsePeek(struct xml_parser* parser, size_t n) {
    size_t position = parser->position;

    while (position < parser->length) {
        if (!isspace(parser->buffer[position])) {
            if (n == 0) {
                return parser->buffer[position];
            }
            else {
                --n;
            }
        }

        position++;
    }

    return 0;
}



/**
 * [PRIVATE]
 *
 * Moves the parser's position n bytes. If the new position would be out of
 * bounds, it will be converted to the bounds itself
 */
static void _AfxXmlParseConsume(struct xml_parser* parser, size_t n) {

    /* Debug information
     */
#ifdef XML_PARSER_VERBOSE
#define min(X,Y) ((X) < (Y) ? (X) : (Y))
    char* consumed = alloca((n + 1) * sizeof(char));
    memcpy(consumed, &parser->buffer[parser->position], min(n, parser->length - parser->position));
    consumed[n] = 0;
#undef min

    size_t message_buffer_length = 512;
    char* message_buffer = alloca(512 * sizeof(char));
    snprintf(message_buffer, message_buffer_length, "Consuming %li bytes \"%s\"", (long)n, consumed);
    message_buffer[message_buffer_length - 1] = 0;

    xml_parser_info(parser, message_buffer);
#endif


    /* Move the position forward
     */
    parser->position += n;

    /* Don't go too far
     *
     * @warning Valid because parser->length must be greater than 0
     */
    if (parser->position >= parser->length) {
        parser->position = parser->length - 1;
    }
}



/**
 * [PRIVATE]
 *
 * Skips to the next non-whitespace character
 */
static void _AfxXmlParseSkipWhitespaces(struct xml_parser* parser) {

    while (isspace(parser->buffer[parser->position])) {
        if (parser->position + 1 >= parser->length) {
            return;
        }
        else {
            parser->position++;
        }
    }
}



/**
 * [PRIVATE]
 *
 * Finds and creates mem attributes on the given node.
 *
 * @author Blake Felt
 * @see https://github.com/Molorius
 */
static afxXmlAttr** _AfxXmlParseAttribs(afxXml* xml, struct xml_parser* parser, afxString *tag_open)
{
    afxError err = AFX_ERR_NONE;
    (void)parser;
    char* tmp;
    char* rest = NULL;
    char* token;
    char* str_name;
    char* str_content;
    const afxChar* start_name;
    const afxChar* start_content;
    size_t old_elements;
    size_t new_elements;
    afxXmlAttr* new_attribute;
    afxXmlAttr** attributes;
    int position;

    afxContext mem = AfxGetIoContext();
    AfxAssertObjects(1, &mem, afxFcc_CTX);

    attributes = AfxCoallocate(mem, 1, sizeof(afxXmlAttr*), 0, AfxSpawnHint());
    attributes[0] = 0;

    afxString128 tmpStr;
    AfxString128(&tmpStr);
    AfxCopyString(&tmpStr.str, tag_open);
    tmp = (char*)AfxGetStringData(&tmpStr.str,0);

    token = xml_strtok_r(tmp, " ", &rest); // skip the first value
    
    if (token != NULL)
    {

        //tag_open->range = strlen(token);
        afxNat trimRange = strlen(token);

        for (token = xml_strtok_r(NULL, " ", &rest); token != NULL; token = xml_strtok_r(NULL, " ", &rest))
        {
            str_name = AfxAllocate(mem, strlen(token) + 1, 0, AfxSpawnHint());
            str_content = AfxAllocate(mem, strlen(token) + 1, 0, AfxSpawnHint());
            // %s=\"%s\" wasn't working for some reason, ugly hack to make it work
            if (sscanf(token, "%[^=]=\"%[^\"]", str_name, str_content) != 2)
            {
                if (sscanf(token, "%[^=]=\'%[^\']", str_name, str_content) != 2)
                {
                    AfxDeallocate(mem, str_name);
                    AfxDeallocate(mem, str_content);
                    continue;
                }
            }
            position = token - tmp;
            start_name = &tag_open->src.start[position];
            start_content = &tag_open->src.start[position + strlen(str_name) + 2];

            new_attribute = AfxAllocate(mem, sizeof(afxXmlAttr), 0, AfxSpawnHint());
            AfxWrapStringLiteral(&new_attribute->name, start_name, strlen(str_name));
            AfxWrapStringLiteral(&new_attribute->content, start_content, strlen(str_content));

            old_elements = get_zero_terminated_array_attributes(attributes);
            new_elements = old_elements + 1;
            attributes = AfxReallocate(mem, attributes, (new_elements + 1) * sizeof(struct xml_attributes*), 0, AfxSpawnHint());

            attributes[new_elements - 1] = new_attribute;
            attributes[new_elements] = 0;


            AfxDeallocate(mem, str_name);
            AfxDeallocate(mem, str_content);
        }
        
        tag_open->range = trimRange;
    }
    return attributes;
}


/**
 * [PRIVATE]
 *
 * Parses an XML fragment node
 *
 * ---( Example without children )---
 * <Node>Text</Node>
 * ---
 *
 * ---( Example with children )---
 * <Parent>
 *     <Child>Text</Child>
 *     <Child>Text</Child>
 *     <Test>Content</Test>
 * </Parent>
 * ---
 */
static afxXmlNode* _AfxXmlParseNode(afxXml* xml, struct xml_parser* parser)
{
    afxError err = AFX_ERR_NONE;

    afxContext mem = AfxGetIoContext();
    AfxAssertObjects(1, &mem, afxFcc_CTX);

    ////////////////////////////////////////////////////////////

    // PROBLEMAS ATUAIS 2023/08/04


    // V�LIDO
    // <Pipeline name='yFlipped'>

    // INV�LIDO - N�o vai registrar o atributo.
    // <Pipeline name = 'yFlipped'>
    // <Pipeline name>

    // INV�LIDO - Vai causar erro no fechamento do node.
    // <Pipeline name = 'yFlipped' >

    ////////////////////////////////////////////////////////////

    /* Setup variables
     */
    afxString tag_open;
    afxString tag_close;
    afxString content;
    AfxResetString(&tag_open);
    AfxResetString(&tag_close);
    AfxResetString(&content);

    size_t original_length;
    afxXmlAttr** attributes;

    afxXmlNode** children = AfxCoallocate(mem, 1, sizeof(afxXmlNode*), 0, AfxSpawnHint());
    children[0] = 0;

    // Parse open tag
    // Parses an opening XML tag without attributes. Ex.: <TagName>

    _AfxXmlParseSkipWhitespaces(parser);

    /* Consume `<'
        */

    if (!('<' == _AfxXmlParsePeek(parser, CURRENT_CHARACTER))) AfxThrowError();
    else
    {
        _AfxXmlParseConsume(parser, 1); // skip '<'

        // Consume tag name
        // Parses the name out of the an XML tag's ending. Ex.: TagName>
              
        size_t start = parser->position;
        size_t length = 0;

        // Parse until '>' or a whitespace is reached

        while (start + length < parser->length)
        {
            uint8_t current = _AfxXmlParsePeek(parser, CURRENT_CHARACTER);

            if (('>' == current) || isspace(current)) break;
            else
            {
                _AfxXmlParseConsume(parser, 1);
                length++;
            }
        }

        // Consume '>'

        if (!('>' == _AfxXmlParsePeek(parser, CURRENT_CHARACTER))) AfxThrowError();
        else
        {
            _AfxXmlParseConsume(parser, 1);

            // Map parsed tag name
            AfxWrapStringLiteral(&tag_open, &parser->buffer[start], length);

            if (tag_open.src.start[3] == 'w')
            {
                int a = 0;
            }
        }
    }

    if (err) AfxThrowError();
    else
    {
        original_length = tag_open.range;
        attributes = _AfxXmlParseAttribs(xml, parser, &tag_open);

        // If tag ends with '/' it's self closing, skip content lookup. Drop '/' and go to node creation

        if (!(tag_open.range > 0 && '/' == tag_open.src.start[original_length - 1] /**(afxChar*)AfxGetStringData(&tag_open, original_length - 1)*/))
        {
            // If the content does not start with '<', a text content is assumed

            if (!('<' == _AfxXmlParsePeek(parser, CURRENT_CHARACTER)))
            {
                // Parses a tag's content. Ex.: any text between until next left angle brackets<
                
                _AfxXmlParseSkipWhitespaces(parser);

                size_t start = parser->position;
                size_t length = 0;

                // Consume until '<' is reached

                while (start + length < parser->length)
                {
                    uint8_t current = _AfxXmlParsePeek(parser, CURRENT_CHARACTER);

                    if ('<' == current) break;
                    else
                    {
                        _AfxXmlParseConsume(parser, 1);
                        length++;
                    }
                }

                // Next character must be an `<' or we have reached end of file

                if (!('<' == _AfxXmlParsePeek(parser, CURRENT_CHARACTER))) AfxThrowError();
                else
                {
                    // Ignore tailing whitespaces

                    while ((length > 0) && isspace(parser->buffer[start + length - 1]))
                        length--;

                    // Return mapped text
                    AfxWrapStringLiteral(&content, &parser->buffer[start], length);
                }
            }
            else // <
            {
                while ('/' != _AfxXmlParsePeek(parser, NEXT_CHARACTER))
                {
                    if ('!' == _AfxXmlParsePeek(parser, NEXT_CHARACTER) && '[' == _AfxXmlParsePeek(parser, NEXT_CHARACTER + 1))
                    {
                        // Parses a tag's CDATA content. Ex.: <![CDATA[any text between until next left angle brackets]]>

                        _AfxXmlParseSkipWhitespaces(parser);
                        _AfxXmlParseConsume(parser, 3);

                        // Consume until '[' is reached
                        afxSize start = parser->position;
                        afxSize length = 0;

                        while (start + length < parser->length)
                        {
                            uint8_t current = _AfxXmlParsePeek(parser, CURRENT_CHARACTER);

                            if ('[' == current)
                            {
                                _AfxXmlParseConsume(parser, 1); // skip [
                                length++;
                                break;
                            }
                            else
                            {
                                _AfxXmlParseConsume(parser, 1);
                                length++;
                            }
                        }

                        afxSize start2 = parser->position;
                        afxSize length2 = 0;

                        // Consume until ']]>' is reached

                        uint8_t current = 0;
                        uint8_t prev1 = 0, prev2 = 0;

                        while (start2 + length2 < parser->length)
                        {
                            prev2 = prev1;
                            prev1 = current;
                            current = _AfxXmlParsePeek(parser, CURRENT_CHARACTER);

                            if ('>' == current && ']' == prev1 && ']' == prev2)
                            {
                                _AfxXmlParseConsume(parser, 1);
                                //length2++;
                                length2 -= 3; // ]]>
                                break;
                            }
                            else
                            {
                                _AfxXmlParseConsume(parser, 1);
                                length2++;
                            }
                        }

                        // Next character must be an '<' or we have reached end of file

                        if (!('<' == _AfxXmlParsePeek(parser, CURRENT_CHARACTER))) AfxThrowError();
                        else
                        {
                            // Return mapped CDATA

                            AfxWrapStringLiteral(&content, &parser->buffer[start2], length2);
                        }
                    }
                    else
                    {
                        // Otherwise children are to be expected
                        // Parse child node

                        afxXmlNode* child = _AfxXmlParseNode(xml, parser);

                        if (!child)
                        {
                            AfxThrowError();
                            break;
                        }

                        // Grow child array :)

                        size_t old_elements = get_zero_terminated_array_nodes(children);
                        size_t new_elements = old_elements + 1;
                        children = AfxReallocate(mem, children, (new_elements + 1) * sizeof(afxXmlNode*), 0, AfxSpawnHint());

                        // Save child

                        children[new_elements - 1] = child;
                        children[new_elements] = 0;
                    }
                }
            }

            if (!err)
            {
                // Parse close tag
                // Parses an closing XML tag without attributes. Ex.: </TagName>
                     
                _AfxXmlParseSkipWhitespaces(parser);

                // Consume '</'

                if (!('<' == _AfxXmlParsePeek(parser, CURRENT_CHARACTER))) AfxThrowError();
                else if (!('/' == _AfxXmlParsePeek(parser, NEXT_CHARACTER))) AfxThrowError();
                else
                {
                    _AfxXmlParseConsume(parser, 2);

                    // Consume tag name
                    // Parses the name out of the an XML tag's ending. Ex.: TagName>

                    size_t start = parser->position;
                    size_t length = 0;

                    // Parse until '>' or a whitespace is reached

                    while (start + length < parser->length)
                    {
                        uint8_t current = _AfxXmlParsePeek(parser, CURRENT_CHARACTER);

                        if (('>' == current) || isspace(current)) break;
                        else
                        {
                            _AfxXmlParseConsume(parser, 1);
                            length++;
                        }
                    }

                    // Consume '>'

                    if (!('>' == _AfxXmlParsePeek(parser, CURRENT_CHARACTER))) AfxThrowError();
                    else
                    {
                        _AfxXmlParseConsume(parser, 1);

                        // Return parsed tag name

                        AfxWrapStringLiteral(&tag_close, &parser->buffer[start], length);
                    }
                }

                if (err)
                {
                    AfxThrowError();
                }
                else
                {
                    /* Close tag has to match open tag
                     */

                    if (0 != AfxCompareString(&tag_open, &tag_close))
                    {
                        AfxThrowError();
                        AfxError(" %.*s %.*s", AfxPushString(&tag_open), AfxPushString(&tag_close));
                    }
                }
            }
        }

        /* Return parsed node
         */
        if (!err)
        {
            if (tag_open.src.start[3] == 'w')
            {
                int a = 0;
            }

            afxXmlNode* node = AfxAllocate(mem, sizeof(afxXmlNode), 0, AfxSpawnHint());
            AfxWrapStringLiteral(&node->name, tag_open.src.start, tag_open.range);
            AfxWrapStringLiteral(&node->content, content.src.start, content.range);
            node->attributes = attributes;
            node->children = children;
            return node;
        }
    }

    /* A failure occured, so free mem allocalted resources
     */
    if (err)
    {
        afxXmlNode** it = children;
        while (*it) {
            AfxXmlNodeDelete(xml, *it);
            ++it;
        }
        AfxDeallocate(mem, children);
    }
    return 0;
}

_AFX afxError AfxParseXml(afxXml* xml, void* buffer, afxNat length)
{
    afxError err = AFX_ERR_NONE;
    /* Initialize parser
     */
    struct xml_parser parser = {
        .buffer = buffer,
        .position = 0,
        .length = length
    };

    /* An empty buffer canv never contain a valid document
     */
    if (!length)
    {
        AfxThrowError();
    }
    else
    {
        /* Parse the root node
         */
        afxXmlNode *root = _AfxXmlParseNode(xml, &parser);

        if (!root)
        {
            AfxThrowError();
        }
        else
        {
            /* Return parsed document
             */

            xml->buffer.buffer = buffer;
            xml->buffer.length = length;
            xml->root = root;
        }
    }
    return err;
}

/**
 * [PUBLIC API]
 */
afxError _AfxXmlOpen(afxXml* xml, void* source)
{
    afxError err = AFX_ERR_NONE;

    afxContext mem = AfxGetIoContext();
    AfxAssertObjects(1, &mem, afxFcc_CTX);

    /* Prepare buffer
     */
    size_t const read_chunk = 1; // TODO 4096;

    size_t document_length = 0;
    size_t buffer_size = 512;	// TODO 4069
    uint8_t* buffer = AfxAllocate(mem, (buffer_size * sizeof(uint8_t)), 0, AfxSpawnHint());

    /* Read hole file into buffer
     */
    while (!feof(source)) {

        /* Reallocate buffer
         */
        if (buffer_size - document_length < read_chunk)
        {
            buffer = AfxReallocate(mem, buffer, buffer_size + 2 * read_chunk, 0, AfxSpawnHint());
            buffer_size += 2 * read_chunk;
        }

        size_t read = fread( &buffer[document_length], sizeof(uint8_t), read_chunk, source);

        document_length += read;
    }
    //fclose(source);

    /* Try to parse buffer
     */
    if (AfxParseXml(xml, buffer, document_length))
        AfxThrowError();

    if (err)
    {
        AfxDeallocate(mem, buffer);
    }
    return err;
}


#if 0
/**
 * [PUBLIC API]
 */
afxXmlNode* xml_easy_child(afxXmlNode* node, uint8_t const* child_name, ...) {

    /* Find children, one by one
     */
    afxXmlNode* current = node;

    va_list arguments;
    va_start(arguments, child_name);


    /* Descent to current.child
     */
    while (child_name) {

        /* Convert child_name to xml_string for easy comparison
         */
        afxString cn;
        AfxWrapStringLiteral(&cn, child_name, strlen(child_name));
        
        /* Interate through mem children
         */
        afxXmlNode* next = 0;

        size_t i = 0; for (; i < xml_node_children(current); ++i)
        {
            afxXmlNode* child = xml_node_child(current, i);

            if (0 == AfxCompareString(xml_node_name(child), &cn)) {
                if (!next) {
                    next = child;

                    /* Two children with the same name
                     */
                }
                else {
                    va_end(arguments);
                    return 0;
                }
            }
        }

        /* No child with that name found
         */
        if (!next) {
            va_end(arguments);
            return 0;
        }
        current = next;

        /* Find name of next child
         */
        child_name = va_arg(arguments, uint8_t const*);
    }
    va_end(arguments);


    /* Return current element
     */
    return current;
}

#endif





_AFX afxXmlNode* AfxGetXmlRoot(afxXml* xml)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(xml, afxFcc_XML);
    return xml->root;
}

_AFX afxString const* AfxGetXmlNodeName(afxXmlNode const *node)
{
    afxError err = AFX_ERR_NONE;
    AfxAssert(node);
    return &node->name;
}

_AFX afxString const* AfxGetXmlNodeContent(afxXmlNode const *node)
{
    afxError err = AFX_ERR_NONE;
    AfxAssert(node);
    return &node->content;
}

_AFX afxNat AfxCountXmlChildNodes(afxXmlNode const *node)
{
    afxError err = AFX_ERR_NONE;
    AfxAssert(node);
    return get_zero_terminated_array_nodes(node->children);
}

_AFX afxXmlNode const* AfxGetXmlChildNode(afxXmlNode const *node, afxNat idx)
{
    afxError err = AFX_ERR_NONE;
    AfxAssert(node);

    if (idx >= AfxCountXmlChildNodes(node))
    {
        return 0;
    }

    return node->children[idx];
}

_AFX afxNat AfxCountXmlAttributes(afxXmlNode const *node)
{
    afxError err = AFX_ERR_NONE;
    AfxAssert(node);
    return get_zero_terminated_array_attributes(node->attributes);
}

_AFX afxString* AfxXmlNodeGetAttributeName(afxXmlNode const *node, afxNat idx)
{
    afxError err = AFX_ERR_NONE;
    AfxAssert(node);

    if (idx >= AfxCountXmlAttributes(node))
    {
        return 0;
    }

    return &node->attributes[idx]->name;
}

_AFX afxString* AfxXmlNodeGetAttributeContent(afxXmlNode const *node, afxNat idx)
{
    if (idx >= AfxCountXmlAttributes(node))
    {
        return 0;
    }

    return &node->attributes[idx]->content;
}

_AFX afxBool AfxXmlNodeHasAttribute(afxXmlNode const* node, afxString const* key, afxBool ci)
{
    afxError err = AFX_ERR_NONE;
    AfxAssert(node);
    AfxAssert(key);
    afxNat cnt = AfxCountXmlAttributes(node);

    for (afxNat i = 0; i < cnt; i++)
    {
        afxXmlAttr const *a = node->attributes[i];

        if ((ci && (0 == AfxCompareStringCi(key, &a->name))) || (0 == AfxCompareString(key, &a->name)))
            return TRUE;
    }
    return FALSE;
}

_AFX afxString const* AfxFindXmlAttribute(afxXmlNode const* node, afxString const* key, afxBool ci)
{
    afxError err = AFX_ERR_NONE;
    AfxAssert(node);
    AfxAssert(key);
    afxNat cnt = AfxCountXmlAttributes(node);

    for (afxNat i = 0; i < cnt; i++)
    {
        afxXmlAttr const *a = node->attributes[i];

        if ((ci && (0 == AfxCompareStringCi(key, &a->name))) || (0 == AfxCompareString(key, &a->name)))
            return &a->content;
    }
    return NIL;
}

_AFX afxBool AfxExtractXmlAttributeI32(afxXmlNode const* node, afxString const* key, afxBool ci, afxInt32* value)
{
    afxError err = AFX_ERR_NONE;
    AfxAssert(node);
    AfxAssert(key);

    afxBool rslt;
    afxString const *content;

    if ((rslt = !!(content = AfxFindXmlAttribute(node, key, ci))))
    {
        AfxAssert(value);
        AfxScanString(content, "%i", value);
    }
    return rslt;
}

_AFX afxBool AfxExtractXmlAttributeN32(afxXmlNode const* node, afxString const* key, afxBool ci, afxNat32* value)
{
    afxError err = AFX_ERR_NONE;
    AfxAssert(node);
    AfxAssert(key);

    afxBool rslt;
    afxString const *content;

    if ((rslt = !!(content = AfxFindXmlAttribute(node, key, ci))))
    {
        AfxAssert(value);
        AfxScanString(content, "%u", value);
    }
    return rslt;
}

_AFX afxBool AfxExtractXmlAttributeR32(afxXmlNode const* node, afxString const* key, afxBool ci, afxReal32* value)
{
    afxError err = AFX_ERR_NONE;
    AfxAssert(node);
    AfxAssert(key);

    afxBool rslt;
    afxString const *content;

    if ((rslt = !!(content = AfxFindXmlAttribute(node, key, ci))))
    {
        AfxAssert(value);
        AfxScanString(content, "%f", value);
    }
    return rslt;
}

_AFX afxBool AfxExtractXmlAttributeR64(afxXmlNode const* node, afxString const* key, afxBool ci, afxReal64* value)
{
    afxError err = AFX_ERR_NONE;
    AfxAssert(node);
    AfxAssert(key);

    afxBool rslt;
    afxString const *content;

    if ((rslt = !!(content = AfxFindXmlAttribute(node, key, ci))))
    {
        AfxAssert(value);
        AfxScanString(content, "%f", value);
    }
    return rslt;
}




_AFX afxXmlNode const* AfxXmlNodeFindChild(afxXmlNode const *base, afxString const *child, afxString const *attr, afxString const *value)
{
    afxError err = AFX_ERR_NONE;
    AfxAssert(base);
    afxNat cnt = AfxCountXmlChildNodes(base);

    for (afxNat i = 0; i < cnt; i++)
    {
        afxXmlNode const *n = base->children[i];

        if (0 == AfxCompareString(child, &n->name))
        {
            if (!attr || AfxStringIsEmpty(attr))
                return n;

            afxNat cnt2 = AfxCountXmlAttributes(n);

            for (afxNat j = 0; j < cnt2; j++)
            {
                afxXmlAttr const *a = n->attributes[j];

                if (0 == AfxCompareString(attr, &a->name))
                {
                    if (!value || AfxStringIsEmpty(value))
                        return n;

                    if (0 == AfxCompareString(value, &a->content))
                        return n;
                }
            }
        }
    }
    return NIL;
}

_AFX void AfxReleaseXml(afxXml* xml)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertType(xml, afxFcc_XML);

    AfxXmlNodeDelete(xml, xml->root);

    if (xml->buffer.buffer)
    {
        afxContext mem = AfxGetIoContext();
        AfxAssertObjects(1, &mem, afxFcc_CTX);
        AfxDeallocate(mem, xml->buffer.buffer);
    }
}

_AFX afxError AfxLoadXml(afxXml* xml, afxUri const *uri)
{
    afxError err = AFX_ERR_NONE;

    AfxEntry("uri:%.*s", AfxPushString(uri ? AfxUriGetStringConst(uri) : &AFX_STR_EMPTY));
    afxFile file;

    if (AfxOpenFiles(1, &file, uri, (afxFileFlags[]) { AFX_FILE_FLAG_R })) AfxThrowError();
    else
    {
        AfxAssertObjects(1, &file, afxFcc_FILE);

        AfxAssignTypeFcc(xml, afxFcc_XML);

        if (_AfxXmlOpen(xml, AfxGetFileHostDescriptor(file)))
            AfxThrowError();

        AfxReleaseObjects(1, (void*[]) { file });
    }
    return err;
}
