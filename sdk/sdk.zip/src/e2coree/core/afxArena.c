/*
 *          ::::::::  :::       :::     :::     :::::::::  :::::::::   ::::::::
 *         :+:    :+: :+:       :+:   :+: :+:   :+:    :+: :+:    :+: :+:    :+:
 *         +:+    +:+ +:+       +:+  +:+   +:+  +:+    +:+ +:+    +:+ +:+    +:+
 *         +#+    +:+ +#+  +:+  +#+ +#++:++#++: +#+    +:+ +#++:++#:  +#+    +:+
 *         +#+  # +#+ +#+ +#+#+ +#+ +#+     +#+ +#+    +#+ +#+    +#+ +#+    +#+
 *         #+#   +#+   #+#+# #+#+#  #+#     #+# #+#    #+# #+#    #+# #+#    #+#
 *          ###### ###  ###   ###   ###     ### #########  ###    ###  ########
 *
 *              T H E   Q W A D R O   E X E C U T I O N   E C O S Y S T E M
 *
 *                                   Public Test Build
 *                   (c) 2017 SIGMA Technology Group � Federa��o SIGMA
 *                                    www.sigmaco.org
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define _AFX_ARENA_C
#include "afx/core/afxArena.h"
#include "../src/e2coree/core/afxCoreHideout.h"

AFX_DEFINE_STRUCT(afxArenaCleanup)
{
    void(*action)(void *data,void*extra);
    void *data;
    void *extra;
};

AFX_DEFINE_STRUCT(afxArenaRecycleItem)
{
    afxArenaRecycleItem* next;
};

AFX_DEFINE_STRUCT(afxArenaLargeItem)
{
    afxArenaLargeItem* next;
    afxArenaLargeItem* prev;
    //afxNat siz; // afx
};
#if 0
AFX_OBJECT(afxArena)
{
    AFX_OBJECT(afxContext)    all;
    afxContext                   mem;
    afxSize                     totalAllocated;
    afxSize                     smallItems;
    afxSize                     largeItems;
    afxSize                     chunkCnt;
    afxSize                     unusedSpace; /* Unused space due to alignment, etc. */

    afxSize                     allocated;
    char                        *initialData;
    char                        *data;

    void*                       (*alloc)(afxSize);
    void                        (*dealloc)(void *);

    afxSize                     maxCleanupCnt;
    afxSize                     cleanupCnt;
    afxArenaCleanup*            cleanups;
    afxArenaLargeItem*          largeList;

    afxSize                     chunkSiz;
    afxSize                     largeItemSiz;

     // se n�o for NIL, reciclagem est� habilitada.
    // Isto � um array de linked list de partes mantidas para reciclagem.
    // As partes s�o todas ponteiros para dentro dos chunks alocados.
    // Array[i] aponta para itens de tamanho 'i'.
    afxArenaRecycleItem**       recycleBin;
    // E aqui o montante de mem�ria armazenada na reciclagem.
    afxSize		                recycleSiz;
};
#endif
#define DEFAULT_CHUNK_SIZE         4096
#define DEFAULT_LARGE_OBJECT_SIZE  (DEFAULT_CHUNK_SIZE / 8)
#define DEFAULT_INITIAL_CLEANUP_SIZE 16


/*
 * mmap allocator constants
 *
 */
#ifdef USE_MMAP_ALLOC

 /* header starts with afxSize containing allocated size info and has at least 16 bytes to align the returned memory */
#define MMAP_ALLOC_HEADER_SIZE (sizeof(afxSize) >= 16 ? (sizeof(afxSize)) : 16)

/* mmap allocator uses chunks of 32 4kB pages */
#define MMAP_ALLOC_CHUNK_SIZE		((32 * 4096) - MMAP_ALLOC_HEADER_SIZE)
#define MMAP_ALLOC_LARGE_OBJECT_SIZE	(MMAP_ALLOC_CHUNK_SIZE / 8)
#define MMAP_ALLOC_INITIAL_CLEANUP_SIZE	16

#endif /* USE_MMAP_ALLOC */

/*
 * Create a new aren.
 */
_AFX void* AfxArenaCtor(afxArena* result);


/*
 * Create a new aren, with chunk size and large object size.
 * Note that largeItemSiz must be <= chunkSiz.
 * Anything larger than the large object size is individually alloced.
 * largeItemSiz = chunkSiz/8 is reasonable;
 * initial_cleanup_size is the number of preallocated ptrs for cleanups.
 * The cleanups are in a growing array, and it must start larger than zero.
 * If recycle is true, environmentally friendly memory recycling is be enabled.
 */
_AFX void* AfxArenaCtor2(afxArena* result, afxSize chunkSiz, afxSize largeItemSiz, afxSize initialCleanupSiz, int recycle);


/*
 * Destroy REGION.  All memory associated with REGION is freed as if
 * AfxExhaustArena was called.
 */
_AFX void AfxArenaDtor(afxArena* aren);


/*
 * Add a cleanup to REGION.  ACTION will be called with DATA as
 * parameter when the aren is freed or destroyed.
 *
 * Returns 0 on failure.
 */
_AFX afxSize AfxAddArenaCleanup(afxArena* aren, void(*action)(void *data,void*extra), void *data,void*extra);

/*
 * Remove cleanup, both action and data must match exactly.
 */
_AFX void AfxRemoveArenaCleanup(afxArena* aren, void(*action)(void *,void*), void *data);

/*
 * Allocate SIZE bytes of memory inside REGION.  The memory is
 * deallocated when AfxExhaustArena is called for this aren.
 */
_AFX void *AfxRequestArenaUnit(afxArena* aren, afxSize size);

/** Allocate array with integer overflow checks, in aren */
_AFX void *AfxRequestArenaUnits(afxArena* aren, afxSize num, afxSize size);

/*
 * Allocate SIZE bytes of memory inside REGION and copy INIT into it.
 * The memory is deallocated when AfxExhaustArena is called for this
 * aren.
 */
_AFX void *AfxRequestArenaStorage(afxArena* aren, const void *init, afxSize size);

/**
 * Allocate array (with integer overflow check on sizes), and init with
 * the given array copied into it.  Allocated in the aren
 */
_AFX void *AfxRequestArenaStorages(afxArena* aren, const void *init, afxSize num, afxSize size);

/*
 * Allocate SIZE bytes of memory inside REGION that are initialized to
 * 0.  The memory is deallocated when AfxExhaustArena is called for
 * this aren.
 */
_AFX void *AfxRequestZeroedArenaUnit(afxArena* aren, afxSize size);

/**
 * Allocate array (with integer overflow check on sizes), and zero it.
 * Allocated in the aren.
 */
_AFX void *AfxRequestZeroedArenaUnits(afxArena* aren, afxSize num, afxSize size);

/*
 * Run the cleanup actions and free all memory associated with REGION.
 */
_AFX void AfxExhaustArena(afxArena* aren);


/*
 * Duplicate STRING and allocate the result in REGION.
 */
_AFX char *AfxArenaDuplicateString(afxArena* aren, const char *string);

/*
 * Recycle an allocated memory block. Pass size used to alloc it.
 * Does nothing if recycling is not enabled for the aren.
 */
_AFX void AfxRecycleArenaUnit(afxArena* aren, void *block, afxSize size);

/*
 * Print some REGION statistics to OUT.
 */
_AFX void AfxDumpArenaStats(afxArena* aren, afxStream *out);

/* get size of recyclebin */
_AFX afxSize AfxGetArenaRecycleSize(afxArena* aren);
/* get size of aren memory in use */
_AFX afxSize AfxGetArenaTotalAllocated(afxArena* aren);
/* get size of aren memory unused */
_AFX afxSize AfxGetArenaUnusedSpace(afxArena* aren);

/* Debug print REGION statistics to LOG. */
_AFX void AfxLogArenaStats(afxArena* aren);

/** This value is enough so that x*y does not overflow if both < than this */
#define _AFX_ARENA_NO_OVERFLOW ((afxSize)1 << (sizeof(afxSize) * 4))

#ifdef ALIGNMENT
#undef ALIGNMENT
#endif
#ifndef PACKED_STRUCTS
#define _AFX_ARENA_ALIGN_UP(x, s)     (((x) + s - 1) & (~(s - 1)))
#if SIZEOF_OFF_T > SIZEOF_VOIDP
#define ALIGNMENT	(sizeof(off_t))
#else
#define ALIGNMENT	(sizeof(void *))
#endif
#else
#define _AFX_ARENA_ALIGN_UP(x, s) ((x)<SIZEOF_VOIDP?SIZEOF_VOIDP:(x))
#define ALIGNMENT 1
#endif /* PACKED_STRUCTS */
/* #define CHECK_DOUBLE_FREE 0 */ /* set to 1 to perform expensive check for double recycle() */

static void* alloc_region_base(afxArena* result, afxSize initial_cleanupCnt)
{
    afxError err = AFX_ERR_NONE;
    //afxArena result = (afxArena )allocator(sizeof(AFX_OBJECT(afxArena)));
    
    if (!result)
        return NIL;

    result->totalAllocated = 0;
    result->smallItems = 0;
    result->largeItems = 0;
    result->chunkCnt = 1;
    result->unusedSpace = 0;
    result->recycleBin = NIL;
    result->recycleSiz = 0;
    result->largeList = NIL;

    result->allocated = 0;
    result->data = NIL;
    result->initialData = NIL;

    //result->alloc = allocator;
    //result->dealloc = deallocator;

    AfxAssert(initial_cleanupCnt > 0);
    result->maxCleanupCnt = initial_cleanupCnt;
    result->cleanupCnt = 0;
    result->cleanups = (afxArenaCleanup *)AfxAllocate(result->mem, result->maxCleanupCnt * sizeof(afxArenaCleanup), 0, AfxSpawnHint());
    
    if (!result->cleanups)
    {

        return NIL;
    }

    result->chunkSiz = DEFAULT_CHUNK_SIZE;
    result->largeItemSiz = DEFAULT_LARGE_OBJECT_SIZE;
    return result;
}

_AFX void* AfxArenaCtor(afxArena* result)
{
    /*afxArena result =*/ alloc_region_base(result, DEFAULT_INITIAL_CLEANUP_SIZE);

    if (!result)
        return NIL;

    result->data = (char *)AfxAllocate(result->mem, result->chunkSiz, 0, AfxSpawnHint());

    if (!result->data)
    {
        AfxDeallocate(result->mem, result->cleanups);
        //deallocator(result);
        return NIL;
    }
    result->initialData = result->data;

    return result;
}

_AFX void* AfxArenaCtor2(afxArena* result, afxSize chunkSiz, afxSize largeItemSiz, afxSize initial_cleanup_size, int recycle)
{
    afxError err = AFX_ERR_NONE;
    /*afxArena result = */alloc_region_base(result, initial_cleanup_size);

    if (!result)
        return NIL;

    AfxAssert(largeItemSiz <= chunkSiz);
    result->chunkSiz = chunkSiz;
    result->largeItemSiz = largeItemSiz;

    if (result->chunkSiz > 0)
    {
        result->data = (char *)AfxAllocate(result->mem, result->chunkSiz, 0, AfxSpawnHint());

        if (!result->data)
        {
            AfxDeallocate(result->mem, result->cleanups);
            //AfxDeallocate(result->mem, result);
            return NIL;
        }
        result->initialData = result->data;
    }

    if (recycle)
    {
        result->recycleBin = AfxAllocate(result->mem, (sizeof(afxArenaRecycleItem*) * result->largeItemSiz), 0, AfxSpawnHint());

        if (!result->recycleBin)
        {
            AfxArenaDtor(result);
            return NIL;
        }
        AfxZero(result->recycleBin, sizeof(afxArenaRecycleItem*) * result->largeItemSiz);
    }
    return result;
}

_AFX void AfxArenaDtor(afxArena* aren)
{
    

    if (!aren)
        return;

    afxContext mem = aren->mem;

    AfxExhaustArena(aren);
    AfxDeallocate(mem, aren->cleanups);
    AfxDeallocate(mem, aren->initialData);

    if (aren->recycleBin)
        AfxDeallocate(mem, aren->recycleBin);

    if (aren->largeList)
    {
        afxArenaLargeItem* p = aren->largeList, *np;

        while (p)
        {
            np = p->next;
            AfxDeallocate(mem, p);
            p = np;
        }
    }
    //deallocator(aren);
}

_AFX afxSize AfxAddArenaCleanup(afxArena* aren, void(*action)(void *data, void*extra), void *data, void *extra)
{
    afxError err = AFX_ERR_NONE;
    AfxAssert(action);
    afxArenaCleanup *cleanups;

    if (aren->cleanupCnt >= aren->maxCleanupCnt)
    {
        cleanups = (afxArenaCleanup *)AfxAllocate(aren->mem, (2 * aren->maxCleanupCnt * sizeof(afxArenaCleanup)), 0, AfxSpawnHint());

        if (!cleanups)
            return 0;

        AfxCopy(cleanups, aren->cleanups, aren->cleanupCnt * sizeof(afxArenaCleanup));
        AfxDeallocate(aren->mem, aren->cleanups);

        aren->cleanups = cleanups;
        aren->maxCleanupCnt *= 2;
    }

    cleanups = aren->cleanups;
    cleanups[aren->cleanupCnt].action = action;
    cleanups[aren->cleanupCnt].data = data;
    cleanups[aren->cleanupCnt].extra = extra;

    ++aren->cleanupCnt;
    return aren->cleanupCnt;
}

_AFX void AfxRemoveArenaCleanup(afxArena* aren, void(*action)(void *,void*), void *data)
{
    afxSize i;

    for (i = 0; i < aren->cleanupCnt; i++)
    {
        afxArenaCleanup *cleanups = aren->cleanups;

        if (cleanups[i].action == action && cleanups[i].data == data)
        {
            aren->cleanupCnt--;
            cleanups[i] = cleanups[aren->cleanupCnt];
            return;
        }
    }
}

_AFX void _AfxArenDeallocBlockCleanupAction(void *data, void*extra)
{
    AfxDeallocate(((afxArena*)extra)->mem, data);
}

_AFX void* AfxRequestArenaUnit(afxArena* aren, afxSize size)
{
    afxSize aligned_size;
    void *result;

    if (size == 0)
    {
        size = 1;
    }

    aligned_size = _AFX_ARENA_ALIGN_UP(size, ALIGNMENT);

    if (aligned_size >= aren->largeItemSiz)
    {
        result = AfxAllocate(aren->mem, size + sizeof(afxArenaLargeItem), 0, AfxSpawnHint());

        if (!result)
            return NIL;

        ((afxArenaLargeItem*)result)->prev = NIL;
        ((afxArenaLargeItem*)result)->next = aren->largeList;
        //((afxArenaLargeItem*)result)->siz = size; // afx

        afxArenaLargeItem *largeList = aren->largeList;

        if (largeList)
            largeList->prev = (afxArenaLargeItem*)result;

        aren->largeList = (afxArenaLargeItem*)result;

        aren->totalAllocated += size;
        ++aren->largeItems;

        return (char *)result + sizeof(afxArenaLargeItem);
    }

    afxArenaRecycleItem **recycleBin = (afxArenaRecycleItem**)aren->recycleBin;

    if (recycleBin && recycleBin[aligned_size])
    {
        result = (void*)recycleBin[aligned_size];
        aren->recycleBin[aligned_size] = recycleBin[aligned_size]->next;
        aren->recycleSiz -= aligned_size;
        aren->unusedSpace += aligned_size - size;
        return result;
    }

    if (aren->allocated + aligned_size > aren->chunkSiz)
    {
        void *chunk = AfxAllocate(aren->mem, aren->chunkSiz, 0, AfxSpawnHint());
        afxSize wasted;

        if (!chunk)
            return NIL;

        wasted = (aren->chunkSiz - aren->allocated) & (~(ALIGNMENT - 1));

        if (
#ifndef PACKED_STRUCTS
            wasted >= ALIGNMENT
#else
            wasted >= SIZEOF_VOIDP
#endif
            )
        {
            /* put wasted part in recycle bin for later use */
            aren->totalAllocated += wasted;
            ++aren->smallItems;
            AfxRecycleArenaUnit(aren, aren->data + aren->allocated, wasted);
            aren->allocated += wasted;
        }

        ++aren->chunkCnt;
        aren->unusedSpace += aren->chunkSiz - aren->allocated;

        if (!AfxAddArenaCleanup(aren, _AfxArenDeallocBlockCleanupAction, chunk, aren))
        {
            AfxDeallocate(aren->mem, chunk);
            aren->chunkCnt--;
            aren->unusedSpace -= aren->chunkSiz - aren->allocated;
            return NIL;
        }
        aren->allocated = 0;
        aren->data = (char *)chunk;
    }

    result = aren->data + aren->allocated;
    aren->allocated += aligned_size;

    aren->totalAllocated += aligned_size;
    aren->unusedSpace += aligned_size - size;
    ++aren->smallItems;

    return result;
}

_AFX void* AfxRequestArenaStorage(afxArena* aren, const void *init, afxSize size)
{
    void *result = AfxRequestArenaUnit(aren, size);

    if (!result)
        return NIL;

    AfxCopy(result, init, size);
    return result;
}

_AFX void* AfxRequestZeroedArenaUnit(afxArena* aren, afxSize size)
{
    void *result = AfxRequestArenaUnit(aren, size);

    if (!result)
        return NIL;

    AfxZero(result, size);
    return result;
}

_AFX void* AfxRequestArenaStorages(afxArena* aren, const void *init, afxSize num, afxSize size)
{
    if ((num >= _AFX_ARENA_NO_OVERFLOW || size >= _AFX_ARENA_NO_OVERFLOW) && num > 0 && SIZE_MAX / num < size)
    {
        AfxError("AfxRequestArenaStorages failed because of integer overflow");
        exit(1);
    }
    return AfxRequestArenaStorage(aren, init, num*size);
}

_AFX void* AfxRequestZeroedArenaUnits(afxArena* aren, afxSize num, afxSize size)
{
    if ((num >= _AFX_ARENA_NO_OVERFLOW || size >= _AFX_ARENA_NO_OVERFLOW) && num > 0 && SIZE_MAX / num < size)
    {
        AfxError("AfxRequestZeroedArenaUnits failed because of integer overflow");
        exit(1);
    }
    return AfxRequestZeroedArenaUnit(aren, num*size);
}

_AFX void* AfxRequestArenaUnits(afxArena* aren, afxSize num, afxSize size)
{
    if ((num >= _AFX_ARENA_NO_OVERFLOW || size >= _AFX_ARENA_NO_OVERFLOW) && num > 0 && SIZE_MAX / num < size)
    {
        AfxError("AfxRequestArenaUnits failed because of integer overflow");
        exit(1);
    }
    return AfxRequestArenaUnit(aren, num*size);
}

_AFX void AfxExhaustArena(afxArena* aren)
{
    afxError err = AFX_ERR_NONE;
    afxSize i;
    AfxAssert(aren);
    AfxAssert(aren->cleanups);

    i = aren->cleanupCnt;
    afxArenaCleanup *cleanups = aren->cleanups;

    while (i > 0)
    {
        --i;
        AfxAssert(cleanups[i].action);
        cleanups[i].action(cleanups[i].data, cleanups[i].extra);
    }

    if (aren->recycleBin)
    {
        AfxZero(aren->recycleBin, sizeof(afxArenaRecycleItem*) * aren->largeItemSiz);
        aren->recycleSiz = 0;
    }

    if (aren->largeList)
    {
        afxArenaLargeItem* p = aren->largeList, *np;
        //void(*deallocator)(void *) = aren->dealloc;

        while (p)
        {
            np = p->next;
            AfxDeallocate(aren->mem, p);
            p = np;
        }
        aren->largeList = NIL;
    }

    aren->data = aren->initialData;
    aren->cleanupCnt = 0;
    aren->allocated = 0;

    aren->totalAllocated = 0;
    aren->smallItems = 0;
    aren->largeItems = 0;
    aren->chunkCnt = 1;
    aren->unusedSpace = 0;
}

_AFX char* AfxArenaDuplicateString(afxArena* aren, const char *string)
{
    return (char *)AfxRequestArenaStorage(aren, string, strlen(string) + 1);
}

_AFX void AfxRecycleArenaUnit(afxArena* aren, void *block, afxSize size)
{
    afxError err = AFX_ERR_NONE;
    afxSize aligned_size;

    if (!block || !aren->recycleBin)
        return;

    if (size == 0)
    {
        size = 1;
    }
    aligned_size = _AFX_ARENA_ALIGN_UP(size, ALIGNMENT);

    if (aligned_size < aren->largeItemSiz)
    {
        afxArenaRecycleItem* elem = (afxArenaRecycleItem*)block;
        /* we rely on the fact that ALIGNMENT is void* so the next will fit */
        AfxAssert(aligned_size >= sizeof(afxArenaRecycleItem));

#ifdef CHECK_DOUBLE_FREE
        if (CHECK_DOUBLE_FREE)
        {
            /* make sure the same ptr is not freed twice. */
            afxArenaRecycleItem *p = aren->recycleBin[aligned_size];
            while (p) {
                AfxAssert(p != elem);
                p = p->next;
            }
        }
#endif

        elem->next = aren->recycleBin[aligned_size];
        aren->recycleBin[aligned_size] = elem;
        aren->recycleSiz += aligned_size;
        aren->unusedSpace -= aligned_size - size;
        return;
    }
    else
    {
        afxArenaLargeItem* l;

        /* a large allocation */
        aren->totalAllocated -= size;
        --aren->largeItems;

        l = (afxArenaLargeItem*)((char*)block - sizeof(afxArenaLargeItem));

        if (l->prev)
            l->prev->next = l->next;
        else
            aren->largeList = l->next;

        if (l->next)
            l->next->prev = l->prev;

        AfxDeallocate(aren->mem, l);
    }
}

_AFX void AfxDumpArenaStats(afxArena* aren, afxStream *out)
{
    afxString128 str;
    AfxString128(&str);
    AfxFormatString(&str.str, "%lu objects (%lu small/%lu large), %lu bytes allocated (%lu wasted) in %lu chunks, %lu cleanups, %lu in recyclebin",
        (unsigned long)(aren->smallItems + aren->largeItems),
        (unsigned long)aren->smallItems,
        (unsigned long)aren->largeItems,
        (unsigned long)aren->totalAllocated,
        (unsigned long)aren->unusedSpace,
        (unsigned long)aren->chunkCnt,
        (unsigned long)aren->cleanupCnt,
        (unsigned long)aren->recycleSiz);
    AfxWriteStream(out, AfxGetStringDataConst(&str.str, 0), AfxGetStringSize(&str.str), 0);

    if (aren->recycleBin)
    {
        /* print details of the recycle bin */
        afxSize i;
        for (i = 0; i < aren->largeItemSiz; i++)
        {
            afxSize count = 0;
            afxArenaRecycleItem* el = aren->recycleBin[i];
            while (el)
            {
                count++;
                el = el->next;
            }

            if (i%ALIGNMENT == 0 && i != 0)
            {
                AfxFormatString(&str.str, " %lu", (unsigned long)count);
                AfxWriteStream(out, AfxGetStringDataConst(&str.str, 0), AfxGetStringSize(&str.str), 0);
            }
        }
    }
}

_AFX afxSize AfxGetArenaRecycleSize(afxArena* aren)
{
    return aren->recycleSiz;
}

_AFX afxSize AfxGetArenaTotalAllocated(afxArena* aren)
{
    return aren->totalAllocated;
}

_AFX afxSize AfxGetArenaUnusedSpace(afxArena* aren)
{
    return aren->unusedSpace;
}

/* debug routine */
_AFX void AfxLogArenaStats(afxArena* aren)
{
    char buf[10240], *str = buf;
    int strl = sizeof(buf);
    int len;
    snprintf(str, strl, "%lu objects (%lu small/%lu large), %lu bytes allocated (%lu wasted) in %lu chunks, %lu cleanups, %lu in recyclebin",
        (unsigned long)(aren->smallItems + aren->largeItems),
        (unsigned long)aren->smallItems,
        (unsigned long)aren->largeItems,
        (unsigned long)aren->totalAllocated,
        (unsigned long)aren->unusedSpace,
        (unsigned long)aren->chunkCnt,
        (unsigned long)aren->cleanupCnt,
        (unsigned long)aren->recycleSiz);
    len = strlen(str);
    str += len;
    strl -= len;
    if (aren->recycleBin) {
        /* print details of the recycle bin */
        afxSize i;
        for (i = 0; i < aren->largeItemSiz; i++) {
            afxSize count = 0;
            afxArenaRecycleItem* el = aren->recycleBin[i];
            while (el) {
                count++;
                el = el->next;
            }
            if (i%ALIGNMENT == 0 && i != 0) {
                snprintf(str, strl, " %lu", (unsigned long)count);
                len = strlen(str);
                str += len;
                strl -= len;
            }
        }
    }
    AfxAdvertise("memory: %s", buf);
}

_AFX void AfxReleaseArena(afxArena* aren)
{
    AfxEntry("aren=%p", aren);
    afxError err = AFX_ERR_NONE;
    AfxAssertType(aren, afxFcc_AREN);
    AfxExhaustArena(aren);
    AfxArenaDtor(aren);   
}

_AFX afxError AfxAcquireArena(afxContext mem, afxArena* aren, afxArenaSpecification const *spec, afxHint const hint)
{
    AfxEntry("aren=%p", aren);
    AfxEntry("spec=%p,hint=\"%s:%i!%s\"", spec, AfxFindPathTarget((char const *const)hint[0]), (int)hint[1], (char const *const)hint[2]);
    afxError err = AFX_ERR_NONE;
    //AfxAssert(spec);

    afxNat sysPagSiz = AfxGetMemoryPageSize();
    afxNat pageSiz = spec && spec->chunkSiz ? spec->chunkSiz : sysPagSiz;
    afxNat initCleanupSiz = spec && spec->initialCleanupSiz ? spec->initialCleanupSiz : 16;
    afxNat largeItemSiz = spec && spec->largeItemSiz ? spec->largeItemSiz : pageSiz / 8;
    afxBool recycle = spec && spec->recycle ? spec->recycle : TRUE;

    AfxAssignTypeFcc(aren, afxFcc_AREN);
    aren->mem = mem;

    aren->hint[0] = hint[0];
    aren->hint[1] = hint[1];
    aren->hint[2] = hint[2];

    if (!AfxArenaCtor2(aren, pageSiz, largeItemSiz, initCleanupSiz, recycle))
        AfxThrowError();
    
    return err;
}
