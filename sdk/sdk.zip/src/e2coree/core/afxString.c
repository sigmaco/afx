/*
 *          ::::::::  :::       :::     :::     :::::::::  :::::::::   ::::::::
 *         :+:    :+: :+:       :+:   :+: :+:   :+:    :+: :+:    :+: :+:    :+:
 *         +:+    +:+ +:+       +:+  +:+   +:+  +:+    +:+ +:+    +:+ +:+    +:+
 *         +#+    +:+ +#+  +:+  +#+ +#++:++#++: +#+    +:+ +#++:++#:  +#+    +:+
 *         +#+  # +#+ +#+ +#+#+ +#+ +#+     +#+ +#+    +#+ +#+    +#+ +#+    +#+
 *         #+#   +#+   #+#+# #+#+#  #+#     #+# #+#    #+# #+#    #+# #+#    #+#
 *          ###### ###  ###   ###   ###     ### #########  ###    ###  ########
 *
 *              T H E   Q W A D R O   E X E C U T I O N   E C O S Y S T E M
 *
 *                                   Public Test Build
 *                   (c) 2017 SIGMA Technology Group � Federa��o SIGMA
 *                                    www.sigmaco.org
 */

#define _CRT_SECURE_NO_WARNINGS 1
#include <stdarg.h>
#include <string.h>
#include <ctype.h>
#include <stdio.h>
#include "afx/core/afxString.h"
#include "afx/core/afxContext.h"
#include "afx/core/afxStream.h"
#include "afx/core/afxSystem.h"

_AFX afxString strEmptyData = AFX_STRING_LITERAL("");
_AFX afxString const AFX_STR_EMPTY = AFX_STRING_LITERAL("");

_AFXINL void* AfxGetStringData(afxString *str, afxNat base)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertString(str);
    //AfxAssert(base < str->range);

    //if (base < str->range)
        //return NIL;

    if (str->flags & _AFX_STR_FLAG_EXCERPT)
    {
        return AfxGetStringData(str->src.parentRW, str->src.base + base);
    }
    else
    {
        return &(str->src.startRW[base]);
    }
    return NIL;
};

_AFXINL void const* AfxGetStringDataConst(afxString const *str, afxNat base)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertString(str);

    //AfxAssert(base < str->range);

    //if (base < str->range)
        //return NIL;

    if (str->flags & _AFX_STR_FLAG_EXCERPT)
    {
        return AfxGetStringDataConst(str->src.parent, str->src.base + base);
    }
    else
    {
        return &(str->src.start[base]);
    }

    return NIL;
};

_AFXINL afxNat AfxGetStringSize(afxString const *str)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertString(str);
    return str->range;
};

_AFXINL afxNat AfxGetStringBufferCap(afxString const *str)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertString(str);

    if (str->flags & _AFX_STR_FLAG_EXCERPT)
    {
        return AfxGetStringBufferCap(str->src.parent);
    }
    else
    {
        return (str->flags & _AFX_STR_FLAG_BUFFERED) ? str->src.cap : 0;
    }
};

_AFXINL afxError AfxGetStringAsHex(afxString const *str, afxNat32 *value)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertString(str);
    AfxAssert(value);
    AfxScanString(str, "%x", value);
    return err;
}

_AFXINL afxError AfxGetStringAsReal(afxString const *str, afxReal *value)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertString(str);
    AfxAssert(value);
    void const *src = AfxGetStringDataConst(str, 0);
    AfxAssert(src);
    *value = strtod(src, NIL);
    return err;
}

_AFXINL afxBool AfxStringIsEmpty(afxString const *str)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertString(str);
    return (0 == str->range);
}

AFX afxBool AfxStringIsWriteable(afxString const *str)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertString(str);
    afxNat cap = AfxGetStringBufferCap(str);
    return (0 < cap) && (str->flags & _AFX_STR_FLAG_BUFFERED);
}

_AFXINL afxChar* AfxFindStringCharB2F(afxString const *str, afxNat base, afxInt ch)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertString(str);
    void const *src = AfxGetStringDataConst(str, base);
    AfxAssert(src);
    AfxAssert(0 < str->range - base);
    return (0 < str->range - base) && src ? strrchr(src, ch) : NIL; // can fault if str isn't null terminated
}

_AFXINL afxChar* AfxFindStringChar(afxString const *str, afxNat base, afxInt ch)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertString(str);
    void const *src = AfxGetStringDataConst(str, base);
    AfxAssert(src);
    AfxAssert(0 < str->range - base);
    return (0 < str->range - base) && src ? memchr(src, ch, str->range - base) : NIL;
}

_AFXINL afxResult AfxCompareStringLiteralCi(afxString const *str, afxNat base, afxChar const *start, afxNat range)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertString(str);
    AfxAssert(start);

    if (!range)
        range = AfxMeasureRawString(start);

    if (str->range + range == 0) return 0;
    else if ((str->range != range) || ((!str->range && range) || (!range && str->range))) // if have different lenghts or any of them is blank.
        return str->range - range;

    afxString a, b;
    AfxExcerptStringRange(&a, str, base, range);
    AfxWrapStringLiteral(&b, start, range);
    return AfxCompareStringCi(&a, &b);
}

_AFXINL afxResult AfxCompareStringLiteral(afxString const *str, afxNat base, afxChar const *start, afxNat range)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertString(str);
    AfxAssert(start);

    if (!range)
        range = AfxMeasureRawString(start);

    if (str->range + range == 0) return 0;
    else if ((str->range != range) || ((!str->range && range) || (!range && str->range))) // if have different lenghts or any of them is blank.
        return str->range - range;

    afxString a, b;
    AfxExcerptStringRange(&a, str, base, range);
    AfxWrapStringLiteral(&b, start, range);
    return AfxCompareString(&a, &b);
}

_AFXINL afxResult AfxCompareStringRangeCi(afxString const *str, afxString const *other, afxNat base, afxNat range)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertString(str);

    afxString a, b;
    AfxWrapStringLiteral(&a, AfxGetStringDataConst(str, base), range);
    AfxWrapStringLiteral(&b, AfxGetStringDataConst(other, base), range);
    return AfxCompareStringCi(&a, &b);
}

_AFXINL afxResult AfxCompareStringRange(afxString const *str, afxString const *other, afxNat base, afxNat range)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertString(str);

    afxString a, b;
    AfxWrapStringLiteral(&a, AfxGetStringDataConst(str, base), range);
    AfxWrapStringLiteral(&b, AfxGetStringDataConst(other, base), range);
    return AfxCompareString(&a, &b);
}

_AFXINL afxResult AfxCompareStringCi(afxString const *str, afxString const *other)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertString(str);
    AfxAssertString(other);

    if (str->range + other->range == 0) return 0;
    else if ((str->range != other->range) || ((!str->range && other->range) || (!other->range && str->range))) // if have different lenghts or any of them is blank.
        return str->range - other->range;

    void const *a = AfxGetStringDataConst(str, 0);
    void const *b = AfxGetStringDataConst(other, 0);
    AfxAssert(a);
    AfxAssert(b);
    return _strnicmp(a, b, str->range);
}

_AFXINL afxResult AfxCompareString(afxString const *str, afxString const *other)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertString(str);
    AfxAssertString(other);

    if (str->range + other->range == 0) return 0;
    else if ((str->range != other->range) || ((!str->range && other->range) || (!other->range && str->range))) // if have different lenghts or any of them is blank.
        return str->range - other->range;

    void const *a = AfxGetStringDataConst(str, 0);
    void const *b = AfxGetStringDataConst(other, 0);
    AfxAssert(a);
    AfxAssert(b);
    return strncmp(a, b, str->range);
}

_AFXINL afxResult AfxScanStringArg(afxString const *str, afxChar const *fmt, va_list args)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertString(str);
    void const *src = AfxGetStringDataConst(str, 0);
    AfxAssert(src);
    AfxAssert(fmt);
    afxResult rslt = vsscanf(src, fmt, args);
    return rslt;
}

_AFXINL afxResult AfxScanString(afxString const *str, afxChar const *fmt, ...)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertString(str);
    void const *src = AfxGetStringDataConst(str, 0);
    AfxAssert(src);
    AfxAssert(fmt);

    va_list args;
    va_start(args, fmt);
    afxResult rslt = vsscanf(src, fmt, args);
    va_end(args);
    return rslt;
}

_AFXINL afxResult AfxDumpString(afxString const *str, afxNat base, afxNat range, void *dst)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertString(str);
    AfxAssertRange(str->range, base, range);
    afxNat maxRange = AfxGetStringSize(str);
    AfxAssert(base + range <= maxRange);
    void const *src = AfxGetStringDataConst(str, base);
    AfxAssert(src);
    AfxAssert(range);
    AfxAssert(dst);
    AfxCopy(dst, src, range > maxRange - base ? maxRange - base : range);
    return 0;
}

_AFXINL afxBool WildCardMatch(afxString const *str, const char *Wildcard, char *Out)
{
    // bool __cdecl WildCardMatch(const char *Name, const char *Wildcard, char *Out)

    afxBool result;

    afxChar const* v3 = AfxGetStringDataConst(str, 0);
    
    if (Wildcard)
    {
        afxChar const* i;
        afxChar* v6 = Out;

        while (1)
        {
            afxChar const* v4 = Wildcard;
            afxChar v7;

            while (1)
            {
            LABEL_4:
                while (1)
                {
                    v7 = *v4;

                    if (*v4 != 63)
                        break;

                    if (*v3)
                        *v6++ = *v3++;

                    ++v4;
                }

                if (v7 != 42)
                    break;

                afxChar v8 = (v4++)[1];

                for (i = v4; v8; v8 = (i++)[1])
                {
                    if (v8 == 59)
                        break;

                    if (v8 == 63)
                        break;

                    if (v8 == 42)
                        break;
                }

                afxNat v10 = i - v4;

                if (i == v4)
                {
                    AfxCopyRawString(v6, v3);
                    return 1;
                }

                if (*v3)
                {
                    afxString t1, t2;
                    AfxWrapStringLiteral(&t1, v4, v10);
                    AfxWrapStringLiteral(&t2, v3, v10);

                    while (AfxCompareString(&t1, &t2) || !WildCardMatch(&t2, v4, v6))
                    {
                        *v6 = *v3;
                        afxChar v11 = v3[1];
                        ++v6;
                        ++v3;
                        if (!v11)
                            goto LABEL_4;
                    }
                    return 1;
                }
            }
            
            if (!v7)
                break;

            afxChar v12 = tolower(v7);
            
            if (v12 != tolower(*v3))
                return 0;

            ++v3;
            ++v4;
        }

        *v6 = 0;
        result = *v3 == 0;
    }
    else
    {
        AfxCopyRawString(Out, v3);
        result = 1;
    }
    return result;
}

// READ/WRITE METHODS /////////////////////////////////////////////////////////

_AFXINL void AfxDeallocateString(afxString *str)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertString(str);
    //AfxAssert(str->flags & _AFX_STR_FLAG_ALLOCED);
    
    if (str->flags & _AFX_STR_FLAG_ALLOCED)
    {
        if (str->src.startRW)
            AfxDeallocate(NIL, str->src.startRW);

        str->src.startRW = NIL;
        AfxResetString(str);
    }
}

_AFXINL afxError AfxAllocateString(afxString* str, afxNat cap, void const *start, afxNat range)
{
    afxError err = AFX_ERR_NONE;
    AfxAssert(!range || (range && start));
    
    if (start && !range)
        range = AfxMeasureRawString(start);

    //AfxAssert(range);
    afxNat effectiveCap = cap ? cap : range;
    //AfxAssert(effectiveCap);
    AfxAssert(range <= effectiveCap);
    afxNat effectiveRange = range > effectiveCap ? effectiveCap : range; // truncate to capacity when string has space.
    //AfxAssert(effectiveRange);

    void *buf = NIL;
    
    if (effectiveCap && !(buf = AfxAllocate(NIL, effectiveCap, 0, AfxSpawnHint())))
        AfxThrowError();

    AfxWrapStringBuffer(str, buf, effectiveCap);
    str->flags = _AFX_STR_FLAG_ALLOCED | _AFX_STR_FLAG_BUFFERED;

    if (effectiveRange)
    {
        afxString src;
        AfxWrapStringLiteral(&src, start, effectiveRange);
        AfxCopyString(str, &src);
    }
    return err;
}

#if 0
_AFXINL afxError AfxReallocateString(afxString *str, afxNat cap, void const *start, afxNat range)
{
    afxError err = AFX_ERR_NONE;
    AfxAssert(!range || (range && start));
    void *buf = NIL;

    if (start && !range)
        range = AfxMeasureRawString(start);

    {
        AfxAssertString(str);
        AfxAssert(str->flags & _AFX_STR_FLAG_ALLOCED);
        AfxAssert(str->flags & _AFX_STR_FLAG_BUFFERED);
        afxNat effectiveCap = cap ? cap : range;
        AfxAssert(effectiveCap);
        AfxAssert(range <= effectiveCap);
        afxNat effectiveRange = range > effectiveCap ? effectiveCap : range; // truncate to capacity when string has space.
        AfxAssert(effectiveRange);

        if (!(buf = AfxReallocate(NIL, str->src.startRW, effectiveCap, 0, AfxSpawnHint()))) AfxThrowError();
        else
        {
            str->range = effectiveRange;
            str->src.cap = effectiveCap;
            str->src.startRW = buf;

            AfxCopy(str->src.startRW, start, str->range);

            if (str->src.cap > str->range)
                str->src.startRW[str->range] = '\0';
        }
    }
    return err;
}
#endif

_AFXINL afxResult _AfxWriteString(afxString *str, afxNat base, void const *src, afxNat range)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertString(str);
    AfxAssert(AfxStringIsWriteable(str));
    afxResult rslt = 0;

    AfxAssert(src);

    if (!range)
        range = AfxMeasureRawString(src);

    AfxAssert(range);
    afxNat cap = AfxGetStringBufferCap(str);
    AfxAssert(cap >= range);
    afxNat effectiveCap = (cap - base);
    AfxAssert(range <= effectiveCap);
    afxNat effectiveRange = range > effectiveCap ? effectiveCap : range; // truncate to capacity when string has space.
    AfxAssert(effectiveRange);

    afxChar *start = AfxGetStringData(str, base);
    AfxAssert(start);
    AfxCopy(start, src, effectiveRange);


    if (base + effectiveRange > str->range)
        str->range = base + effectiveRange;


    if (effectiveCap > effectiveRange)
        start[effectiveRange] = '\0';
    
    return err;
}

_AFXINL afxResult AfxFormatStringArg(afxString *str, afxChar const *fmt, va_list args)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertString(str);
    AfxAssert(AfxStringIsWriteable(str));
    afxNat cap = AfxGetStringBufferCap(str);
    AfxAssert(cap);
    AfxAssert(fmt);
    AfxAssert(args);
    void *map = AfxGetStringData(str, 0);
    AfxAssert(map);
    return (str->range = vsnprintf(map, cap, fmt, args));
}

_AFXINL afxResult AfxFormatString(afxString *str, afxChar const *fmt, ...)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertString(str);
    AfxAssert(AfxStringIsWriteable(str));

    va_list args;
    AfxAssert(fmt);
    va_start(args, fmt);
    AfxFormatStringArg(str, fmt, args);
    va_end(args);
    return str->range;
}

_AFXINL afxNat AfxAppendStringLiteral(afxString *str, afxChar const *start, afxNat range)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertString(str);
    AfxAssert(AfxStringIsWriteable(str));

    if (!range && start)
        range = AfxMeasureRawString(start);

    afxString tmp;
    AfxWrapStringLiteral(&tmp, start, range);
    afxNat overflow = AfxAppendString(str, &tmp);
    AfxAssert(!overflow);
    return overflow;
}

_AFXINL afxNat AfxAppendString(afxString *str, afxString const *in)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertString(str);
    AfxAssert(AfxStringIsWriteable(str));
    AfxAssertString(in);
    afxNat srcLen = AfxGetStringSize(in);
    afxNat effectiveRange = 0;

    if (srcLen)
    {
        afxNat base = AfxGetStringSize(str);
        afxNat cap = AfxGetStringBufferCap(str);
        AfxAssert(cap); // writeable strings must have capacity
        afxNat leftCap = (cap - base);

        if (!leftCap) AfxThrowError();
        else
        {
            void *dstData = AfxGetStringData(str, base);
            AfxAssert(dstData);
            AfxAssert(leftCap >= srcLen);
            effectiveRange = srcLen > leftCap ? leftCap : srcLen; // truncate to capacity when string has space.
            AfxAssert(effectiveRange == srcLen);

            if (!dstData) AfxThrowError();
            else
            {
                afxString tmp;
                AfxWrapStringBuffer(&tmp, dstData, effectiveRange);
                AfxCopyString(&tmp, in);
                str->range += tmp.range;
            }
        }
    }
    return srcLen - effectiveRange;
}

_AFXINL afxNat AfxCopyStringRange(afxString *str, afxString const *in, afxNat base, afxNat range)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertString(str);
    AfxAssert(AfxStringIsWriteable(str));
    AfxAssertString(in);
    AfxAssertRange(in->range, base, range);

    afxString tmp;

    if (AfxExcerptStringRange(&tmp, in, base, range))
        AfxThrowError();

    afxNat overflow = AfxCopyString(str, &tmp);
    AfxAssert(!overflow);
    return overflow;
}

_AFXINL afxNat AfxCopyString(afxString *str, afxString const *in)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertString(str);
    AfxAssert(AfxStringIsWriteable(str));

    if (in)
    {
        AfxAssertString(in);

        afxChar *start = AfxGetStringData(str, 0);
        afxNat cap = AfxGetStringBufferCap(str);
        afxNat range = AfxGetStringSize(in);
        afxNat effectiveRange = range > cap ? cap : range;
        AfxAssert(effectiveRange == range);

        if (effectiveRange)
        {
            afxChar const *src = AfxGetStringDataConst(in, 0);
            AfxAssert(src); // if it has range it must have data.
            AfxAssert(start); // if it is writeable it must have data.
            AfxCopy(start, src, effectiveRange);
        }

        if (cap > effectiveRange) // opportunistic attempt to use left space to zero-terminate string.
            start[effectiveRange] = '\0';

        str->range = effectiveRange;

        return range - effectiveRange;
    }
    else
    {
        AfxClearString(str);
        return 0;
    }
}

_AFXINL void AfxClearString(afxString *str)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertString(str);

    if (str->flags & _AFX_STR_FLAG_EXCERPT)
    {
        str->src.base = 0;
        str->src.parent = NIL;
        str->flags &= ~_AFX_STR_FLAG_EXCERPT;
    }
    else
    {
        if (str->src.cap)
        {
            str->src.startRW[0] = '\0';
        }
        else
        {
            str->src.start = NIL;
        }
    }

    str->range = 0;
}

_AFXINL afxError AfxCloneStringRange(afxString* str, afxString const *in, afxNat base, afxNat range)
{
    afxError err = AFX_ERR_NONE;

    if (in)
    {
        AfxAssertString(in);
        AfxAssertRange(in->range, base, range);

        if (range)
        {
            afxString tmp;

            if (AfxExcerptStringRange(&tmp, in, base, range))
                AfxThrowError();

            if (AfxCloneString(str, &tmp))
                AfxThrowError();
        }
    }
    else
    {
        AfxResetString(str);
    }
    return err;
}

_AFXINL afxError AfxCloneString(afxString* str, afxString const *in)
{
    afxError err = AFX_ERR_NONE;
    
    if (in)
    {
        AfxAssertString(in);

        afxNat size = AfxGetStringSize(in);

        if (!size) AfxResetString(str);
        else
        {
            void const *data = AfxGetStringDataConst(in, 0);

            if (data && AfxAllocateString(str, 0, data, size))
            {
                AfxThrowError();
                AfxResetString(str);
            }
        }
    }
    else
    {
        AfxResetString(str);
    }
    return err;
}

_AFXINL afxNat AfxExcerptStringRange(afxString *str, afxString const *parent, afxNat offset, afxNat range)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertString(parent);
    AfxAssertRange(parent->range, offset, range);

    afxNat maxRange = AfxGetStringSize(parent);
    afxNat effectiveRange = range > maxRange ? maxRange : range;
    AfxAssert(effectiveRange == range);

    AfxAssert(str);
#if _AFX_DEBUG
    str->fcc = afxFcc_STR;
#endif
    str->range = effectiveRange;
    str->flags = _AFX_STR_FLAG_EXCERPT;
    str->src.base = offset;
    str->src.parent = parent;

    if (err)
    {
        int a = 0;
    }

    return range - effectiveRange;
}

_AFXINL void AfxExcerptString(afxString *str, afxString const *parent)
{
    afxError err = AFX_ERR_NONE;
    AfxAssert(str);
    AfxAssertString(parent);
    
    if (AfxExcerptStringRange(str, parent, 0, AfxGetStringSize(parent)))
        AfxThrowError();
}

_AFXINL void AfxWrapStringLiteral(afxString *str, void const *start, afxNat range)
{
    afxError err = AFX_ERR_NONE;
    AfxAssert(str);
    AfxAssert(!range || (range && start));

#if _AFX_DEBUG
    str->fcc = afxFcc_STR;
#endif
    str->range = range ? range : (start ? AfxMeasureRawString(start) : 0);
    str->flags = _AFX_STR_FLAG_WRAP;
    str->src.cap = 0;
    str->src.start = start;
}

_AFXINL void AfxWrapStringLiteralRW(afxString *str, void *start, afxNat range)
{
    afxError err = AFX_ERR_NONE;
    AfxAssert(str);
    AfxAssert(!range || (range && start));
    
#if _AFX_DEBUG
    str->fcc = afxFcc_STR;
#endif
    str->range = range ? range : (start ? AfxMeasureRawString(start) : 0);
    str->flags = _AFX_STR_FLAG_WRAP | _AFX_STR_FLAG_BUFFERED;
    str->src.cap = str->range;
    str->src.start = start;
}

_AFXINL void AfxWrapStringBuffer(afxString *str, void *start, afxNat cap)
{
    afxError err = AFX_ERR_NONE;
    AfxAssert(str);
    AfxAssert(start);
    AfxAssert(cap);

#if _AFX_DEBUG
    str->fcc = afxFcc_STR;
#endif
    str->range = 0;
    str->flags = _AFX_STR_FLAG_WRAP | _AFX_STR_FLAG_BUFFERED;
    str->src.cap = cap;
    str->src.start = start;
}

_AFXINL void AfxResetString(afxString *str)
{
    afxError err = AFX_ERR_NONE;
    AfxAssert(str);
#if _AFX_DEBUG
    str->fcc = afxFcc_STR;
#endif
    str->range = 0;
    str->flags = NIL;
    str->src.cap = 0;
    str->src.start = NIL;
}

#if 0
_AFXINL afxString* AfxString128DeployRaw(afxString128 *str, afxChar const *src, afxNat range)
{
    afxError err = AFX_ERR_NONE;
    AfxAssert(str);
    AfxAssert(!range || (range && src));
    AfxWrapStringBuffer(&str->str, str->buf, sizeof(str->buf));

    if (src && src[0])
    {
        if (!range)
            range = AfxMeasureRawString(src);

        if (range > str->str._cap)
            range = str->str._cap;

        AfxCopy(&str->str._data, src, range);
        str->str._bytemap[range] = '\0';
    }
    return &str->str;
}

_AFXINL afxString* AfxString128(afxString128 *str, afxString const *src)
{
    afxError err = AFX_ERR_NONE;
    AfxAssert(str);
    AfxWrapStringBuffer(&str->str, str->buf, sizeof(str->buf));

    if (src && !AfxStringIsEmpty(src))
        AfxCopyString(&str->str, src);

    return &str->str;
}
#endif

_AFX void AfxString8(afxString8 *str)
{
    afxError err = AFX_ERR_NONE;
    AfxAssert(str);
    AfxWrapStringBuffer(&str->str, str->buf, sizeof(str->buf));
}

_AFX void AfxString16(afxString16 *str)
{
    afxError err = AFX_ERR_NONE;
    AfxAssert(str);
    AfxWrapStringBuffer(&str->str, str->buf, sizeof(str->buf));
}

_AFX void AfxString32(afxString32 *str)
{
    afxError err = AFX_ERR_NONE;
    AfxAssert(str);
    AfxWrapStringBuffer(&str->str, str->buf, sizeof(str->buf));
}

_AFX void AfxString128(afxString128 *str)
{
    afxError err = AFX_ERR_NONE;
    AfxAssert(str);
    AfxWrapStringBuffer(&str->str, str->buf, sizeof(str->buf));
}
