/*
 *          ::::::::  :::       :::     :::     :::::::::  :::::::::   ::::::::
 *         :+:    :+: :+:       :+:   :+: :+:   :+:    :+: :+:    :+: :+:    :+:
 *         +:+    +:+ +:+       +:+  +:+   +:+  +:+    +:+ +:+    +:+ +:+    +:+
 *         +#+    +:+ +#+  +:+  +#+ +#++:++#++: +#+    +:+ +#++:++#:  +#+    +:+
 *         +#+  # +#+ +#+ +#+#+ +#+ +#+     +#+ +#+    +#+ +#+    +#+ +#+    +#+
 *         #+#   +#+   #+#+# #+#+#  #+#     #+# #+#    #+# #+#    #+# #+#    #+#
 *          ###### ###  ###   ###   ###     ### #########  ###    ###  ########
 *
 *              T H E   Q W A D R O   E X E C U T I O N   E C O S Y S T E M
 *
 *                                   Public Test Build
 *                   (c) 2017 SIGMA Technology Group � Federa��o SIGMA
 *                                    www.sigmaco.org
 */
 
 /* -*- mode: c; tab-width: 2; indent-tabs-mode: nil; -*-
Copyright (c) 2012 Marcus Geelnard
Copyright (c) 2013-2016 Evan Nemerson

This software is provided 'as-is', without any express or implied
warranty. In no event will the authors be held liable for any damages
arising from the use of this software.

Permission is granted to anyone to use this software for any purpose,
including commercial applications, and to alter it and redistribute it
freely, subject to the following restrictions:

    1. The origin of this software must not be misrepresented; you must not
    claim that you wrote the original software. If you use this software
    in a product, an acknowledgment in the product documentation would be
    appreciated but is not required.

    2. Altered source versions must be plainly marked as such, and must not be
    misrepresented as being the original software.

    3. This notice may not be removed or altered from any source
    distribution.
*/

//#include "../src/e2coree/deps/tinycthread.h"
#include <stdlib.h>
/* Platform specific includes */


#define _CRT_SECURE_NO_WARNINGS 1
#define WIN32_LEAN_AND_MEAN 1

#if (defined(_WIN32) || defined(_WIN64))
#   include <Windows.h>
#endif

#if defined(_WIN32)
#include <process.h>
#include <sys/timeb.h>
#include <time.h>
#else
  #include <signal.h>
  #include <sched.h>
  #include <unistd.h>
  #include <sys/time.h>
  #include <errno.h>
#endif

#include <sys/stat.h>
#include <stdio.h>

#define _AFX_THREAD_C
#define _AFX_SYSTEM_C
#include "afx/core/afxCondition.h"
#include "afx/core/afxThread.h"
#include "afx/core/afxDebug.h"
#include "afx/core/afxSystem.h"

_AFX void AfxGetThreadingId(afxNat32 *tid)
{
#if defined(_WIN32)
    afxError err = NIL;
    AfxAssert(tid);
    *tid = GetCurrentThreadId();
#else
#error "";
#endif
}

#if 0
afxResult _AfxDestroyThread(afxThread thr)
{
    AfxEntry("thr=%p", thr);

#if defined(_TTHREAD_WIN32_)
  /* https://stackoverflow.com/questions/12744324/how-to-detach-a-thread-on-windows-c#answer-12746081 */
  return CloseHandle((HANDLE)thr->osHandle) != 0 ? thrd_success : thrd_error;
#else
  return pthread_detach(thr->osHandle) == 0 ? thrd_success : thrd_error;
#endif
}
#endif

_AFX afxBool AfxThreadAreEqual(afxThread thr, afxThread other)
{
#if 0
#if defined(_WIN32)
  return GetThreadId((HANDLE)thr->osHandle) == GetThreadId((HANDLE)other->osHandle);
#else
  return pthread_equal(thr->osHandle, other->osHandle);
#endif
#else
    return (thr == other);
#endif
}

_AFX void AfxEndProcessor(afxResult code)
{
    AfxEntry("code=%i", code);

#if defined(_WIN32)
#if _TTHREAD_WIN32_TSS_
  if (_tinycthread_tss_head != NULL)
  {
    _tinycthread_tss_cleanup();
  }
#endif//_TTHREAD_WIN32_TSS_
  ExitThread((DWORD)code);
#else
  pthread_exit((void*)(intptr_t)res);
#endif
}

_AFX afxResult AfxWaitForThread(afxThread thr, afxResult *exitCode)
{
    AfxEntry("thr=%p,exitCode=%p", thr, exitCode);
    afxError err = AFX_ERR_NONE;
    AfxAssertObjects(1, &thr, afxFcc_THR);

#if 0
#if defined(_WIN32)
  DWORD dwRes;

  if (WaitForSingleObject((HANDLE)thr->osHandle, INFINITE) == WAIT_FAILED)
  {
      AfxThrowError();
    return thrd_error;
  }
  if (exitCode != NULL)
  {
    if (GetExitCodeThread((HANDLE)thr->osHandle, &dwRes) != 0)
    {
      *exitCode = (int) dwRes;
    }
    else
    {
        AfxThrowError();
      return thrd_error;
    }
  }
  CloseHandle((HANDLE)thr->osHandle);
  thr->osHandle = NIL;
#else
  void* pres;
  if (pthread_join(thr, &pres) != 0)
  {
    return thrd_error;
  }
  if (res != NULL)
  {
    *res = (int)(intptr_t)pres;
  }
#endif
#else

    if (!thr->started || thr->finished)
    {
        // The thread associated with this QThread object has finished execution (i.e. when it returns from run()). This function will return true if the thread has finished. It also returns true if the thread has not been started yet.
        AfxAssert(!thr->running);
        return TRUE;
    }
    else
    {
        while (thr->running)
        {
            AfxYieldThreading();
        }
        return TRUE;
    }
#endif
  AfxEcho("Joined. (thr)%p", thr);
  return 0;
}

_AFX afxResult AfxSleepProcessor(afxTimeSpec const* dur, afxTimeSpec *remaining)
{
#if !defined(_WIN32)
  int res = nanosleep(dur, remaining);
  if (res == 0) {
    return 0;
  } else if (errno == EINTR) {
    return -1;
  } else {
    return -2;
  }
#else
  struct timespec start;
  DWORD t;

  timespec_get(&start, TIME_UTC);

  t = SleepEx((DWORD)(dur->sec * 1000 +
      dur->nsec / 1000000 +
              (((dur->nsec % 1000000) == 0) ? 0 : 1)),
              TRUE);

  if (t == 0) {
    return 0;
  } else {
    if (remaining != NULL) {
      timespec_get((struct timespec* const)remaining, TIME_UTC);
      remaining->sec -= start.tv_sec;
      remaining->nsec -= start.tv_nsec;
      if (remaining->nsec < 0)
      {
        remaining->nsec += 1000000000;
        remaining->sec -= 1;
      }
    }

    return (t == WAIT_IO_COMPLETION) ? -1 : -2;
  }
#endif
}

_AFX void AfxYieldThreading(void)
{
#if defined(_WIN32)
  Sleep(0);
#else
  sched_yield();
#endif
}

typedef struct _afxThrParadigm
{
    void(*start)(afxThread thr, void *udd);
    void *udd;
    void(*exec)(afxThread thr);
} _afxThrParadigm;

_AFX void AfxGetThread(afxThread *thr)
{
    afxError err = AFX_ERR_NONE;
    
    afxNat32 tid;
    AfxGetThreadingId(&tid);

    afxNat i = 0;
    afxSystem sys;
    AfxGetSystem(&sys);
    AfxAssertObjects(1, &sys, afxFcc_SYS);
    while (i < sys->processors.totalUsedCnt)
    {
        afxProcessor *procUnit;

        if (!(AfxGetPoolUnit(&sys->processors, i, (void**)&procUnit))) AfxThrowError();
        else
        {
            if (tid == procUnit->tid)
            {
                afxThread thr2 = procUnit->activeThr;
                AfxAssertObjects(1, &thr2, afxFcc_THR);
                AfxAssert(thr);
                *thr = thr2;
                return;
            }
        }
        ++i;
    }
    *thr = NIL;
}

_AFX void AfxGetThreadingUnit(afxNat *unitIdx)
{
    afxError err = AFX_ERR_NONE;
    
    afxNat32 tid;
    AfxGetThreadingId(&tid);
        
    afxNat i = 0;
    afxSystem sys;
    AfxGetSystem(&sys);
    AfxAssertObjects(1, &sys, afxFcc_SYS);
    while (i < sys->processors.totalUsedCnt)
    {
        afxProcessor *procUnit;

        if (!(AfxGetPoolUnit(&sys->processors, i, (void**)&procUnit))) AfxThrowError();
        else
        {
            if (tid == procUnit->tid)
            {
                AfxAssert(unitIdx);
                *unitIdx = i;
                return;
            }
        }
        ++i;
    }
    //*unitIdx = AFX_INVALID_INDEX;
}

_AFX void AfxGetExecutionCounter(afxNat *currIter, afxNat *lastFreq)
{
    afxError err = AFX_ERR_NONE;
    AfxAssert(currIter || lastFreq);
    
    afxNat32 tid;
    AfxGetThreadingId(&tid);

    afxNat i = 0;
    afxSystem sys;
    AfxGetSystem(&sys);
    AfxAssertObjects(1, &sys, afxFcc_SYS);
    while (i < sys->processors.totalUsedCnt)
    {
        afxProcessor *procUnit;

        if (!(AfxGetPoolUnit(&sys->processors, i, (void**)&procUnit))) AfxThrowError();
        else
        {
            if (tid == procUnit->tid)
            {
                afxThread thr = procUnit->activeThr;
                AfxAssertObjects(1, &thr, afxFcc_THR);

                if (currIter)
                    *currIter = thr->iterCnt;

                if (lastFreq)
                    *lastFreq = thr->lastIterCnt;

                return;
            }
        }
        ++i;
    }

    if (currIter)
        *currIter = 0;

    if (lastFreq)
        *lastFreq = 0;
}

_AFX void AfxGetExecutionTime(afxReal64 *curr, afxReal64 *delta)
{
    afxError err = AFX_ERR_NONE;
    AfxAssert(curr || delta);

    afxNat32 tid;
    AfxGetThreadingId(&tid);

    afxNat i = 0;
    afxSystem sys;
    AfxGetSystem(&sys);
    AfxAssertObjects(1, &sys, afxFcc_SYS);
    while (i < sys->processors.totalUsedCnt)
    {
        afxProcessor *procUnit;

        if (!(AfxGetPoolUnit(&sys->processors, i, (void**)&procUnit))) AfxThrowError();
        else
        {
            if (tid == procUnit->tid)
            {
                afxThread thr = procUnit->activeThr;
                AfxAssertObjects(1, &thr, afxFcc_THR);

                if (curr)
                    *curr = thr->currTime;

                if (delta)
                    *delta = thr->deltaTime;

                return;
            }
        }
        ++i;
    }

    if (curr)
        *curr = 0;

    if (delta)
        *delta = 0;
}

_AFX void AfxGetExecutionClock(afxClock *curr, afxClock *last)
{
    afxError err = AFX_ERR_NONE;
    AfxAssert(curr || last);

    afxNat32 tid;
    AfxGetThreadingId(&tid);

    afxNat i = 0;
    afxSystem sys;
    AfxGetSystem(&sys);
    AfxAssertObjects(1, &sys, afxFcc_SYS);
    while (i < sys->processors.totalUsedCnt)
    {
        afxProcessor *procUnit;

        if (!(AfxGetPoolUnit(&sys->processors, i, (void**)&procUnit))) AfxThrowError();
        else
        {
            if (tid == procUnit->tid)
            {
                afxThread thr = procUnit->activeThr;
                AfxAssertObjects(1, &thr, afxFcc_THR);

                if (curr)
                    *curr = thr->currClock;

                if (last)
                    *last = thr->lastClock;

                return;
            }
        }
        ++i;
    }

    if (curr)
        *curr = (afxClock) { 0 };

    if (last)
        *last = (afxClock) { 0 };
}

_AFX afxBool AfxGetThreadExitCode(afxThread thr, afxInt *exitCode)
{
    AfxEntry("thr=%p", thr);
    afxError err = AFX_ERR_NONE;
    AfxAssertObjects(1, &thr, afxFcc_THR);

    // Retrieves the context of the specified thread.

    AfxAssert(exitCode);
    *exitCode = thr->exitCode;
    return AfxThreadIsFinished(thr);
}

_AFX void AfxExitExecution(afxInt code)
{
    afxError err = AFX_ERR_NONE;
    
    afxThread thr;
    AfxGetThread(&thr);
    AfxEntry("thr=%p", thr);
    AfxAssertObjects(1, &thr, afxFcc_THR);

    // Tells the thread's event loop to exit with a return code.
    // After calling this function, the thread leaves the event loop and returns from the call to QEventLoop::exec().The QEventLoop::exec() function returns returnCode.
    // By convention, a returnCode of 0 means success, any non - zero value indicates an error.
    // Note that unlike the C library function of the same name, this function does return to the caller -- it is event processing that stops.
    // No QEventLoops will be started anymore in this thread until QThread::exec() has been called again.If the eventloop in QThread::exec() is not running then the next call to QThread::exec() will also return immediately.

    thr->exitCode = code;
    thr->exited = TRUE;

    thr->running = FALSE;
}

_AFX void AfxQuitExecution(void)
{
    // Tells the thread's event loop to exit with return code 0 (success). Equivalent to calling QThread::exit(0).
    // This function does nothing if the thread does not have an event loop.
    AfxExitExecution(0);
}

_AFX void AfxRequestThreadInterruption(afxThread thr)
{
    AfxEntry("thr=%p", thr);
    afxError err = AFX_ERR_NONE;
    AfxAssertObjects(1, &thr, afxFcc_THR);

    //void requestInterruption()
    //Request the interruption of the thread.That request is advisory and it is up to code running on the thread to decide if and how it should act upon such request. 
    // This function does not stop any event loop running on the thread and does not terminate it in any way.

    if (!thr->running || thr->finished || thr->isInFinish)
    {
        // nothing to do
    }
    else
    {
        thr->interruptionRequested = TRUE;
    }
}

_AFX afxError AfxExecuteThread(afxThread thr)
{
    afxError err = AFX_ERR_NONE;
    afxThreadOpcode thrOpcode = NIL;

    afxNat procUnitIdx;
    AfxGetThreadingUnit(&procUnitIdx);

    afxSystem sys;
    AfxGetSystem(&sys);
    AfxAssertObjects(1, &sys, afxFcc_SYS);

    if (sys->processors.totalUsedCnt > procUnitIdx)
    {
        AfxAssertObjects(1, &thr, afxFcc_THR);

        if (AfxTryEnterSlockExclusive(&thr->procSlock))
        {
            afxProcessor *procUnit;

            if (!(AfxGetPoolUnit(&sys->processors, procUnitIdx, (void**)&procUnit))) AfxThrowError();
            else
            {
                afxNat affineProcUnitIdx = thr->affineProcUnitIdx;

                if ((AFX_INVALID_INDEX == affineProcUnitIdx) || (affineProcUnitIdx == procUnitIdx))
                {
                    afxThread backedUpThr;

                    if (thr != (backedUpThr = procUnit->activeThr)) // do not allow reentrancy
                    {
                        procUnit->activeThr = thr;

                        {
                            if (thr->running && !thr->started && !thr->finished && AfxSystemIsOperating())
                            {
                                thrOpcode = AFX_THR_OPCODE_RUN;
                                thr->started = TRUE;
                            }

                            if (thr->running)
                            {
                                // Ignore clock recentering issues for this example
                                AfxGetClock(&thr->currClock);
                                thr->currTime = AfxGetSecondsElapsed(&thr->startClock, &thr->currClock);
                                thr->deltaTime = AfxGetSecondsElapsed(&thr->lastClock, &thr->currClock);
                                thr->lastClock = thr->currClock;

#if 0
                                if ((ev = AfxPullNextQueueUnit(&thr->events)))
                                {

                                    AfxPopNextQueue(&thr->events);
                                }
#endif

                                if (!AfxSystemIsOperating())
                                    AfxRequestThreadInterruption(thr);

                                if (thr->interruptionRequested)
                                {
                                    thrOpcode = AFX_THR_OPCODE_QUIT;
                                    thr->running = FALSE;
                                }

                                //afxInt exitCode = 0;
                                afxError rslt = 0;

                                if (thr->proc && (rslt = thr->proc(thr, thr->udd, thrOpcode)))
                                {
                                    AfxThrowError();
                                    AfxExitExecution(-1);
                                }

                                if (thrOpcode == AFX_THR_OPCODE_QUIT || !AfxSystemIsOperating())
                                {
                                    AfxQuitExecution();
                                }

                                if (1 < AfxGetSecondsElapsed(&thr->iterCntSwapClock, &thr->currClock))
                                {
                                    thr->iterCntSwapClock = thr->currClock;
                                    thr->lastIterCnt = thr->iterCnt;
                                    thr->iterCnt = 0;
                                }
                                else
                                {
                                    ++thr->iterCnt;
                                }
                            }
                        }

                        procUnit->activeThr = backedUpThr;
                    }
                }
            }
            AfxExitSlockExclusive(&thr->procSlock);
        }
    }
    return err;
}




#if 0
_AFX afxInt _AfxThrExecCb(afxThread thr) // protected method, called by _AfxThrRun()
{
    afxError err = AFX_ERR_NONE;
    AfxAssertObjects(1, &thr, afxFcc_THR);

    // int exec()
    // Enters the event loop and waits until exit() is called, returning the value that was passed to exit(). The value returned is 0 if exit() is called via quit().
    // This function is meant to be called from within run(). It is necessary to call this function to start event handling.
    // Note: This can only be called within the thread itself, i.e. when it is the current thread.

    AfxAssert(thr == AfxGetThread());

    afxEvent *ev;

    do
    {
        AfxYieldThreading();

        if ((ev = AfxPullNextQueueUnit(&thr->events)))
        {
            
            AfxPopNextQueue(&thr->events);
        }

        if (thr->interruptionRequested) break;
        else
        {
            //thr->running = TRUE;

            if (thr->exec)
                thr->exec(thr);
        }
    }
    while (thr->running);

    thr->running = FALSE;
    return thr->exitCode;
}

_AFX void _AfxThrRun(afxThread thr) // protected method
{
    AfxEntry("thr=%p", thr);
    afxError err = AFX_ERR_NONE;
    AfxAssertObjects(1, &thr, afxFcc_THR);

    // void run()
    // The starting point for the thread. After calling start(), the newly created thread calls this function. The default implementation simply calls exec().
    // You can reimplement this function to facilitate advanced thread management. Returning from this method will end the execution of the thread.

    if (!thr->running)
    {
        thr->running = TRUE;

        //afxEvent ev;
        //AfxEventDeploy(&ev, AFX_EVENT_THR_START, &thr->obj, NIL);
        //AfxObjectEmitEvent(&thr->obj, &ev);

        afxInt exitCode = thr->exec(thr);
        AfxAssert(exitCode == thr->exitCode);

        //thr->running = FALSE;
    }
}
#endif

#if 0
_AFX afxError AfxPostThreadEvent(afxThread thr, afxEvent const *ev)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertObjects(1, &thr, afxFcc_THR);
    AfxAssertType(ev, afxFcc_EVNT);
    
    if (AfxPushQueueUnit(&thr->events, ev))
        AfxThrowError();

    return err;
}
#endif

#if 0
_AFX afxNat32 AfxGetThreadId(afxThread thr)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertObjects(1, &thr, afxFcc_THR);
    return thr->tid;
}
#endif

_AFX void* AfxGetThreadUdd(afxThread thr)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertObjects(1, &thr, afxFcc_THR);
    return thr->udd;
}

_AFX afxBool AfxThreadIsRunning(afxThread thr)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertObjects(1, &thr, afxFcc_THR);
    return thr->running && !thr->isInFinish;
}

_AFX afxBool AfxThreadIsFinished(afxThread thr)
{
    afxError err = AFX_ERR_NONE;
    AfxAssertObjects(1, &thr, afxFcc_THR);
    return thr->finished || thr->isInFinish;
}

_AFX afxBool AfxShouldInterruptExecution(void)
{
    afxError err = AFX_ERR_NONE;

    afxThread thr;
    AfxGetThread(&thr);
    AfxAssertObjects(1, &thr, afxFcc_THR);

    afxBool rslt = FALSE;

    if (!(rslt = !!(thr->interruptionRequested)))
    {
        rslt = (thr->running && (!thr->finished) && (!thr->isInFinish));
    }
    return rslt;
}

_AFX afxNat AfxSuspendThread(afxThread thr)
{
    /*
        If the function succeeds, execution of the specified thread is suspended and the thread's suspend count is incremented. 
        Suspending a thread causes the thread to stop executing user-mode (application) code.

        This function is primarily designed for use by debuggers. 
        It is not intended to be used for thread synchronization. 
        Calling SuspendThread on a thread that owns a synchronization object, such as a mutex or critical section, 
        can lead to a deadlock if the calling thread tries to obtain a synchronization object owned by a suspended thread. 
        To avoid this situation, a thread within an application that is not a debugger should signal the other thread to suspend itself. 
        The target thread must be designed to watch for this signal and respond appropriately.

        Each thread has a suspend count (with a maximum value of MAXIMUM_SUSPEND_COUNT). 
        If the suspend count is greater than zero, the thread is suspended; otherwise, the thread is not suspended and is eligible for execution. 
        Calling SuspendThread causes the target thread's suspend count to be incremented. 
        Attempting to increment past the maximum suspend count causes an error without incrementing the count.

        The ResumeThread function decrements the suspend count of a suspended thread.
    */
    afxError err = AFX_ERR_NONE;
    AfxAssertObjects(1, &thr, afxFcc_THR);

    afxNat cnt = thr->suspendCnt;

    ++thr->suspendCnt;

    return cnt;
}

_AFX afxNat AfxResumeThread(afxThread thr)
{
    /*
        The ResumeThread function checks the suspend count of the subject thread. 
        If the suspend count is zero, the thread is not currently suspended. 
        Otherwise, the subject thread's suspend count is decremented. 
        If the resulting value is zero, then the execution of the subject thread is resumed.

        If the return value is zero, the specified thread was not suspended. 
        If the return value is 1, the specified thread was suspended but was restarted. 
        If the return value is greater than 1, the specified thread is still suspended.
    */
    afxError err = AFX_ERR_NONE;
    AfxAssertObjects(1, &thr, afxFcc_THR);

    afxNat cnt = thr->suspendCnt;

    if (cnt)
        --thr->suspendCnt;

    return cnt;
}

#if 0
_AFX int __stdcall startCbOnThread(afxThread thr)
{
    thr->tid = GetCurrentThreadId();
    thr->osHandle = (afxSize)GetCurrentThread();

    _AfxThrRun(thr);

    return thr->exitCode;
}
#endif

_AFX void AfxSetThreadAffinity(afxThread thr, afxNat procUnitIdx)
{
    AfxEntry("thr=%p", thr);
    afxError err = AFX_ERR_NONE;
    AfxAssertObjects(1, &thr, afxFcc_THR);

    afxNat cap = AfxGetThreadingCapacity();
    AfxAssert(cap > procUnitIdx);
    thr->affineProcUnitIdx = procUnitIdx;
}

_AFX void AfxRunThread(afxThread thr)
{
    AfxEntry("thr=%p", thr);
    afxError err = AFX_ERR_NONE;
    AfxAssertObjects(1, &thr, afxFcc_THR);

    // Begins execution of the thread by calling run(). The operating system will schedule the thread according to the priority parameter. If the thread is already running, this function does nothing.
    // The effect of the priority parameter is dependent on the operating system's scheduling policy. In particular, the priority will be ignored on systems that do not support thread priorities (such as on Linux, see the sched_setscheduler documentation for more details).

    if (!thr->running)
    {
        //thr->started = TRUE;

        AfxGetClock(&thr->startClock);
        thr->lastClock = thr->startClock;
        thr->iterCntSwapClock = thr->lastClock;
        thr->iterCnt = 0;
        
        thr->running = TRUE;
        thr->finished = FALSE;
        thr->exited = FALSE;
        thr->exitCode = 0;
        thr->interruptionRequested = FALSE;

        AfxExecuteThread(thr); // opportunistic attempt to run immediately, if not blocked by affinity or other factor.
    }
}

_AFX afxNat AfxEnumerateThreads(afxNat first, afxNat cnt, afxThread thr[])
{
    afxError err = AFX_ERR_NONE;
    AfxAssert(thr);
    AfxAssert(cnt);
    afxSystem sys;
    AfxGetSystem(&sys);
    AfxAssertObjects(1, &sys, afxFcc_SYS);
    AfxAssertClass(&sys->threads, afxFcc_THR);
    return AfxEnumerateInstances(&sys->threads, first, cnt, (afxHandle*)thr);
}

_AFX afxNat AfxCurateThreads(afxNat first, afxNat cnt, afxBool(*f)(afxThread, void*), void *udd)
{
    afxError err = AFX_ERR_NONE;
    AfxAssert(f);
    AfxAssert(cnt);
    afxSystem sys;
    AfxGetSystem(&sys);
    AfxAssertObjects(1, &sys, afxFcc_SYS);
    AfxAssertClass(&sys->threads, afxFcc_THR);
    return AfxCurateInstances(&sys->threads, first, cnt, (void*)f, udd);
}

_AFX afxError _AfxThrDtor(afxThread thr)
{
    AfxEntry("thr=%p", thr);
    afxError err = AFX_ERR_NONE;

    AfxAssertObjects(1, &thr, afxFcc_THR);

    // Destroys the QThread.
    // Note that deleting a QThread object will not stop the execution of the thread it manages.Deleting a running QThread(i.e.isFinished() returns false) will result in a program crash.Wait for the finished() signal before deleting the QThread.
    // Since Qt 6.3, it is allowed to delete a QThread instance created by a call to QThread::create() even if the corresponding thread is still running.In such a case, Qt will post an interruption request to that thread(via requestInterruption()); will ask the thread's event loop (if any) to quit (via quit()); and will block until the thread has finished.

    while (thr->running)
    {
        AfxRequestThreadInterruption(thr);
        AfxDoSystemThreading(0);
        //AfxYieldThreading();
        //afxResult exitCode = 0;
        //AfxWaitForThread(thr, &exitCode);
    }

#if 0
    AfxAssert(AfxQueueIsEmpty(&thr->events));

    if (AfxReleaseQueue(&thr->events))
        AfxThrowError();
#endif

    return err;
}

_AFX afxError _AfxThrCtor(afxThread thr, afxCookie const *cookie)
{
    afxError err = AFX_ERR_NONE;
    AfxEntry("%p", thr);
    AfxAssertObjects(1, &thr, afxFcc_THR);

    afxThreadConfig const *config = cookie->udd[0] ? ((afxThreadConfig const *)cookie->udd[0]) + cookie->no : NIL;
    
    if (AfxAcquireSlock(&thr->procSlock)) AfxThrowError();
    else
    {
        //thr->affineProcUnitIdx = spec ? spec->affineProcUnitIdx : AFX_INVALID_INDEX; // if not equal to AFX_INVALID_INDEX, this thread can be ran by any system processor unit, else case, will only be ran by the unit specified by this index.
        thr->startClock = (afxClock) { 0 };
        thr->currClock = (afxClock) { 0 };
        thr->lastClock = (afxClock) { 0 };
        thr->iterCntSwapClock = (afxClock) { 0 };
        thr->iterCnt = 0;
        thr->currTime = 0;
        thr->deltaTime = 0;
        thr->proc = config ? config->proc : NIL;
        thr->started = FALSE;
        thr->running = FALSE;
        thr->finished = FALSE;
        thr->exited = FALSE;
        thr->isInFinish = FALSE;
        thr->interruptionRequested = FALSE;
        thr->exitCode = 0;
        thr->udd = config ? config->udd : NIL;

        thr->suspendCnt = 0;
        thr->affineProcUnitIdx = AFX_INVALID_INDEX;


        //AfxSetThreadAffinity(thr, spec ? spec->affinityMask : NIL);

        // The new thread is not started -- it must be started by an explicit call to start().
        // This allows you to connect to its signals, move QObjects to the thread, choose the new thread's priority and so on.
        // The function f will be called in the new thread.

#if 0
        if (AfxAcquireQueue(&thr->events, sizeof(afxEvent), 32)) AfxThrowError();
        else
        {

        }

        if (err)
            AfxReleaseQueue(&thr->events);
#endif
        if (err)
            AfxReleaseSlock(&thr->procSlock);
    }
    return err;
}

_AFX afxError AfxAcquireThreads(afxNat cnt, afxThread thr[], afxThreadConfig const config[], afxHint const hint)
{
    AfxEntry("cnt=%u,thr=%p,config=%p,hint=\"%s:%i!%s\"", cnt, thr, config, AfxFindPathTarget((char const *const)hint[0]), (int)hint[1], (char const *const)hint[2]);
    afxError err = AFX_ERR_NONE;
    
    // Creates a new QThread object that will execute the function f with the arguments args.
    // The new thread is not started -- it must be started by an explicit call to start(). This allows you to connect to its signals, move QObjects to the thread, choose the new thread's priority and so on. The function f will be called in the new thread.
    
    afxSystem sys;
    AfxGetSystem(&sys);
    AfxAssertObjects(1, &sys, afxFcc_SYS);
    AfxAssertClass(&sys->threads, afxFcc_THR);

    if (AfxAcquireObjects(&sys->threads, cnt, (afxHandle*)thr, (void*[]) { (void*)config }))
        AfxThrowError();

    return err;
}

_AFX afxClassConfig _AfxThrClsConfig =
{
    .fcc = afxFcc_THR,
    .name = "Thread",
    .unitsPerPage = 1,
    .size = sizeof(AFX_OBJECT(afxThread)),
    .ctx = NIL,
    .ctor = (void*)_AfxThrCtor,
    .dtor = (void*)_AfxThrDtor
};
