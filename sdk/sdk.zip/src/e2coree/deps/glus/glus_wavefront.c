/*
 * GLUS - Modern OpenGL, OpenGL ES and OpenVG Utilities. Copyright (C) since 2010 Norbert Nopper
 *
 * This program is free software: you canv redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#define _CRT_SECURE_NO_WARNINGS 1

#include "GL/glus.h"
#include "afx/core/afxUri.h"

#define _ldrFileOpen fopen
#define _ldrFileClose fclose

#define GLUS_MAX_OBJECTS 1
#define GLUS_MAX_ATTRIBUTES (/*GLUS_MAX_VERTICES*/10485770/GLUS_VERTICES_DIVISOR)
#define GLUS_MAX_TRIANGLE_ATTRIBUTES 10485770//GLUS_MAX_VERTICES
#define GLUS_MAX_LINE_ATTRIBUTES 10485770//GLUS_MAX_VERTICES
#define GLUS_BUFFERSIZE 1024

#define _ldrMemoryMalloc(x_) malloc(x_)
#define _ldrMemoryFree(x_) free(x_)

static GLUSboolean _ldrWavefrontMallocTempMemoryLine(GLUSfloat** vertices, GLUSindex** indices)
{
    afxError err = AFX_ERR_NONE;
    if (!vertices || !indices)
    {
        AfxThrowError();
        return GLUS_FALSE;
    }

    *vertices = (GLUSfloat*)_ldrMemoryMalloc(4 * GLUS_MAX_ATTRIBUTES * sizeof(GLUSfloat));
    if (!*vertices)
    {
        AfxThrowError();
        return GLUS_FALSE;
    }

    *indices = (GLUSindex*)_ldrMemoryMalloc(GLUS_MAX_LINE_ATTRIBUTES * sizeof(GLUSindex));
    if (!*indices)
    {
        AfxThrowError();
        return GLUS_FALSE;
    }

    return GLUS_TRUE;
}

static GLUSvoid _ldrWavefrontFreeTempMemoryLine(GLUSfloat** vertices, GLUSindex** indices)
{
    if (vertices && *vertices)
    {
        _ldrMemoryFree(*vertices);

        *vertices = 0;
    }

    if (indices && *indices)
    {
        _ldrMemoryFree(*indices);

        *indices = 0;
    }
}

static GLUSboolean _ldrWavefrontMallocTempMemory(GLUSfloat** vertices, GLUSfloat** normals, GLUSfloat** texCoords, GLUSfloat** triangleVertices, GLUSfloat** triangleNormals, GLUSfloat** triangleTexCoords)
{
    afxError err = AFX_ERR_NONE;
    if (!vertices || !normals || !texCoords || !triangleVertices || !triangleNormals || !triangleTexCoords)
    {
        AfxThrowError();
        return GLUS_FALSE;
    }

    *vertices = (GLUSfloat*)_ldrMemoryMalloc(4 * GLUS_MAX_ATTRIBUTES * sizeof(GLUSfloat));
    if (!*vertices)
    {
        AfxThrowError();
        return GLUS_FALSE;
    }

    *normals = (GLUSfloat*)_ldrMemoryMalloc(3 * GLUS_MAX_ATTRIBUTES * sizeof(GLUSfloat));
    if (!*normals)
    {
        AfxThrowError();
        return GLUS_FALSE;
    }

    *texCoords = (GLUSfloat*)_ldrMemoryMalloc(2 * GLUS_MAX_ATTRIBUTES * sizeof(GLUSfloat));
    if (!*texCoords)
    {
        AfxThrowError();
        return GLUS_FALSE;
    }

    *triangleVertices = (GLUSfloat*)_ldrMemoryMalloc(4 * GLUS_MAX_TRIANGLE_ATTRIBUTES * sizeof(GLUSfloat));
    if (!*triangleVertices)
    {
        AfxThrowError();
        return GLUS_FALSE;
    }

    *triangleNormals = (GLUSfloat*)_ldrMemoryMalloc(3 * GLUS_MAX_TRIANGLE_ATTRIBUTES * sizeof(GLUSfloat));
    if (!*triangleNormals)
    {
        AfxThrowError();
        return GLUS_FALSE;
    }

    *triangleTexCoords = (GLUSfloat*)_ldrMemoryMalloc(2 * GLUS_MAX_TRIANGLE_ATTRIBUTES * sizeof(GLUSfloat));
    if (!*triangleTexCoords)
    {
        AfxThrowError();
        return GLUS_FALSE;
    }

    return GLUS_TRUE;
}

static GLUSvoid _ldrWavefrontFreeTempMemory(GLUSfloat** vertices, GLUSfloat** normals, GLUSfloat** texCoords, GLUSfloat** triangleVertices, GLUSfloat** triangleNormals, GLUSfloat** triangleTexCoords)
{
    if (vertices && *vertices)
    {
        _ldrMemoryFree(*vertices);

        *vertices = 0;
    }

    if (normals && *normals)
    {
        _ldrMemoryFree(*normals);

        *normals = 0;
    }

    if (texCoords && *texCoords)
    {
        _ldrMemoryFree(*texCoords);

        *texCoords = 0;
    }

    if (triangleVertices && *triangleVertices)
    {
        _ldrMemoryFree(*triangleVertices);

        *triangleVertices = 0;
    }

    if (triangleNormals && *triangleNormals)
    {
        _ldrMemoryFree(*triangleNormals);

        *triangleNormals = 0;
    }

    if (triangleTexCoords && *triangleTexCoords)
    {
        _ldrMemoryFree(*triangleTexCoords);

        *triangleTexCoords = 0;
    }
}

static GLUSvoid _ldrWavefrontInitMaterial(GLUSmaterial* material)
{
    afxError err = AFX_ERR_NONE;
    if (!material)
    {
        AfxThrowError();
        return;
    }

    material->name[0] = 0;

    material->emissive[0] = 0.0f;
    material->emissive[1] = 0.0f;
    material->emissive[2] = 0.0f;
    material->emissive[3] = 1.0f;

    material->ambient[0] = 0.0f;
    material->ambient[1] = 0.0f;
    material->ambient[2] = 0.0f;
    material->ambient[3] = 1.0f;

    material->diffuse[0] = 0.0f;
    material->diffuse[1] = 0.0f;
    material->diffuse[2] = 0.0f;
    material->diffuse[3] = 1.0f;

    material->specular[0] = 0.0f;
    material->specular[1] = 0.0f;
    material->specular[2] = 0.0f;
    material->specular[3] = 1.0f;

    material->shininess = 0.0f;

    material->transparency = 1.0f;

    material->reflection = GLUS_FALSE;

    material->refraction = GLUS_FALSE;

    material->indexOfRefraction = 1.0f;

    material->emissiveTextureFilename[0] = 0;

    material->ambientTextureFilename[0] = 0;

    material->diffuseTextureFilename[0] = 0;

    material->specularTextureFilename[0] = 0;

    material->transparencyTextureFilename[0] = 0;

    material->bumpTextureFilename[0] = 0;

    material->emissiveTextureName = 0;

    material->ambientTextureName = 0;

    material->diffuseTextureName = 0;

    material->specularTextureName = 0;

    material->transparencyTextureName = 0;

    material->bumpTextureName = 0;
}

static GLUSvoid _ldrWavefrontDestroyMaterial(GLUSmaterialList** materialList)
{
    afxError err = AFX_ERR_NONE;
    GLUSmaterialList* currentMaterialList = 0;
    GLUSmaterialList* nextMaterialList = 0;

    if (!materialList || !*materialList)
    {
        AfxThrowError();
        return;
    }

    currentMaterialList = *materialList;
    while (currentMaterialList != 0)
    {
        nextMaterialList = currentMaterialList->next;

        memset(&currentMaterialList->material, 0, sizeof(GLUSmaterial));

        _ldrMemoryFree(currentMaterialList);

        currentMaterialList = nextMaterialList;
    }

    *materialList = 0;
}

static GLUSboolean _ldrWavefrontLoadMaterial(const afxUri* filename, const afxUri* materialName, GLUSmaterialList** materialList)
{
    (void)filename;
    afxError err = AFX_ERR_NONE;
    FILE* f;

    GLUSint i, k;

    GLUSchar buffer[GLUS_BUFFERSIZE];
    GLUSchar* checkBuffer;
    GLUSchar name[GLUS_MAX_STRING];
    GLUSchar identifier[512];

    GLUSmaterialList* currentMaterialList = 0;

    if (!materialName || !materialList)
    {
        AfxThrowError();
        return GLUS_FALSE;
    }

    AfxAdvertise("MTL FNAME %.*s", AfxPushString(AfxUriGetStringConst(materialName)));

    afxUri2048 uri2;
    AfxUri2048(&uri2);

    AfxResolveUri(materialName, AFX_FILE_FLAG_R, &uri2.uri);

    f = _ldrFileOpen(AfxGetStringDataConst(AfxUriGetString(&uri2.uri), 0), "r");

    if (!f)
    {
        AfxThrowError();
        return GLUS_FALSE;
    }

    while (!feof(f))
    {
        buffer[0] = 0;

        if (fgets(buffer, GLUS_BUFFERSIZE, f) == 0)
        {
            if (ferror(f))
            {
                AfxThrowError();
                _ldrFileClose(f);

                return GLUS_FALSE;
            }
        }

        checkBuffer = buffer;

        k = 0;

        // Skip first spaces etc.
        while (*checkBuffer)
        {
            if (*checkBuffer != ' ' && *checkBuffer != '\t')
            {
                break;
            }

            checkBuffer++;
            k++;

            if (k >= GLUS_BUFFERSIZE)
            {
                AfxThrowError();
                _ldrFileClose(f);

                return GLUS_FALSE;
            }
        }

        i = 0;

        while (checkBuffer[i])
        {
            if (checkBuffer[i] == ' ' || checkBuffer[i] == '\t')
            {
                break;
            }

            checkBuffer[i] = (GLUSchar)tolower(checkBuffer[i]);

            i++;

            if (i >= GLUS_BUFFERSIZE - k)
            {
                AfxThrowError();
                _ldrFileClose(f);

                return GLUS_FALSE;
            }
        }

        if (strncmp(checkBuffer, "newmtl", 6) == 0)
        {
            GLUSmaterialList* newMaterialList = 0;

            sscanf(checkBuffer, "%s %s", identifier, name);

            newMaterialList = (GLUSmaterialList*)_ldrMemoryMalloc(sizeof(GLUSmaterialList));

            if (!newMaterialList)
            {
                AfxThrowError();
                _ldrWavefrontDestroyMaterial(materialList);

                _ldrFileClose(f);

                return GLUS_FALSE;
            }

            memset(newMaterialList, 0, sizeof(GLUSmaterialList));

            _ldrWavefrontInitMaterial(&newMaterialList->material);

            strcpy(newMaterialList->material.name, name);

            if (*materialList == 0)
            {
                *materialList = newMaterialList;
            }
            else
            {
                currentMaterialList->next = newMaterialList;
            }

            currentMaterialList = newMaterialList;
        }
        else if (strncmp(checkBuffer, "ke", 2) == 0)
        {
            sscanf(checkBuffer, "%s %f %f %f", identifier, &currentMaterialList->material.emissive[0], &currentMaterialList->material.emissive[1], &currentMaterialList->material.emissive[2]);

            currentMaterialList->material.emissive[3] = 1.0f;
        }
        else if (strncmp(checkBuffer, "ka", 2) == 0)
        {
            sscanf(checkBuffer, "%s %f %f %f", identifier, &currentMaterialList->material.ambient[0], &currentMaterialList->material.ambient[1], &currentMaterialList->material.ambient[2]);

            currentMaterialList->material.ambient[3] = 1.0f;
        }
        else if (strncmp(checkBuffer, "kd", 2) == 0)
        {
            sscanf(checkBuffer, "%s %f %f %f", identifier, &currentMaterialList->material.diffuse[0], &currentMaterialList->material.diffuse[1], &currentMaterialList->material.diffuse[2]);

            currentMaterialList->material.diffuse[3] = 1.0f;
        }
        else if (strncmp(checkBuffer, "ks", 2) == 0)
        {
            sscanf(checkBuffer, "%s %f %f %f", identifier, &currentMaterialList->material.specular[0], &currentMaterialList->material.specular[1], &currentMaterialList->material.specular[2]);

            currentMaterialList->material.specular[3] = 1.0f;
        }
        else if (strncmp(checkBuffer, "ns", 2) == 0)
        {
            sscanf(checkBuffer, "%s %f", identifier, &currentMaterialList->material.shininess);
        }
        else if (strncmp(checkBuffer, "d", 1) == 0 || strncmp(checkBuffer, "Tr", 2) == 0)
        {
            sscanf(checkBuffer, "%s %f", identifier, &currentMaterialList->material.transparency);
        }
        else if (strncmp(checkBuffer, "ni", 2) == 0)
        {
            sscanf(checkBuffer, "%s %f", identifier, &currentMaterialList->material.indexOfRefraction);
        }
        else if (strncmp(checkBuffer, "map_ke", 6) == 0)
        {
            sscanf(checkBuffer, "%s %s", identifier, name);

            strcpy(currentMaterialList->material.emissiveTextureFilename, name);
        }
        else if (strncmp(checkBuffer, "map_ka", 6) == 0)
        {
            sscanf(checkBuffer, "%s %s", identifier, name);

            strcpy(currentMaterialList->material.ambientTextureFilename, name);
        }
        else if (strncmp(checkBuffer, "map_kd", 6) == 0)
        {
            sscanf(checkBuffer, "%s %s", identifier, name);

            strcpy(currentMaterialList->material.diffuseTextureFilename, name);
        }
        else if (strncmp(checkBuffer, "map_ks", 6) == 0)
        {
            sscanf(checkBuffer, "%s %s", identifier, name);

            strcpy(currentMaterialList->material.specularTextureFilename, name);
        }
        else if (strncmp(checkBuffer, "map_d", 5) == 0 || strncmp(checkBuffer, "map_Tr", 6) == 0)
        {
            sscanf(checkBuffer, "%s %s", identifier, name);

            strcpy(currentMaterialList->material.transparencyTextureFilename, name);
        }
        else if (strncmp(checkBuffer, "map_bump", 8) == 0 || strncmp(checkBuffer, "bump", 4) == 0)
        {
            sscanf(checkBuffer, "%s %s", identifier, name);

            strcpy(currentMaterialList->material.bumpTextureFilename, name);
        }
        else if (strncmp(checkBuffer, "illum", 5) == 0)
        {
            GLUSint illum;

            sscanf(checkBuffer, "%s %d", identifier, &illum);

            // Only setting reflection and refraction depending on illumination model.
            switch (illum)
            {
                case 3:
                case 4:
                case 5:
                case 8:
                case 9:
                    currentMaterialList->material.reflection = GLUS_TRUE;
                    break;
                case 6:
                case 7:
                    currentMaterialList->material.reflection = GLUS_TRUE;
                    currentMaterialList->material.refraction = GLUS_TRUE;
                    break;
            }
        }
    }

    _ldrFileClose(f);

    return GLUS_TRUE;
}

static GLUSvoid _ldrWavefrontDestroyGroup(GLUSgroupList** groupList)
{
    afxError err = AFX_ERR_NONE;
    GLUSgroupList* currentGroupList = 0;
    GLUSgroupList* nextGroupList = 0;

    if (!groupList || !*groupList)
    {
        AfxThrowError();
        return;
    }

    currentGroupList = *groupList;
    while (currentGroupList != 0)
    {
        nextGroupList = currentGroupList->next;

        if (currentGroupList->group.indices)
        {
            _ldrMemoryFree(currentGroupList->group.indices);
        }
        memset(&currentGroupList->group, 0, sizeof(GLUSgroup));

        _ldrMemoryFree(currentGroupList);

        currentGroupList = nextGroupList;
    }

    *groupList = 0;
}

static GLUSboolean _ldrWavefrontCopyDataLine(GLUSline* line, GLUSuint totalNumberVertices, GLUSfloat* lineVertices, GLUSuint totalNumberIndices, GLUSindex* lineIndices)
{
    afxError err = AFX_ERR_NONE;
    if (!line || !lineVertices || !lineIndices)
    {
        AfxThrowError();
        return GLUS_FALSE;
    }

    memset(line, 0, sizeof(GLUSline));

    line->numberVertices = totalNumberVertices;
    line->numberIndices = totalNumberIndices;

    if (totalNumberVertices > 0)
    {
        line->vertices = (GLUSfloat*)_ldrMemoryMalloc(totalNumberVertices * 4 * sizeof(GLUSfloat));

        if (line->vertices == 0)
        {
            AfxThrowError();
            _ldrLineDestroyf(line);

            return GLUS_FALSE;
        }

        memcpy(line->vertices, lineVertices, totalNumberVertices * 4 * sizeof(GLUSfloat));
    }
    if (totalNumberIndices > 0)
    {
        line->indices = (GLUSindex*)_ldrMemoryMalloc(totalNumberIndices * sizeof(GLUSindex));

        if (line->indices == 0)
        {
            AfxThrowError();
            _ldrLineDestroyf(line);

            return GLUS_FALSE;
        }

        memcpy(line->indices, lineIndices, totalNumberIndices * sizeof(GLUSindex));
    }

    line->mode = GLUS_LINES;

    return GLUS_TRUE;
}

static GLUSboolean _ldrWavefrontCopyData(GLUSshape* shape, GLUSuint totalNumberVertices, GLUSfloat* triangleVertices, GLUSuint totalNumberNormals, GLUSfloat* triangleNormals, GLUSuint totalNumberTexCoords, GLUSfloat* triangleTexCoords)
{
    afxError err = AFX_ERR_NONE;
    GLUSuint indicesCounter = 0;

    if (!shape || !triangleVertices || !triangleNormals || !triangleTexCoords)
    {
        AfxThrowError();
        return GLUS_FALSE;
    }

    memset(shape, 0, sizeof(GLUSshape));

    shape->numberVertices = totalNumberVertices;

    if (totalNumberVertices > 0)
    {
        shape->vertices = (GLUSfloat*)_ldrMemoryMalloc(totalNumberVertices * 4 * sizeof(GLUSfloat));

        if (shape->vertices == 0)
        {
            AfxThrowError();
            _ldrShapeDestroyf(shape);

            return GLUS_FALSE;
        }

        memcpy(shape->vertices, triangleVertices, totalNumberVertices * 4 * sizeof(GLUSfloat));
    }
    if (totalNumberNormals > 0)
    {
        shape->normals = (GLUSfloat*)_ldrMemoryMalloc(totalNumberNormals * 3 * sizeof(GLUSfloat));

        if (shape->normals == 0)
        {
            AfxThrowError();
            _ldrShapeDestroyf(shape);

            return GLUS_FALSE;
        }

        memcpy(shape->normals, triangleNormals, totalNumberNormals * 3 * sizeof(GLUSfloat));
    }
    if (totalNumberTexCoords > 0)
    {
        shape->texCoords = (GLUSfloat*)_ldrMemoryMalloc(totalNumberTexCoords * 2 * sizeof(GLUSfloat));

        if (shape->texCoords == 0)
        {
            AfxThrowError();
            _ldrShapeDestroyf(shape);

            return GLUS_FALSE;
        }

        memcpy(shape->texCoords, triangleTexCoords, totalNumberTexCoords * 2 * sizeof(GLUSfloat));
    }

    // Just create the indices from the list of vertices.

    shape->numberIndices = totalNumberVertices;

    if (totalNumberVertices > 0)
    {
        shape->indices = (GLUSindex*)_ldrMemoryMalloc(totalNumberVertices * sizeof(GLUSindex));

        if (shape->indices == 0)
        {
            AfxThrowError();
            _ldrShapeDestroyf(shape);

            return GLUS_FALSE;
        }

        for (indicesCounter = 0; indicesCounter < totalNumberVertices; indicesCounter++)
        {
            shape->indices[indicesCounter] = indicesCounter;
        }
    }

    shape->mode = GLUS_TRIANGLES;

    return GLUS_TRUE;
}

GLUSboolean __ldrWavefrontMove(GLUSwavefront* wavefront, GLUSshape* shape)
{
    afxError err = AFX_ERR_NONE;
    GLUSmaterialList* materialWalker;
    GLUSgroupList* groupWalker;

    GLUSuint i;
    GLUSuint counter = 0;

    if (!wavefront || !shape)
    {
        AfxThrowError();
        return GLUS_FALSE;
    }

    // No clear of wavefront by purpose.

    wavefront->vertices = shape->vertices;
    wavefront->normals = shape->normals;
    wavefront->texCoords = shape->texCoords;
    wavefront->tangents = shape->tangents;
    wavefront->bitangents = shape->bitangents;
    wavefront->numberVertices = shape->numberVertices;

    groupWalker = wavefront->groups;
    while (groupWalker)
    {
        groupWalker->group.indices = (GLUSindex*)_ldrMemoryMalloc(groupWalker->group.numberIndices * sizeof(GLUSindex));

        if (!groupWalker->group.indices)
        {
            AfxThrowError();
            memset(wavefront, 0, sizeof(GLUSwavefront));

            return GLUS_FALSE;
        }

        for (i = 0; i < groupWalker->group.numberIndices; i++)
        {
            groupWalker->group.indices[i] = counter++;
        }

        materialWalker = wavefront->materials;

        while (materialWalker)
        {
            if (strcmp(materialWalker->material.name, groupWalker->group.materialName) == 0)
            {
                groupWalker->group.material = &materialWalker->material;

                break;
            }

            materialWalker = materialWalker->next;
        }

        groupWalker = groupWalker->next;
    }

    _ldrMemoryFree(shape->indices);
    shape->indices = 0;

    memset(shape, 0, sizeof(GLUSshape));

    return GLUS_TRUE;
}

GLUSboolean __ldrWavefrontParse(const GLUSchar* filename, GLUSshape* shape, GLUSwavefront* wavefront, GLUSscene* scene, void const* io)
{
    afxError err = AFX_ERR_NONE;
    (void)io;
    GLUSboolean result;

    FILE* f;

    GLUSchar buffer[GLUS_BUFFERSIZE];
    GLUSchar identifier[7];

    GLUSfloat x, y, z;
    GLUSfloat s, t;

    GLUSfloat* vertices = 0;
    GLUSfloat* normals = 0;
    GLUSfloat* texCoords = 0;

    GLUSuint numberVertices = 0;
    GLUSuint numberNormals = 0;
    GLUSuint numberTexCoords = 0;

    GLUSfloat* triangleVertices = 0;
    GLUSfloat* triangleNormals = 0;
    GLUSfloat* triangleTexCoords = 0;

    GLUSuint offsetNumberVertices = 0;
    GLUSuint offsetNumberNormals = 0;
    GLUSuint offsetNumberTexCoords = 0;

    GLUSuint totalNumberVertices = 0;
    GLUSuint totalNumberNormals = 0;
    GLUSuint totalNumberTexCoords = 0;

    GLUSuint facesEncoding = 0;

    // Material and groups

    GLUSchar name[GLUS_MAX_STRING];

    GLUSuint numberIndicesGroup = 0;
    GLUSuint numberMaterials = 0;
    GLUSuint numberGroups = 0;

    GLUSgroupList* currentGroupList = 0;
    GLUSobjectList* currentObjectList = 0;

    // Objects

    GLUSuint numberObjects = 0;

    if (scene)
    {
        memset(scene, 0, sizeof(GLUSscene));
    }

    if (wavefront)
    {
        memset(wavefront, 0, sizeof(GLUSwavefront));
    }

    if (shape)
    {
        memset(shape, 0, sizeof(GLUSshape));
    }

    if (!filename || !shape)
    {
        AfxThrowError();
        return GLUS_FALSE;
    }

    f = _ldrFileOpen(filename, "r");

    if (!f)
    {
        AfxThrowError();
        return GLUS_FALSE;
    }

    if (!_ldrWavefrontMallocTempMemory(&vertices, &normals, &texCoords, &triangleVertices, &triangleNormals, &triangleTexCoords))
    {
        AfxThrowError();
        _ldrWavefrontFreeTempMemory(&vertices, &normals, &texCoords, &triangleVertices, &triangleNormals, &triangleTexCoords);

        _ldrFileClose(f);

        return GLUS_FALSE;
    }

    while (!feof(f))
    {
        buffer[0] = 0;

        if (fgets(buffer, GLUS_BUFFERSIZE, f) == 0)
        {
            if (ferror(f))
            {
                AfxThrowError();
                _ldrWavefrontFreeTempMemory(&vertices, &normals, &texCoords, &triangleVertices, &triangleNormals, &triangleTexCoords);

                _ldrFileClose(f);

                return GLUS_FALSE;
            }
        }

        if (wavefront)
        {
            if (strncmp(buffer, "mtllib", 6) == 0)
            {
                sscanf(buffer, "%s %s", identifier, name);

                if (numberMaterials == 0)
                {
                    wavefront->materials = 0;
                }

                afxUri2048 uri, uri2;;
                AfxUri2048(&uri);
                AfxUri2048(&uri2);
                AfxFormatUri(&uri.uri, filename);
                AfxFormatUri(&uri2.uri, name);
                
                AfxAdvertise("MTL NAME %s", name);

                if (!_ldrWavefrontLoadMaterial(&uri.uri, &uri2.uri, &wavefront->materials))
                {
                    AfxThrowError();
                    _ldrWavefrontFreeTempMemory(&vertices, &normals, &texCoords, &triangleVertices, &triangleNormals, &triangleTexCoords);

                    _ldrFileClose(f);

                    return GLUS_FALSE;
                }

                numberMaterials++;
            }
            else if (strncmp(buffer, "usemtl", 6) == 0)
            {
                if (!currentGroupList || currentGroupList->group.materialName[0] != '\0')
                {
                    GLUSgroupList* newGroupList;

                    newGroupList = (GLUSgroupList*)_ldrMemoryMalloc(sizeof(GLUSgroupList));

                    if (!newGroupList)
                    {
                        AfxThrowError();
                        _ldrWavefrontFreeTempMemory(&vertices, &normals, &texCoords, &triangleVertices, &triangleNormals, &triangleTexCoords);

                        _ldrFileClose(f);

                        return GLUS_FALSE;
                    }

                    memset(newGroupList, 0, sizeof(GLUSgroupList));

                    strcpy(newGroupList->group.name, name);

                    if (numberGroups == 0)
                    {
                        wavefront->groups = newGroupList;
                    }
                    else
                    {
                        if (!currentGroupList)
                        {
                            AfxThrowError();
                            _ldrMemoryFree(newGroupList);

                            _ldrWavefrontFreeTempMemory(&vertices, &normals, &texCoords, &triangleVertices, &triangleNormals, &triangleTexCoords);

                            _ldrFileClose(f);

                            return GLUS_FALSE;
                        }

                        currentGroupList->next = newGroupList;

                        currentGroupList->group.numberIndices = numberIndicesGroup;
                        numberIndicesGroup = 0;
                    }

                    currentGroupList = newGroupList;

                    numberGroups++;
                }

                //

                sscanf(buffer, "%s %s", identifier, name);

                strcpy(currentGroupList->group.materialName, name);
            }
            else if (strncmp(buffer, "g", 1) == 0)
            {
                GLUSgroupList* newGroupList;

                sscanf(buffer, "%s %s", identifier, name);

                newGroupList = (GLUSgroupList*)_ldrMemoryMalloc(sizeof(GLUSgroupList));

                if (!newGroupList)
                {
                    AfxThrowError();
                    _ldrWavefrontFreeTempMemory(&vertices, &normals, &texCoords, &triangleVertices, &triangleNormals, &triangleTexCoords);

                    _ldrFileClose(f);

                    return GLUS_FALSE;
                }

                memset(newGroupList, 0, sizeof(GLUSgroupList));

                strcpy(newGroupList->group.name, name);

                if (numberGroups == 0)
                {
                    wavefront->groups = newGroupList;
                }
                else
                {
                    if (!currentGroupList)
                    {
                        AfxThrowError();
                        _ldrMemoryFree(newGroupList);

                        _ldrWavefrontFreeTempMemory(&vertices, &normals, &texCoords, &triangleVertices, &triangleNormals, &triangleTexCoords);

                        _ldrFileClose(f);

                        return GLUS_FALSE;
                    }

                    currentGroupList->next = newGroupList;

                    currentGroupList->group.numberIndices = numberIndicesGroup;
                    numberIndicesGroup = 0;
                }

                currentGroupList = newGroupList;

                numberGroups++;
            }
        }

        if (strncmp(buffer, "o", 1) == 0)
        {
            if (scene)
            {
                GLUSobjectList* newObjectList;

                if (currentObjectList)
                {
                    if (wavefront && currentGroupList)
                    {
                        currentGroupList->group.numberIndices = numberIndicesGroup;
                        numberIndicesGroup = 0;
                    }

                    result = _ldrWavefrontCopyData(shape, totalNumberVertices - offsetNumberVertices, &triangleVertices[4 * offsetNumberVertices], totalNumberNormals - offsetNumberNormals, &triangleNormals[3 * offsetNumberNormals], totalNumberTexCoords - offsetNumberTexCoords, &triangleTexCoords[2 * offsetNumberTexCoords]);

                    if (result)
                    {
                        _ldrShapeCalculateTangentBitangentf(shape);
                    }

                    if (!__ldrWavefrontMove(wavefront, shape))
                    {
                        AfxThrowError();
                        _ldrWavefrontFreeTempMemory(&vertices, &normals, &texCoords, &triangleVertices, &triangleNormals, &triangleTexCoords);

                        _ldrFileClose(f);

                        return GLUS_FALSE;
                    }

                    memcpy(&currentObjectList->object, wavefront, sizeof(GLUSwavefront));
                }

                sscanf(buffer, "%s %s", identifier, name);

                strcpy(wavefront->name, name);

                // Always create a new object.

                newObjectList = (GLUSobjectList*)_ldrMemoryMalloc(sizeof(GLUSobjectList));
                if (!newObjectList)
                {
                    AfxThrowError();
                    _ldrWavefrontFreeTempMemory(&vertices, &normals, &texCoords, &triangleVertices, &triangleNormals, &triangleTexCoords);

                    _ldrFileClose(f);

                    return GLUS_FALSE;
                }
                newObjectList->next = 0;

                // Link together.
                if (currentObjectList)
                {
                    currentObjectList->next = newObjectList;
                }
                currentObjectList = newObjectList;

                // Set as root, if needed.
                if (scene->objectList == 0)
                {
                    scene->objectList = currentObjectList;
                }

                // Remember offset and reset values.

                offsetNumberVertices = totalNumberVertices;
                offsetNumberNormals = totalNumberNormals;
                offsetNumberTexCoords = totalNumberTexCoords;

                numberGroups = 0;

                currentGroupList = 0;
            }
            else if (wavefront)
            {
                GLUSgroupList* newGroupList;

                sscanf(buffer, "%s %s", identifier, name);

                newGroupList = (GLUSgroupList*)_ldrMemoryMalloc(sizeof(GLUSgroupList));

                if (!newGroupList)
                {
                    AfxThrowError();
                    _ldrWavefrontFreeTempMemory(&vertices, &normals, &texCoords, &triangleVertices, &triangleNormals, &triangleTexCoords);

                    _ldrFileClose(f);

                    return GLUS_FALSE;
                }

                memset(newGroupList, 0, sizeof(GLUSgroupList));

                strcpy(newGroupList->group.name, name);

                if (numberGroups == 0)
                {
                    wavefront->groups = newGroupList;
                }
                else
                {
                    if (!currentGroupList)
                    {
                        AfxThrowError();
                        _ldrMemoryFree(newGroupList);

                        _ldrWavefrontFreeTempMemory(&vertices, &normals, &texCoords, &triangleVertices, &triangleNormals, &triangleTexCoords);

                        _ldrFileClose(f);

                        return GLUS_FALSE;
                    }

                    currentGroupList->next = newGroupList;

                    currentGroupList->group.numberIndices = numberIndicesGroup;
                    numberIndicesGroup = 0;
                }

                currentGroupList = newGroupList;

                numberGroups++;
            }
            else
            {
                if (numberObjects == GLUS_MAX_OBJECTS)
                {
                    AfxThrowError();
                    _ldrWavefrontFreeTempMemory(&vertices, &normals, &texCoords, &triangleVertices, &triangleNormals, &triangleTexCoords);

                    _ldrFileClose(f);

                    return GLUS_FALSE;
                }
            }

            numberObjects++;
        }
        else if (strncmp(buffer, "vt", 2) == 0)
        {
            if (numberTexCoords == GLUS_MAX_ATTRIBUTES)
            {
                AfxThrowError();
                _ldrWavefrontFreeTempMemory(&vertices, &normals, &texCoords, &triangleVertices, &triangleNormals, &triangleTexCoords);

                _ldrFileClose(f);

                return GLUS_FALSE;
            }

            sscanf(buffer, "%s %f %f", identifier, &s, &t);

            texCoords[2 * numberTexCoords + 0] = s;
            texCoords[2 * numberTexCoords + 1] = t;

            numberTexCoords++;
        }
        else if (strncmp(buffer, "vn", 2) == 0)
        {
            if (numberNormals == GLUS_MAX_ATTRIBUTES)
            {
                AfxThrowError();
                _ldrWavefrontFreeTempMemory(&vertices, &normals, &texCoords, &triangleVertices, &triangleNormals, &triangleTexCoords);

                _ldrFileClose(f);

                return GLUS_FALSE;
            }

            sscanf(buffer, "%s %f %f %f", identifier, &x, &y, &z);

            normals[3 * numberNormals + 0] = x;
            normals[3 * numberNormals + 1] = y;
            normals[3 * numberNormals + 2] = z;

            numberNormals++;
        }
        else if (strncmp(buffer, "v", 1) == 0)
        {
            if (numberVertices == GLUS_MAX_ATTRIBUTES)
            {
                AfxThrowError();
                _ldrWavefrontFreeTempMemory(&vertices, &normals, &texCoords, &triangleVertices, &triangleNormals, &triangleTexCoords);

                _ldrFileClose(f);

                return GLUS_FALSE;
            }

            sscanf(buffer, "%s %f %f %f", identifier, &x, &y, &z);

            vertices[4 * numberVertices + 0] = x;
            vertices[4 * numberVertices + 1] = y;
            vertices[4 * numberVertices + 2] = z;
            vertices[4 * numberVertices + 3] = 1.0f;

            numberVertices++;
        }
        else if (strncmp(buffer, "f", 1) == 0)
        {
            GLUSchar* token;

            GLUSint vIndex, vtIndex, vnIndex;

            GLUSuint edgeCount = 0;

            token = strtok(buffer, " \t");
            token = strtok(0, " \n");

            if (!token)
            {
                continue;
            }

            // Check faces
            if (strstr(token, "//") != 0)
            {
                facesEncoding = 2;
            }
            else if (strstr(token, "/") == 0)
            {
                facesEncoding = 0;
            }
            else if (strstr(token, "/") != 0)
            {
                GLUSchar* c = strstr(token, "/");

                c++;

                if (!c)
                {
                    continue;
                }

                if (strstr(c, "/") == 0)
                {
                    facesEncoding = 1;
                }
                else
                {
                    facesEncoding = 3;
                }
            }

            while (token != 0)
            {
                vIndex = -1;
                vtIndex = -1;
                vnIndex = -1;

                switch (facesEncoding)
                {
                    case 0:
                        sscanf(token, "%d", &vIndex);
                    break;
                    case 1:
                        sscanf(token, "%d/%d", &vIndex, &vtIndex);
                    break;
                    case 2:
                        sscanf(token, "%d//%d", &vIndex, &vnIndex);
                    break;
                    case 3:
                        sscanf(token, "%d/%d/%d", &vIndex, &vtIndex, &vnIndex);
                    break;
                }

                vIndex--;
                vtIndex--;
                vnIndex--;

                if (vIndex >= 0)
                {
                    if (edgeCount < 3)
                    {
                        if (totalNumberVertices >= GLUS_MAX_TRIANGLE_ATTRIBUTES)
                        {
                            AfxThrowError();
                            _ldrWavefrontFreeTempMemory(&vertices, &normals, &texCoords, &triangleVertices, &triangleNormals, &triangleTexCoords);

                            _ldrFileClose(f);

                            return GLUS_FALSE;
                        }

                        memcpy(&triangleVertices[4 * totalNumberVertices], &vertices[4 * vIndex], 4 * sizeof(GLUSfloat));

                        totalNumberVertices++;
                        numberIndicesGroup++;
                    }
                    else
                    {
                        if (totalNumberVertices >= GLUS_MAX_TRIANGLE_ATTRIBUTES - 2)
                        {
                            AfxThrowError();
                            _ldrWavefrontFreeTempMemory(&vertices, &normals, &texCoords, &triangleVertices, &triangleNormals, &triangleTexCoords);

                            _ldrFileClose(f);

                            return GLUS_FALSE;
                        }

                        memcpy(&triangleVertices[4 * (totalNumberVertices)], &triangleVertices[4 * (totalNumberVertices - edgeCount)], 4 * sizeof(GLUSfloat));
                        memcpy(&triangleVertices[4 * (totalNumberVertices + 1)], &triangleVertices[4 * (totalNumberVertices - 1)], 4 * sizeof(GLUSfloat));
                        memcpy(&triangleVertices[4 * (totalNumberVertices + 2)], &vertices[4 * vIndex], 4 * sizeof(GLUSfloat));

                        totalNumberVertices += 3;
                        numberIndicesGroup +=3;
                    }
                }
                if (vnIndex >= 0)
                {
                    if (edgeCount < 3)
                    {
                        if (totalNumberNormals >= GLUS_MAX_TRIANGLE_ATTRIBUTES)
                        {
                            AfxThrowError();
                            _ldrWavefrontFreeTempMemory(&vertices, &normals, &texCoords, &triangleVertices, &triangleNormals, &triangleTexCoords);

                            _ldrFileClose(f);

                            return GLUS_FALSE;
                        }

                        memcpy(&triangleNormals[3 * totalNumberNormals], &normals[3 * vnIndex], 3 * sizeof(GLUSfloat));

                        totalNumberNormals++;
                    }
                    else
                    {
                        if (totalNumberNormals >= GLUS_MAX_TRIANGLE_ATTRIBUTES - 2)
                        {
                            AfxThrowError();
                            _ldrWavefrontFreeTempMemory(&vertices, &normals, &texCoords, &triangleVertices, &triangleNormals, &triangleTexCoords);

                            _ldrFileClose(f);

                            return GLUS_FALSE;
                        }

                        memcpy(&triangleNormals[3 * (totalNumberNormals)], &triangleNormals[3 * (totalNumberNormals - edgeCount)], 3 * sizeof(GLUSfloat));
                        memcpy(&triangleNormals[3 * (totalNumberNormals + 1)], &triangleNormals[3 * (totalNumberNormals - 1)], 3 * sizeof(GLUSfloat));
                        memcpy(&triangleNormals[3 * (totalNumberNormals + 2)], &normals[3 * vnIndex], 3 * sizeof(GLUSfloat));

                        totalNumberNormals += 3;
                    }
                }
                if (vtIndex >= 0)
                {
                    if (edgeCount < 3)
                    {
                        if (totalNumberTexCoords >= GLUS_MAX_TRIANGLE_ATTRIBUTES)
                        {
                            AfxThrowError();
                            _ldrWavefrontFreeTempMemory(&vertices, &normals, &texCoords, &triangleVertices, &triangleNormals, &triangleTexCoords);

                            _ldrFileClose(f);

                            return GLUS_FALSE;
                        }

                        memcpy(&triangleTexCoords[2 * totalNumberTexCoords], &texCoords[2 * vtIndex], 2 * sizeof(GLUSfloat));

                        totalNumberTexCoords++;
                    }
                    else
                    {
                        if (totalNumberTexCoords >= GLUS_MAX_TRIANGLE_ATTRIBUTES - 2)
                        {
                            AfxThrowError();
                            _ldrWavefrontFreeTempMemory(&vertices, &normals, &texCoords, &triangleVertices, &triangleNormals, &triangleTexCoords);

                            _ldrFileClose(f);

                            return GLUS_FALSE;
                        }

                        memcpy(&triangleTexCoords[2 * (totalNumberTexCoords)], &triangleTexCoords[2 * (totalNumberTexCoords - edgeCount)], 2 * sizeof(GLUSfloat));
                        memcpy(&triangleTexCoords[2 * (totalNumberTexCoords + 1)], &triangleTexCoords[2 * (totalNumberTexCoords - 1)], 2 * sizeof(GLUSfloat));
                        memcpy(&triangleTexCoords[2 * (totalNumberTexCoords + 2)], &texCoords[2 * vtIndex], 2 * sizeof(GLUSfloat));

                        totalNumberTexCoords += 3;
                    }
                }

                edgeCount++;

                token = strtok(0, " \n");
            }
        }
    }

    _ldrFileClose(f);

    if (wavefront && currentGroupList)
    {
        currentGroupList->group.numberIndices = numberIndicesGroup;
        numberIndicesGroup = 0;
    }

    result = _ldrWavefrontCopyData(shape, totalNumberVertices - offsetNumberVertices, &triangleVertices[4 * offsetNumberVertices], totalNumberNormals - offsetNumberNormals, &triangleNormals[3 * offsetNumberNormals], totalNumberTexCoords - offsetNumberTexCoords, &triangleTexCoords[2 * offsetNumberTexCoords]);

    _ldrWavefrontFreeTempMemory(&vertices, &normals, &texCoords, &triangleVertices, &triangleNormals, &triangleTexCoords);

    if (result)
    {
        _ldrShapeCalculateTangentBitangentf(shape);
    }

    if (scene)
    {
        if (!__ldrWavefrontMove(wavefront, shape))
        {
            AfxThrowError();
            if (result)
            {
                _ldrShapeDestroyf(shape);
            }

            return GLUS_FALSE;
        }

        if (!scene->objectList)
        {
            scene->objectList = (GLUSobjectList*)_ldrMemoryMalloc(sizeof(GLUSobjectList));
            if (!scene->objectList)
            {
                AfxThrowError();
                _ldrWavefrontDestroy(wavefront);

                return GLUS_FALSE;
            }
            scene->objectList->next = 0;

            currentObjectList = scene->objectList;
        }

        memcpy(&currentObjectList->object, wavefront, sizeof(GLUSwavefront));
    }

    return result;
}

GLUSboolean __ldrWavefrontParseLine(const GLUSchar* filename, GLUSline* line)
{
    afxError err = AFX_ERR_NONE;
    GLUSboolean result;

    FILE* f;

    GLUSchar buffer[GLUS_BUFFERSIZE];
    GLUSchar identifier[7];

    GLUSfloat x, y, z;

    GLUSint start, end;

    GLUSfloat* vertices = 0;

    GLUSindex* indices = 0;

    GLUSuint numberVertices = 0;

    GLUSuint numberIndices = 0;

    // Objects

    GLUSuint numberObjects = 0;

    if (line)
    {
        memset(line, 0, sizeof(GLUSline));
    }

    if (!filename || !line)
    {
        AfxThrowError();
        return GLUS_FALSE;
    }

    f = _ldrFileOpen(filename, "r");

    if (!f)
    {
        AfxThrowError();
        return GLUS_FALSE;
    }

    if (!_ldrWavefrontMallocTempMemoryLine(&vertices, &indices))
    {
        AfxThrowError();
        _ldrWavefrontFreeTempMemoryLine(&vertices, &indices);
        _ldrFileClose(f);
        return GLUS_FALSE;
    }

    while (!feof(f))
    {
        buffer[0] = 0;

        if (fgets(buffer, GLUS_BUFFERSIZE, f) == 0)
        {
            if (ferror(f))
            {
                AfxThrowError();
                _ldrWavefrontFreeTempMemoryLine(&vertices, &indices);
                _ldrFileClose(f);
                return GLUS_FALSE;
            }
        }

        if (strncmp(buffer, "o", 1) == 0)
        {
            if (numberObjects == GLUS_MAX_OBJECTS)
            {
                AfxThrowError();
                _ldrWavefrontFreeTempMemoryLine(&vertices, &indices);
                _ldrFileClose(f);
                return GLUS_FALSE;
            }

            numberObjects++;
        }
        else if (strncmp(buffer, "v", 1) == 0)
        {
            if (numberVertices == GLUS_MAX_ATTRIBUTES)
            {
                AfxThrowError();
                _ldrWavefrontFreeTempMemoryLine(&vertices, &indices);
                _ldrFileClose(f);
                return GLUS_FALSE;
            }

            sscanf(buffer, "%s %f %f %f", identifier, &x, &y, &z);

            vertices[4 * numberVertices + 0] = x;
            vertices[4 * numberVertices + 1] = y;
            vertices[4 * numberVertices + 2] = z;
            vertices[4 * numberVertices + 3] = 1.0f;

            numberVertices++;
        }
        else if (strncmp(buffer, "l", 1) == 0)
        {
            if (numberIndices == GLUS_MAX_LINE_ATTRIBUTES)
            {
                AfxThrowError();
                _ldrWavefrontFreeTempMemoryLine(&vertices, &indices);
                _ldrFileClose(f);
                return GLUS_FALSE;
            }

            sscanf(buffer, "%s %d %d", identifier, &start, &end);

            if (start > 0)
            {
                start--;
            }
            else if (start < 0)
            {
                start += numberVertices;
            }
            else
            {
                AfxThrowError();
                _ldrWavefrontFreeTempMemoryLine(&vertices, &indices);
                _ldrFileClose(f);
                return GLUS_FALSE;
            }

            if (end > 0)
            {
                end--;
            }
            else if (end < 0)
            {
                end += numberVertices;
            }
            else
            {
                AfxThrowError();
                _ldrWavefrontFreeTempMemoryLine(&vertices, &indices);
                _ldrFileClose(f);
                return GLUS_FALSE;
            }

            indices[numberIndices + 0] = (GLUSindex)start;
            indices[numberIndices + 1] = (GLUSindex)end;

            numberIndices += 2;;
        }
    }

    _ldrFileClose(f);

    result = _ldrWavefrontCopyDataLine(line, numberVertices, vertices, numberIndices, indices);

    _ldrWavefrontFreeTempMemoryLine(&vertices, &indices);

    return result;
}

//

GLUSboolean GLUSAPIENTRY _ldrWavefrontLoad(const GLUSchar* filename, GLUSwavefront* wavefront, void const* io)
{
    afxError err = AFX_ERR_NONE;
    GLUSshape dummyShape;

    if (!__ldrWavefrontParse(filename, &dummyShape, wavefront, 0, io))
    {
        AfxThrowError();
        _ldrWavefrontDestroy(wavefront);
        return GLUS_FALSE;
    }

    if (!__ldrWavefrontMove(wavefront, &dummyShape))
    {
        AfxThrowError();
        _ldrWavefrontDestroy(wavefront);
        return GLUS_FALSE;
    }

    return GLUS_TRUE;
}

GLUSvoid GLUSAPIENTRY _ldrWavefrontDestroy(GLUSwavefront* wavefront)
{
    if (!wavefront)
    {
        return;
    }

    _ldrWavefrontDestroyMaterial(&wavefront->materials);
    _ldrWavefrontDestroyGroup(&wavefront->groups);

    if (wavefront->vertices)
    {
        _ldrMemoryFree(wavefront->vertices);

        wavefront->vertices = 0;
    }

    if (wavefront->normals)
    {
        _ldrMemoryFree(wavefront->normals);

        wavefront->normals = 0;
    }

    if (wavefront->texCoords)
    {
        _ldrMemoryFree(wavefront->texCoords);

        wavefront->texCoords = 0;
    }

    if (wavefront->tangents)
    {
        _ldrMemoryFree(wavefront->tangents);

        wavefront->tangents = 0;
    }

    if (wavefront->bitangents)
    {
        _ldrMemoryFree(wavefront->bitangents);

        wavefront->bitangents = 0;
    }

    memset(wavefront, 0, sizeof(GLUSwavefront));
}

GLUSboolean GLUSAPIENTRY _ldrWavefrontLoadScene(const GLUSchar* filename, GLUSscene* scene, void const* io)
{
    afxError err = AFX_ERR_NONE;
    GLUSshape dummyShape;
    GLUSwavefront dummyWavefront;

    if (!scene)
    {
        AfxThrowError();
        return GLUS_FALSE;
    }

    memset(&dummyShape, 0, sizeof(GLUSshape));
    memset(&dummyWavefront, 0, sizeof(GLUSwavefront));

    memset(scene, 0, sizeof(GLUSscene));

    if (!__ldrWavefrontParse(filename, &dummyShape, &dummyWavefront, scene, io))
    {
        AfxThrowError();
        _ldrWavefrontDestroyScene(scene);
        return GLUS_FALSE;
    }

    return GLUS_TRUE;
}

GLUSvoid GLUSAPIENTRY _ldrWavefrontDestroyScene(GLUSscene* scene)
{
    afxError err = AFX_ERR_NONE;
    GLUSobjectList* walker;
    GLUSobjectList* toDelete;

    if (!scene)
    {
        AfxThrowError();
        return;
    }

    walker = scene->objectList;

    while (walker)
    {
        // Avoid deleting materials several times.
        if (walker != scene->objectList)
        {
            walker->object.materials = 0;
        }

        _ldrWavefrontDestroy(&walker->object);

        toDelete = walker;

        walker = walker->next;

        free(toDelete);
    }

    memset(scene, 0, sizeof(GLUSscene));
}

