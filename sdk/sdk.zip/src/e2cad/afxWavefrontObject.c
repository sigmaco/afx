#define _CRT_SECURE_NO_WARNINGS 1
#define WIN32_LEAN_AND_MEAN 1
#include <Windows.h>

#define _AFX_SKELETON_C
#include "afx/core/afxSystem.h"
#include "afxWavefrontObject.h"
#include "afx/sim/modeling/afxMesh.h"
#include "afx/sim/afxMaterial.h"
#include "afx/sim/afxAsset.h"
#include "../e2coree/deps/glus/GL/glus.h"
#include "../e2coree/deps/glus/GLUS/glus_wavefront.h"
#include "afx/core/afxUri.h"
#include "afx/draw/afxDrawSystem.h"
#include "afx/math/afxVector.h"
#include "afx/math/afxQuaternion.h"
#include "afx/math/afxMatrix.h"

//afxModule* e2object = NIL;

_AFXEXPORT void MshbGetVertexInfoObj(void* data, afxNat* vtxCnt, afxBool* biased, afxNat* weightCnt, afxNat* attrCnt)
{
    GLUSwavefront* obj = data;

    if (vtxCnt)
        *vtxCnt = obj->numberVertices;

    if (biased)
        *biased = FALSE;

    if (weightCnt)
        *weightCnt = 0;

    if (attrCnt)
    {
        afxNat attrCnt2 = 0;

        if (!!obj->vertices)
            ++attrCnt2;

        if (!!obj->normals)
            ++attrCnt2;

        if (!!obj->tangents)
            ++attrCnt2;

        if (!!obj->bitangents)
            ++attrCnt2;

        if (!!obj->texCoords)
            ++attrCnt2;

        *attrCnt = attrCnt2;
    }
}

_AFXEXPORT void MshbGetVertexWeightsObj(void* data, afxNat first, afxNat cnt, afxVertexWeight weight[])
{
    for (afxNat i = 0; i < cnt; i++)
        weight[i].pivotIdx = 0,
        weight[i].weight = 1.f;
}

_AFXEXPORT void MshbGetVertexBiasesObj(void* data, afxNat baseVtxIdx, afxNat vtxCnt, afxVertexBias bias[])
{
    for (afxNat i = 0; i < vtxCnt; i++)
        bias[i].baseWeightIdx = 0,
        bias[i].weightCnt = 0;
}

_AFXEXPORT void MshbGetVertexSpecsObj(void* data, afxNat baseAttrIdx, afxNat attrCnt, afxVertexAttrSpec spec[], afxBool hasData[])
{
    afxError err = NIL;
    AfxAssert(data);
    AfxAssert(spec);
    AfxAssert(hasData);
    GLUSwavefront* obj = data;

    for (afxNat i = 0; i < attrCnt; i++)
    {
        afxNat attrIdx = baseAttrIdx + i;
        
        switch (attrIdx)
        {
        case 0:
        {
            spec[i].tag = "pos";
            spec[i].fmt = afxVertexFormat_V4D;
            spec[i].usage = afxVertexUsage_POS;
            spec[i].flags = NIL;
            spec[i].cacheIdx = 0;

            hasData[i] = !!obj->vertices;
            break;
        }
        case 1:
        {
            spec[i].tag = "nrm";
            spec[i].fmt = afxVertexFormat_V3D;
            spec[i].usage = afxVertexUsage_NRM;
            spec[i].flags = NIL;
            spec[i].cacheIdx = 0;

            hasData[i] = !!obj->normals;
            break;
        }
        case 2:
        {
            spec[i].tag = "tan";
            spec[i].fmt = afxVertexFormat_V3D;
            spec[i].usage = afxVertexUsage_TAN;
            spec[i].flags = NIL;
            spec[i].cacheIdx = 0;

            hasData[i] = !!obj->tangents;
            break;
        }
        case 3:
        {
            spec[i].tag = "bin";
            spec[i].fmt = afxVertexFormat_V3D;
            spec[i].usage = afxVertexUsage_BTN;
            spec[i].flags = NIL;
            spec[i].cacheIdx = 0;

            hasData[i] = !!obj->bitangents;
            break;
        }
        case 4:
        {
            spec[i].tag = "uv";
            spec[i].fmt = afxVertexFormat_V2D;
            spec[i].usage = afxVertexUsage_UV;
            spec[i].flags = NIL;
            spec[i].cacheIdx = 0;

            hasData[i] = !!obj->texCoords;
            break;
        }
        default: AfxThrowError(); break;
        }
    }
}

_AFXEXPORT void MshbGetVertexDataObj(void* data, afxNat attrIdx, afxNat baseVtxIdx, afxNat vtxCnt, void* dst)
{
    afxError err = NIL;
    AfxAssert(data);
    GLUSwavefront* obj = data;

    switch (attrIdx)
    {
    case 0:
    {
        AfxCopy(dst, &obj->vertices[4 * baseVtxIdx], vtxCnt * sizeof(afxV4d));
        break;
    }
    case 1:
    {
        AfxCopy(dst, ((afxV3d*)obj->normals)[baseVtxIdx], vtxCnt * sizeof(afxV3d));
        break;
    }
    case 2:
    {
        AfxCopy(dst, ((afxV3d*)obj->tangents)[baseVtxIdx], vtxCnt * sizeof(afxV3d));
        break;
    }
    case 3:
    {
        AfxCopy(dst, ((afxV3d*)obj->bitangents)[baseVtxIdx], vtxCnt * sizeof(afxV3d));
        break;
    }
    case 4:
    {
        AfxCopy(dst, ((afxV2d*)obj->texCoords)[baseVtxIdx], vtxCnt * sizeof(afxV2d));
        break;
    }
    default: AfxThrowError(); break;
    }
}

_AFXEXPORT afxNat MshbGetTopologyInfoObj(void* data, afxNat* triCnt, afxNat* surCnt)
{
    GLUSwavefront* obj = data;

    afxNat secCnt = 0, triIdxCnt = 0;
    GLUSgroupList* groupWalker = obj->groups;
    while (groupWalker)
    {
        triIdxCnt += groupWalker->group.numberIndices;
        secCnt++;
        groupWalker = groupWalker->next;
    }

    if (triCnt)
        *triCnt = triIdxCnt / 3;

    if (surCnt)
        *surCnt = secCnt;

    return 0;
}

_AFXEXPORT afxNat MshbGetSurfaceDataObj(void* data, afxNat surIdx, afxNat* mtlIdx, afxNat triangles[])
{
    GLUSwavefront* obj = data;

    *mtlIdx = AFX_INVALID_INDEX;

    afxNat secCnt = 0;
    GLUSgroupList* groupWalker = obj->groups;

    while (groupWalker)
    {
        if (secCnt == surIdx)
        {
            afxNat idxCnt = groupWalker->group.numberIndices;

            for (afxNat i = 0; i < idxCnt; i++)
                triangles[i] = groupWalker->group.indices[i];

            afxNat mtlIdx2 = 0;
            GLUSmaterialList* materialWalker = obj->materials;
            
            while (materialWalker)
            {
                if (&materialWalker->material == groupWalker->group.material)
                {
                    *mtlIdx = mtlIdx2;
                    break;
                }
                mtlIdx2++;
                materialWalker = materialWalker->next;
            }

            return idxCnt;
        }
        secCnt++;
        groupWalker = groupWalker->next;
    }
    return 0;
}

_AFXEXPORT void MshbGetCoincidentMapObj(void* data, afxNat firstVtx, afxNat vtxCnt, afxNat map[])
{
    for (afxNat i = 0; i < vtxCnt; i++)
        map[i] = 0;
}

_AFXEXPORT void MshbGetTriangleMapObj(void* data, afxNat firstVtx, afxNat vtxCnt, afxNat map[])
{
    for (afxNat i = 0; i < vtxCnt; i++)
        map[i] = 0;
}

_AFXEXPORT void MshbGetEdgeMapObj(void* data, afxNat first, afxNat triCnt, afxNat const indices[], afxNat map[])
{
    for (afxNat i = 0; i < triCnt * 3; i++)
        map[i] = 0;
}

_AFXEXPORT void MshbGetBindingInfoObj(void* data, afxNat* mtlCnt, afxNat* artCnt)
{
    GLUSwavefront* obj = data;

    GLUSmaterialList* materialWalker = obj->materials;
    afxNat mtlCnt2 = 0;
    while (materialWalker)
    {
        mtlCnt2++;
        materialWalker = materialWalker->next;
    }

    if (mtlCnt)
        *mtlCnt = mtlCnt2;

    if (artCnt)
        *artCnt = 1;
}

_AFXEXPORT afxMaterial MshbGetMaterialObj(void* data, afxNat mtlIdx)
{
    GLUSwavefront* obj = data;
#if 0
    afxNat mtlIdx2 = 0;
    GLUSmaterialList* materialWalker = obj->materials;

    while (materialWalker)
    {
        if (mtlIdx == mtlIdx2)
        {
            afxMaterial mtl;
            AfxAcquireMaterial(sim, 1, &mtl);
            AfxTryAssertObjects(1, &mtl, afxFcc_MTL);
            afxUri tmp;
            AfxUriWrapLiteralRW(&tmp, materialWalker->material.name, 0);
            AfxRenameMaterial(mtl, &tmp);
            afxUri texUri;
            AfxUriWrapLiteralRW(&texUri, &materialWalker->material.diffuseTextureFilename, 0);
            AfxReloadMaterialTexture(mtl, &texUri);

            break;
        }
        mtlIdx2++;
        materialWalker = materialWalker->next;
    }
#endif
    return NIL;
}

_AFXEXPORT afxNat MshbGetVertebraInfoObj(void* data, afxNat artIdx, afxString* name)
{
    GLUSwavefront* obj = data;
    
    (void)artIdx;
    AfxResetString(name);

    afxNat secCnt = 0;
    afxNat triIdxCnt = 0;
    GLUSgroupList* groupWalker = obj->groups;
    while (groupWalker)
    {
        if (artIdx == secCnt)
        {
            triIdxCnt += groupWalker->group.numberIndices;
            break;
        }        
        groupWalker = groupWalker->next;
        secCnt++;
    }

    return triIdxCnt / 3;
}

_AFXEXPORT void MshbGetVertebraDataObj(void* data, afxString const* name, afxNat baseTriIdx, afxNat triCnt, void* dst)
{
    GLUSwavefront* obj = data;

    afxString tmp;
    afxNat secCnt = 0;
    afxNat triIdxCnt = 0;
    GLUSgroupList* groupWalker = obj->groups;
    while (groupWalker)
    {
        AfxWrapStringLiteral(&tmp, groupWalker->group.name, 0);

        if (0 == AfxCompareString(&tmp, name))
        {
            AfxCopy(dst, groupWalker->group.indices, groupWalker->group.numberIndices * sizeof(groupWalker->group.indices[0]));
            break;
        }
        groupWalker = groupWalker->next;
    }
}

struct cadbData
{
    afxUri const* name;
    afxNat meshCnt;
    afxMesh* meshes;
    afxUri* meshNames;
    afxModel mdl;
    afxSkeleton skl;
};

_AFXEXPORT void CadbGetNameObj(void* data2, afxUri* name)
{
    struct cadbData* data = data2;

    AfxExcerptUriPath(name, data->name);
}

_AFXEXPORT afxNat CadbCountSetsObj(void* data2)
{
    struct cadbData* data = data2;

    afxNat cnt = 0;

    if (data->meshCnt)
        ++cnt;

    if (data->skl)
        ++cnt;

    if (data->mdl)
        ++cnt;

    return cnt;
}

_AFXEXPORT void CadbGetSetInfoObj(void* data2, afxNat setIdx, afxFcc* resType, afxNat* resCnt)
{
    struct cadbData* data = data2;

    if (resType)
        *resType = setIdx == 0 ? afxFcc_MSH : setIdx == 1 ? afxFcc_MDL : setIdx == 2 ? afxFcc_SKL : NIL;

    if (resCnt)
        *resCnt = (setIdx == 0) ? data->meshCnt : (setIdx == 1) ? 1 : (setIdx == 2) ? 1 : 0;
}

_AFXEXPORT void* CadbGetResourceInfoObj(void* data2, afxFcc type, afxNat resIdx, afxUri* name)
{
    struct cadbData* data = data2;

    if (name)
    {
        if (type != afxFcc_MSH)
            AfxExcerptUriName(name, data->name);
        else
            AfxExcerptUriName(name, &data->meshNames[resIdx]);
    }

    if (type == afxFcc_MSH)
        return (data->meshes[resIdx]);

    if (type == afxFcc_MDL)
        return data->mdl;
        
    if (type == afxFcc_SKL)
        return data->skl;

    return NIL;
}

_AFXEXPORT void SklbGetInfoObj(void* data2, afxNat* boneCnt, afxNat* lodType)
{
    afxError err = NIL;
    GLUSscene* g_wavefrontScene = data2;
    AfxAssert(g_wavefrontScene);

    if (boneCnt)
    {
        afxNat boneCnt2 = 0;

        GLUSobjectList* objectWalker = g_wavefrontScene->objectList;
        while (objectWalker)
        {
            ++boneCnt2;
            objectWalker = objectWalker->next;
        }

        *boneCnt = boneCnt2;
    }

    if (lodType)
        *lodType = NIL;
}

_AFXEXPORT afxNat SklbGetParentObj(void* data, afxNat boneIdx)
{
    afxError err = NIL;
    GLUSscene* g_wavefrontScene = data;
    AfxAssert(g_wavefrontScene);
    AfxAssert(boneIdx == 0);
    return AFX_INVALID_INDEX;
}

_AFXEXPORT void SklbGetTagObj(void* data2, afxNat boneIdx, afxString* dst)
{
    afxError err = NIL;
    GLUSscene* g_wavefrontScene = data2;
    AfxAssert(g_wavefrontScene);

    if (dst)
    {
        afxNat boneCnt = 0;
        AfxResetString(dst);

        GLUSobjectList* objectWalker = g_wavefrontScene->objectList;
        while (objectWalker)
        {
            if (boneCnt == boneIdx)
            {
                AfxWrapStringLiteral(dst, objectWalker->object.name, 0);
                return;
            }
            ++boneCnt;
            objectWalker = objectWalker->next;
        }
    }
}

_AFXEXPORT afxError AfxLoadAssetsFromWavefrontObj(afxSimulation sim, afxFlags flags, afxNat cnt, afxUri const file[], afxAsset cad[])
{
    afxError err = AFX_ERR_NONE;

    // a entire file should be an afxModel.
    // each object should be an afxMesh, if none at least one afxMesh must pack all groups.
    // each group should be an afxMeshSurface
    // .obj doesn't contains skeletal info, so must have one single afxMeshVertebra bound to all groups.

    AfxAssert(sim);
    afxContext mem = AfxSimulationGetMemory(sim);

    for (afxNat i = 0; i < cnt; i++)
    {

        GLUSscene g_wavefrontScene;
#if !0
        afxUri file2;
        afxUri2048 uri2;
        AfxUri2048(&uri2);
        AfxExcerptUriPath(&file2, &file[i]);
        AfxResolveUri(&file2, AFX_FILE_FLAG_R, &uri2.uri);

        if (!_ldrWavefrontLoadScene(AfxGetUriData(&uri2.uri, 0), &g_wavefrontScene, NIL)) AfxThrowError();
        else
        {
            afxMeshBuilder mshb = { 0 };
            mshb.GetVertexInfo = MshbGetVertexInfoObj;
            mshb.GetVertexBiases = MshbGetVertexBiasesObj;
            mshb.GetVertexWeights = MshbGetVertexWeightsObj;
            mshb.GetVertexData = MshbGetVertexDataObj;
            mshb.GetVertexSpecs = MshbGetVertexSpecsObj;
            
            mshb.GetTopologyInfo = MshbGetTopologyInfoObj;
            mshb.GetSurfaceData = MshbGetSurfaceDataObj;
            mshb.GetEdgeMap = MshbGetEdgeMapObj;
            mshb.GetBindingInfo = MshbGetBindingInfoObj;
            mshb.GetMaterial = MshbGetMaterialObj;
            mshb.GetVertebraInfo = MshbGetVertebraInfoObj;
            mshb.GetVertebraData = MshbGetVertebraDataObj;

            afxNat meshCnt = 0;
            GLUSobjectList* objectWalker = g_wavefrontScene.objectList;
            while (objectWalker)
            {
                meshCnt++;
                objectWalker = objectWalker->next;
            }

            afxArray meshRes;
            afxArray meshNames;
            AfxAcquireArray(&meshRes, sizeof(&objectWalker->object), meshCnt, AfxSpawnHint());
            AfxAcquireArray(&meshNames, sizeof(afxUri), meshCnt, AfxSpawnHint());
            AfxReserveArraySpace(&meshRes, meshCnt);
            AfxReserveArraySpace(&meshNames, meshCnt);

            objectWalker = g_wavefrontScene.objectList;
            while (objectWalker)
            {
                afxNat idx;
                GLUSwavefront*ptr = &objectWalker->object;
                AfxInsertArrayUnits(&meshRes, 1, &idx, &ptr);
                AfxUriWrapLiteral(AfxInsertArrayUnit(&meshNames, &idx), objectWalker->object.name, 0);
                AfxAdvertise("%.*s", AfxPushString(AfxUriGetStringConst(AfxGetArrayUnit(&meshNames, idx))));
                objectWalker = objectWalker->next;
            }

            afxArray meshes;
            AfxAcquireArray(&meshes, sizeof(afxMesh), meshCnt, AfxSpawnHint());
            AfxReserveArraySpace(&meshes, meshCnt);
            
            if (AfxBuildMeshes(sim, &mshb, meshCnt, meshRes.data, meshes.data))
                AfxThrowError();

            AfxAssertObjects(meshCnt, meshes.data, afxFcc_MSH);
            AfxReleaseArray(&meshRes);
            meshes.cnt = meshCnt;

            // build the skeleton
            afxSkeletonBuilder sklb = { 0 };
            sklb.GetParent = SklbGetParentObj;
            sklb.GetInfo = SklbGetInfoObj;
            sklb.GetTag = SklbGetTagObj;            
            afxSkeleton skl = NIL;
            
            if (AfxBuildSkeletons(sim, &sklb, 1, (void*[]){ &g_wavefrontScene }, &skl))
                AfxThrowError();

            AfxAssertObjects(1, &skl, afxFcc_SKL);

            // assemble all things into a model
            afxUri mdlName;
            AfxExcerptUriName(&mdlName, &file2);
            afxModel mdl = AfxAssembleModel(sim, &mdlName, skl, NIL, meshCnt, meshes.data);
            AfxAssertObjects(1, &mdl, afxFcc_MDL);

            afxAssetBuilder cadb = { 0 };
            cadb.GetName = CadbGetNameObj;
            cadb.CountSets = CadbCountSetsObj;
            cadb.GetResourceInfo = CadbGetResourceInfoObj;
            cadb.GetSetInfo = CadbGetSetInfoObj;
            
            struct cadbData cadbD = { 0 };
            cadbD.name = &file2;
            cadbD.meshCnt = meshCnt;
            cadbD.meshes = meshes.data;
            cadbD.meshNames = meshNames.data;
            cadbD.mdl = mdl;
            cadbD.skl = skl;

            if (AfxBuildAssets(sim, &cadb, 1, (void*[]) { &cadbD }, cad))
                AfxThrowError();

            AfxReleaseObjects(meshCnt, meshes.data);
            AfxReleaseArray(&meshes);
            AfxReleaseArray(&meshNames);
            AfxReleaseObjects(1, (void*[]) { skl });
            AfxReleaseObjects(1, (void*[]) { mdl });

            _ldrWavefrontDestroyScene(&(g_wavefrontScene));
        }
#endif//0
    }
    return err;
}
