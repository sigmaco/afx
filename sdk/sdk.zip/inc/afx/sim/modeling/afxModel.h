/*
 *          ::::::::  :::       :::     :::     :::::::::  :::::::::   ::::::::
 *         :+:    :+: :+:       :+:   :+: :+:   :+:    :+: :+:    :+: :+:    :+:
 *         +:+    +:+ +:+       +:+  +:+   +:+  +:+    +:+ +:+    +:+ +:+    +:+
 *         +#+    +:+ +#+  +:+  +#+ +#++:++#++: +#+    +:+ +#++:++#:  +#+    +:+
 *         +#+  # +#+ +#+ +#+#+ +#+ +#+     +#+ +#+    +#+ +#+    +#+ +#+    +#+
 *         #+#   +#+   #+#+# #+#+#  #+#     #+# #+#    #+# #+#    #+# #+#    #+#
 *          ###### ###  ###   ###   ###     ### #########  ###    ###  ########
 *
 *              T H E   Q W A D R O   E X E C U T I O N   E C O S Y S T E M
 *
 *                                   Public Test Build
 *                   (c) 2017 SIGMA Technology Group � Federa��o SIGMA
 *                                    www.sigmaco.org
 */

#ifndef AFX_MODEL_H
#define AFX_MODEL_H

#include "afxMesh.h"
#include "afx/sim/afxSkeleton.h"

/// O objeto afxModel descreve uma cole��o de afxMesh'es que s�o todas ligadas ao mesmo afxSkeleton.
/// Isso � essencialmente qualquer grupo conectado de malhas que s�o animadas em conjuntura.
/// Um ator seria um modelo, assim seria um ve�culo, ou mesmo uma edifica��o inteira se essa fossa modelada como uma hierarquia singular.
/// Um afxModel completo � feito de um afxSkeleton e um conjunto de afxMesh'es, ambos dos quais podem ser acessados diretamente da estrutura do afxModel.

AFX_DEFINE_STRUCT(afxMeshSlot)
{
    afxMesh             msh;
    afxNat*             boneIndices;
    afxNat*             srcBoneIndices;
    afxSkeleton         srcSkl;
};

#ifdef _AFX_MODEL_C
AFX_OBJECT(afxModel)
{
    afxUri              uri; // 128
    afxSkeleton         skl;
    afxTransform        init;
    afxAabb             aabb;
    afxNat              meshSlotCnt;
    afxMeshSlot         *meshSlots;
};
#endif

AFX afxUri const*       AfxGetModelUri(afxModel mdl);

AFX afxSkeleton         AfxGetModelSkeleton(afxModel mdl);
AFX void                AfxSetModelSkeleton(afxModel mdl, afxSkeleton skl);

AFX void                AfxGetModelInitialPlacement(afxModel mdl, afxReal m[4][4]);
AFX void                AfxSetModelInitialPlacement(afxModel mdl, afxTransform const* xform);

AFX afxNat              AfxCountModelMeshes(afxModel mdl);
AFX afxNat              AfxGetBoundMeshes(afxModel mdl, afxNat baseSlotIdx, afxNat slotCnt, afxMesh msh[]);
AFX afxError            AfxBindModelMeshes(afxModel mdl, afxSkeleton srcSkl, afxNat first, afxNat cnt, afxMesh meshes[]);

AFX afxBool             AfxBoundMeshIsTransferred(afxModel mdl, afxNat slotIdx);
AFX afxSkeleton         AfxGetBoundMeshOriginalSkeleton(afxModel mdl, afxNat slotIdx);
AFX afxNat const*       AfxGetBoundMeshOriginalBoneIndices(afxModel mdl, afxNat slotIdx);

AFX afxNat const*       AfxGetBoundMeshBoneIndices(afxModel mdl, afxNat slotIdx);

AFX void                AfxBuildBoundMeshRigMatrixArray(afxModel mdl, afxNat slotIdx, afxWorldPose const* WorldPose, afxNat firstBoneIdx, afxNat boneCnt, afxReal xformBuffer[][4][4]);

AFX afxModel            AfxAssembleModel(afxSimulation sim, afxUri const* name, afxSkeleton skl, afxTransform const* init, afxNat mshCnt, afxMesh msh[]);

AFX void                AfxTransformModels(afxReal const affine[3], afxReal const linear[3][3], afxReal const invLinear[3][3], afxReal affineTol, afxReal linearTol, afxFlags flags, afxNat cnt, afxModel mdl[]);

#endif//AFX_MODEL_H