#ifndef AFX_BRUSH_H
#define AFX_BRUSH_H

#include "afxMmuiDefs.h"

#endif//AFX_BRUSH_H