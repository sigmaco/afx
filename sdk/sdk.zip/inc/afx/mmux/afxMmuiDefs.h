#ifndef AFX_WIDGET_DEFS_H
#define AFX_WIDGET_DEFS_H

#include "afx/draw/afxDrawDefs.h"

#endif//AFX_WIDGET_DEFS_H