/*
 *          ::::::::  :::       :::     :::     :::::::::  :::::::::   ::::::::
 *         :+:    :+: :+:       :+:   :+: :+:   :+:    :+: :+:    :+: :+:    :+:
 *         +:+    +:+ +:+       +:+  +:+   +:+  +:+    +:+ +:+    +:+ +:+    +:+
 *         +#+    +:+ +#+  +:+  +#+ +#++:++#++: +#+    +:+ +#++:++#:  +#+    +:+
 *         +#+  # +#+ +#+ +#+#+ +#+ +#+     +#+ +#+    +#+ +#+    +#+ +#+    +#+
 *         #+#   +#+   #+#+# #+#+#  #+#     #+# #+#    #+# #+#    #+# #+#    #+#
 *          ###### ###  ###   ###   ###     ### #########  ###    ###  ########
 *
 *              T H E   Q W A D R O   E X E C U T I O N   E C O S Y S T E M
 *
 *                                   Public Test Build
 *                   (c) 2017 SIGMA Technology Group � Federa��o SIGMA
 *                                    www.sigmaco.org
 */

// This content is part of SIGMA Future Storage <https://sigmaco.org/future-storage>

#ifndef AFX_XML_H
#define AFX_XML_H

#include "afx/core/afxUri.h"

// XML --- UNIFORM RESOURCE DICTIONARY

AFX_DEFINE_STRUCT(afxXmlAttr)
{
    afxString name, content;
};

AFX_DEFINE_STRUCT(afxXmlNode)
{
    afxString           name, content;
    afxXmlAttr          **attributes;
    afxXmlNode          **children;
};

AFX_DEFINE_STRUCT(afxXml)
{
    _AFX_DBG_FCC; // afxFcc_XML
    struct
    {
        afxByte*    buffer;
        afxSize     length;
    }               buffer;
    afxXmlNode      *root;
};

AFX afxError            AfxLoadXml(afxXml* xml, afxUri const *uri);
AFX afxError            AfxParseXml(afxXml* xml, void* buffer, afxNat bufSiz);
AFX void                AfxReleaseXml(afxXml* xml);

AFX afxXmlNode*         AfxGetXmlRoot(afxXml* xml);
AFX afxString const*    AfxGetXmlNodeName(afxXmlNode const *node);
AFX afxString const*    AfxGetXmlNodeContent(afxXmlNode const *node);
AFX afxNat              AfxCountXmlChildNodes(afxXmlNode const *node);
AFX afxXmlNode const*   AfxGetXmlChildNode(afxXmlNode const *node, afxNat idx);
AFX afxNat              AfxCountXmlAttributes(afxXmlNode const *node);
AFX afxString*          AfxXmlNodeGetAttributeName(afxXmlNode const *node, afxNat idx);
AFX afxString*          AfxXmlNodeGetAttributeContent(afxXmlNode const *node, afxNat idx);

AFX afxBool             AfxXmlNodeHasAttribute(afxXmlNode const* node, afxString const* key, afxBool ci);

AFX afxString const*    AfxFindXmlAttribute(afxXmlNode const* node, afxString const* key, afxBool ci);

AFX afxBool             AfxExtractXmlAttributeI32(afxXmlNode const* node, afxString const* key, afxBool ci, afxInt32* value);
AFX afxBool             AfxExtractXmlAttributeN32(afxXmlNode const* node, afxString const* key, afxBool ci, afxNat32* value);
AFX afxBool             AfxExtractXmlAttributeR32(afxXmlNode const* node, afxString const* key, afxBool ci, afxReal32* value);
AFX afxBool             AfxExtractXmlAttributeR64(afxXmlNode const* node, afxString const* key, afxBool ci, afxReal64* value);


AFX afxXmlNode const*   AfxXmlNodeFindChild(afxXmlNode const *base, afxString const *child, afxString const *attr, afxString const *value);

#endif//AFX_XML_H