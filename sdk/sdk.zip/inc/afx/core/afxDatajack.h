/*
 *          ::::::::  :::       :::     :::     :::::::::  :::::::::   ::::::::
 *         :+:    :+: :+:       :+:   :+: :+:   :+:    :+: :+:    :+: :+:    :+:
 *         +:+    +:+ +:+       +:+  +:+   +:+  +:+    +:+ +:+    +:+ +:+    +:+
 *         +#+    +:+ +#+  +:+  +#+ +#++:++#++: +#+    +:+ +#++:++#:  +#+    +:+
 *         +#+  # +#+ +#+ +#+#+ +#+ +#+     +#+ +#+    +#+ +#+    +#+ +#+    +#+
 *         #+#   +#+   #+#+# #+#+#  #+#     #+# #+#    #+# #+#    #+# #+#    #+#
 *          ###### ###  ###   ###   ###     ### #########  ###    ###  ########
 *
 *              T H E   Q W A D R O   E X E C U T I O N   E C O S Y S T E M
 *
 *                                   Public Test Build
 *                   (c) 2017 SIGMA Technology Group � Federa��o SIGMA
 *                                    www.sigmaco.org
 */

#ifndef AFX_IO_CONTEXT_H
#define AFX_IO_CONTEXT_H

#include "afx/core/afxScript.h"

AFX_DEFINE_HANDLE(afxIoContext);

AFX_OBJECT(afxIoContext)
{
    afxInstance   obj;
};

struct afxIoContextInterface
{
    afxError    (*SubmitScripts)(afxIoContext ctx, afxNat cnt, afxScript scripts[]);
}
AFX AfxIoContext;

#endif//AFX_IO_CONTEXT_H