===============================================
HF2ISO - Heighfield-based Isosurface Landscapes
===============================================

 This is a set of POV-Ray scene files and includes used to
 generate isosurface landscapes based on heightfields. 
 
 The main intent was to add detail to an isosurface based on 
 the vertical slope. This is not posible with just isosurfaces,
 as the slope information is not available inside the isosurface
 function. But we can use a heightfield as the main function for
 the isosurface, and then use the slope information from the hf
 to add detail to the main function.
 
 The results are not perfect, but they allow for more natural 
 looking landscapes, softer on horizontal zones and more "rocky"
 on the vertical parts.
   
 As a bonus, there are some ready-to-use features to enrich 
 the landscapes generated, most borrowed from Project Tierra:
  
   + Slope and height based texturing
   + CIE_Skylight setup (requires Lightsys)
   + Media clouds shell
   + Water plane with normal and optional media
   + Isosurface trees with placement based on slope
   + Simplistic birds grouped in flocks following a pattern

 The quick start is to just render the demo scene hf_iso.pov as 
 provided, using the default aspect ratio (i.e. 320x240). This 
 will render a simple and somewhat fast test using the included 
 heightfield and slopemap files (16bit TGA). For a more rich render,
 set also "use_trees", "use_cirrus" and "use_birds" to 1.


--------
CONTENTS
--------

 + hf tools:
 
   - hf_generator.pov
   
     If you don't have any tool to create heightfields, you can 
     generate random ones with this scene.
     
   - hf_convert.pov
   
     If your heightfield file it's not a 16bit TGA format expected by 
     the demo scene, please use this scene to convert your heighfield.
     
   - hf_slopemap.pov
   
     Use it to extract the vertical slope information from the 
     heightfield to a grayscale slope map. 
   
 + demo scene & includes:
 
   - hf2iso.pov
   
     Main demo scene for the technique.
   
   - hf2iso_terrain.inc
   
     Creates the isosurface landscape based on a heightfield and a slope 
     map. 
     
   - hf2iso_textures.inc
   
     Textures used by the landscape isosurface and vegetation.
     
   - hf2iso_forest.inc
   
     Places fake isosurface trees on the landscape. 
     
   - i_cirrus.inc
   
     Creates clouds shell using media.
     
   - i_flock.inc
   
     Creates simplistic bird flocks, following a pattern.
     
   - i_skylight.inc
   
     Setup for skylight based lighting (needs Lightsys).
     
   - i_water.inc
   
     Water plane with optional interior media.
     
  + Pre-made maps:
  
   - hf_convert.tga
   
     Demo heighfield. The file was generated with hf_generator.pov, then
     edited with The Gimp to add a diffuse black border to avoid unwanted
     peaks, and finally converted with hf_convert.pov (hence the file name).
     
   - hf_slopemap.tga
   
     Demo slope map, generated with hf_slopemap.pov from the above file.
   
   
------------
INSTRUCTIONS
------------

  If you want to use the whole toolset to generate your own landscapes, 
  the process flow is as follows:
  
   1) generate a heightfield, or get an existant one...
   2) convert it to 16bit TGA if it isn't already...
   3) generate the grayscale slope map...
   4) adjust hf2iso parameters/variables...
   5) render...
   6) goto 1,2,3 or 4 until satisfied with the landscape.
   
  Here is a more detailed description of each step:
  
   1) Get or generate the base heightfield
   
      For the base heightfield you can use one you already have,
      or you can generate one with the included tool-scene 
      "hf_generator.pov". 

      If you use your own hf file, please convert it to 16bit TGA
      as outlined in step 2. If you prefer to generate one with the
      tool-scene, render it as a TGA (+FT) to avoid the conversion 
      step (if you plan to manipulate the generated hf, better use PNG 
      for the output as it is more universally recognized, then
      convert it to 16bit TGA). 

      To get nicer results with generated heightfields, you can 
      apply some blur later with an image-manipulation app. The
      selective blur of the Gimp can do a good job softening some 
      parts while mantaining some hard transitions. Also, if you 
      are on Linux, I recommend Geomorph to add some rain/erosion 
      effects. Finally, note that you don't need a big image, as 
      the isosurface turbulence and added detail should get ride of
      any pixelization artifacts (512x512 can be enough).      
      
   2) Conversion to TGA
   
      After having some problems with PNG heighfield files, which
      I didn't understand, I settled for TGA files. These seem to 
      be consistent with the height values I expected for the 
      texturing and object placement. 
      
      So, you must use the included tool-scene "hf_convert.pov" if
      your hf file isn't already a 16bit TGA. This scene takes the 
      hf specified and generates a 16 bit grayscale map of it. You
      must specify +FT on the command line or dialog box.
      
   3) Slope map generation
   
      This is the key part of the process, as this map is used as
      a guide to add the detail to the isosurface version of the 
      hf. The tool-scene "hf_slopemap.pov" takes the specified hf file
      and generates a grayscale map of the vertical slope, where the 
      whiter parts correspond to the steepest slope.
      
      You can tweak the color_map entries to balance the proportion
      between plain/rocky parts. The demo scene also expects it as a 
      TGA file, but not necesarily a 16bit one. Note: curiously enough,
      to obtain better results with 8bit maps, you must use a small 
      image: I recomend 1/4 of the size of the hf.
      
   4) Adjusting demo parameters
   
      There are a few variables on the demo scene which may need
      some adjusting for each heightfield/slopemap combination,
      and also depending on wich pattern you chose to displace
      the high slope parts.
      
      The rest of the parameters only need to be tweaked if you 
      want to turn on/off some features or change their appearence.
      The most important are at the top, on the "trace control"
      section. 
      
      See the comments on the source code for more details.

--
Jaime Vives Piqueres
http://www.ignorancia.org
